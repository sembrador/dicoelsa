var require = meteorInstall({"lib":{"case_utils.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/case_utils.js                                                                                              //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
var hasSpace = /\s/;
var hasSeparator = /[\W_]/;
var hasCamel = /([a-z][A-Z]|[A-Z][a-z])/;
/**
 * Remove any starting case from a `string`, like camel or snake, but keep
 * spaces and punctuation that may be important otherwise.
 *
 * @param {String} string
 * @return {String}
 */

this.toNoCase = function (string) {
  if (hasSpace.test(string)) return string.toLowerCase();
  if (hasSeparator.test(string)) return (unseparate(string) || string).toLowerCase();
  if (hasCamel.test(string)) return uncamelize(string).toLowerCase();
  return string.toLowerCase();
};
/**
 * Separator splitter.
 */


var separatorSplitter = /[\W_]+(.|$)/g;
/**
 * Un-separate a `string`.
 *
 * @param {String} string
 * @return {String}
 */

function unseparate(string) {
  return string.replace(separatorSplitter, function (m, next) {
    return next ? ' ' + next : '';
  });
}
/**
 * Camelcase splitter.
 */


var camelSplitter = /(.)([A-Z]+)/g;
/**
 * Un-camelcase a `string`.
 *
 * @param {String} string
 * @return {String}
 */

function uncamelize(string) {
  return string.replace(camelSplitter, function (m, previous, uppers) {
    return previous + ' ' + uppers.toLowerCase().split('').join(' ');
  });
}

this.toSpaceCase = function (string) {
  return toNoCase(string).replace(/[\W_]+(.|$)/g, function (matches, match) {
    return match ? ' ' + match : '';
  }).trim();
};

this.toCamelCase = function (string) {
  return toSpaceCase(string).replace(/\s(\w)/g, function (matches, letter) {
    return letter.toUpperCase();
  });
};

this.toSnakeCase = function (string) {
  return toSpaceCase(string).replace(/\s/g, '_');
};

this.toKebabCase = function (string) {
  return toSpaceCase(string).replace(/\s/g, '-');
};

this.toTitleCase = function (string) {
  var str = toSpaceCase(string).replace(/\s(\w)/g, function (matches, letter) {
    return " " + letter.toUpperCase();
  });

  if (str) {
    str = str.charAt(0).toUpperCase() + str.slice(1);
  }

  return str;
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"object_utils.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/object_utils.js                                                                                            //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
/*
   Returns property value, where property name is given as path.

   Example:

       getPropertyValue("x.y.z", { x: { y: { z: 123 } } }); // returns 123
*/
this.getPropertyValue = function (propertyName, obj) {
  var props = propertyName.split(".");
  var res = obj;

  for (var i = 0; i < props.length; i++) {
    res = res[props[i]];

    if (typeof res == "undefined") {
      return res;
    }
  }

  return res;
};
/* 
   converts properties in format { "x.y": "z" } to { x: { y: "z" } }
*/


this.deepen = function (o) {
  var oo = {},
      t,
      parts,
      part;

  for (var k in o) {
    t = oo;
    parts = k.split('.');
    var key = parts.pop();

    while (parts.length) {
      part = parts.shift();
      t = t[part] = t[part] || {};
    }

    t[key] = o[k];
  }

  return oo;
};
/*
	Function converts array of objects to csv, tsv or json string

	exportFields: list of object keys to export (array of strings)
	fileType: can be "json", "csv", "tsv" (string)
*/


this.exportArrayOfObjects = function (data, exportFields, fileType) {
  data = data || [];
  fileType = fileType || "csv";
  exportFields = exportFields || [];
  var str = ""; // export to JSON

  if (fileType == "json") {
    var tmp = [];

    _.each(data, function (doc) {
      var obj = {};

      _.each(exportFields, function (field) {
        obj[field] = doc[field];
      });

      tmp.push(obj);
    });

    str = JSON.stringify(tmp);
  } // export to CSV or TSV


  if (fileType == "csv" || fileType == "tsv") {
    var columnSeparator = "";

    if (fileType == "csv") {
      columnSeparator = ",";
    }

    if (fileType == "tsv") {
      // "\t" object literal does not transpile correctly to coffeesctipt
      columnSeparator = String.fromCharCode(9);
    }

    _.each(exportFields, function (field, i) {
      if (i > 0) {
        str = str + columnSeparator;
      }

      str = str + "\"" + field + "\"";
    }); //\r does not transpile correctly to coffeescript


    str = str + String.fromCharCode(13) + "\n";

    _.each(data, function (doc) {
      _.each(exportFields, function (field, i) {
        if (i > 0) {
          str = str + columnSeparator;
        }

        var value = getPropertyValue(field, doc) + "";
        value = value.replace(/"/g, '""');
        if (typeof value == "undefined") str = str + "\"\"";else str = str + "\"" + value + "\"";
      }); //\r does not transpile correctly to coffeescript


      str = str + String.fromCharCode(13) + "\n";
    });
  }

  return str;
};

this.mergeObjects = function (target, source) {
  /* Merges two (or more) objects,
  giving the last one precedence */
  if (typeof target !== "object") {
    target = {};
  }

  for (var property in source) {
    if (source.hasOwnProperty(property)) {
      var sourceProperty = source[property];

      if (typeof sourceProperty === 'object') {
        target[property] = mergeObjects(target[property], sourceProperty);
        continue;
      }

      target[property] = sourceProperty;
    }
  }

  for (var a = 2, l = arguments.length; a < l; a++) {
    mergeObjects(target, arguments[a]);
  }

  return target;
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"string_utils.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/string_utils.js                                                                                            //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
this.escapeRegEx = function (string) {
  return string.replace(/([.*+?^=!:${}()|\[\]\/\\])/g, "\\$1");
};

this.replaceSubstrings = function (string, find, replace) {
  return string.replace(new RegExp(escapeRegEx(find), 'g'), replace);
};

this.joinStrings = function (stringArray, join) {
  var sep = join || ", ";
  var res = "";

  _.each(stringArray, function (str) {
    if (str) {
      if (res) res = res + sep;
      res = res + str;
    }
  });

  return res;
};

this.convertToSlug = function (text) {
  return text.toString().toLowerCase().replace(/\s+/g, '-') // Replace spaces with -
  .replace(/[^\w\-]+/g, '') // Remove all non-word chars
  .replace(/\-\-+/g, '-') // Replace multiple - with single -
  .replace(/^-+/, '') // Trim - from start of text
  .replace(/-+$/, ''); // Trim - from end of text
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"both":{"collections":{"contratistas.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// both/collections/contratistas.js                                                                               //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
this.Contratistas = new Mongo.Collection("contratistas");

this.Contratistas.userCanInsert = function (userId, doc) {
  return true;
};

this.Contratistas.userCanUpdate = function (userId, doc) {
  return true;
};

this.Contratistas.userCanRemove = function (userId, doc) {
  return true;
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"inventario.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// both/collections/inventario.js                                                                                 //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
this.Inventario = new Mongo.Collection("inventario");

this.Inventario.userCanInsert = function (userId, doc) {
  return true;
};

this.Inventario.userCanUpdate = function (userId, doc) {
  return true;
};

this.Inventario.userCanRemove = function (userId, doc) {
  return true;
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"materiales.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// both/collections/materiales.js                                                                                 //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
this.Materiales = new Mongo.Collection("materiales");

this.Materiales.userCanInsert = function (userId, doc) {
  return true;
};

this.Materiales.userCanUpdate = function (userId, doc) {
  return true;
};

this.Materiales.userCanRemove = function (userId, doc) {
  return true;
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"ordenes.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// both/collections/ordenes.js                                                                                    //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
this.Ordenes = new Mongo.Collection("ordenes");

this.Ordenes.userCanInsert = function (userId, doc) {
  return true;
};

this.Ordenes.userCanUpdate = function (userId, doc) {
  return true;
};

this.Ordenes.userCanRemove = function (userId, doc) {
  return true;
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"ordenes_items.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// both/collections/ordenes_items.js                                                                              //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
this.OrdenesItems = new Mongo.Collection("ordenes_items");

this.OrdenesItems.userCanInsert = function (userId, doc) {
  return true;
};

this.OrdenesItems.userCanUpdate = function (userId, doc) {
  return true;
};

this.OrdenesItems.userCanRemove = function (userId, doc) {
  return true;
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"proveedores.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// both/collections/proveedores.js                                                                                //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
this.Proveedores = new Mongo.Collection("proveedores");

this.Proveedores.userCanInsert = function (userId, doc) {
  return true;
};

this.Proveedores.userCanUpdate = function (userId, doc) {
  return true;
};

this.Proveedores.userCanRemove = function (userId, doc) {
  return true;
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"proyectos.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// both/collections/proyectos.js                                                                                  //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
this.Proyectos = new Mongo.Collection("proyectos");

this.Proyectos.userCanInsert = function (userId, doc) {
  return true;
};

this.Proyectos.userCanUpdate = function (userId, doc) {
  return true;
};

this.Proyectos.userCanRemove = function (userId, doc) {
  return true;
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"requisiciones.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// both/collections/requisiciones.js                                                                              //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
this.Requisiciones = new Mongo.Collection("requisiciones");

this.Requisiciones.userCanInsert = function (userId, doc) {
  return true;
};

this.Requisiciones.userCanUpdate = function (userId, doc) {
  return true;
};

this.Requisiciones.userCanRemove = function (userId, doc) {
  return true;
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"requisiciones_items.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// both/collections/requisiciones_items.js                                                                        //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
this.RequisicionesItems = new Mongo.Collection("requisiciones_items");

this.RequisicionesItems.userCanInsert = function (userId, doc) {
  return true;
};

this.RequisicionesItems.userCanUpdate = function (userId, doc) {
  return true;
};

this.RequisicionesItems.userCanRemove = function (userId, doc) {
  return true;
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"transacciones.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// both/collections/transacciones.js                                                                              //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
this.Transacciones = new Mongo.Collection("transacciones");

this.Transacciones.userCanInsert = function (userId, doc) {
  return true;
};

this.Transacciones.userCanUpdate = function (userId, doc) {
  return true;
};

this.Transacciones.userCanRemove = function (userId, doc) {
  return true;
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"collections":{"contratistas.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/collections/contratistas.js                                                                             //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Contratistas.allow({
  insert: function (userId, doc) {
    return false;
  },
  update: function (userId, doc, fields, modifier) {
    return false;
  },
  remove: function (userId, doc) {
    return false;
  }
});
Contratistas.before.insert(function (userId, doc) {
  doc.createdAt = new Date();
  doc.createdBy = userId;
  doc.modifiedAt = doc.createdAt;
  doc.modifiedBy = doc.createdBy;
  if (!doc.createdBy) doc.createdBy = userId;
});
Contratistas.before.update(function (userId, doc, fieldNames, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
});
Contratistas.before.upsert(function (userId, selector, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
  /*BEFORE_UPSERT_CODE*/
});
Contratistas.before.remove(function (userId, doc) {});
Contratistas.after.insert(function (userId, doc) {});
Contratistas.after.update(function (userId, doc, fieldNames, modifier, options) {});
Contratistas.after.remove(function (userId, doc) {});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"inventario.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/collections/inventario.js                                                                               //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Inventario.allow({
  insert: function (userId, doc) {
    return false;
  },
  update: function (userId, doc, fields, modifier) {
    return false;
  },
  remove: function (userId, doc) {
    return false;
  }
});
Inventario.before.insert(function (userId, doc) {
  doc.createdAt = new Date();
  doc.createdBy = userId;
  doc.modifiedAt = doc.createdAt;
  doc.modifiedBy = doc.createdBy;
  if (!doc.createdBy) doc.createdBy = userId;
});
Inventario.before.update(function (userId, doc, fieldNames, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
});
Inventario.before.upsert(function (userId, selector, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
  /*BEFORE_UPSERT_CODE*/
});
Inventario.before.remove(function (userId, doc) {});
Inventario.after.insert(function (userId, doc) {});
Inventario.after.update(function (userId, doc, fieldNames, modifier, options) {});
Inventario.after.remove(function (userId, doc) {});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"materiales.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/collections/materiales.js                                                                               //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Materiales.allow({
  insert: function (userId, doc) {
    return false;
  },
  update: function (userId, doc, fields, modifier) {
    return false;
  },
  remove: function (userId, doc) {
    return false;
  }
});
Materiales.before.insert(function (userId, doc) {
  doc.createdAt = new Date();
  doc.createdBy = userId;
  doc.modifiedAt = doc.createdAt;
  doc.modifiedBy = doc.createdBy;
  if (!doc.createdBy) doc.createdBy = userId;
});
Materiales.before.update(function (userId, doc, fieldNames, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
});
Materiales.before.upsert(function (userId, selector, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
  /*BEFORE_UPSERT_CODE*/
});
Materiales.before.remove(function (userId, doc) {});
Materiales.after.insert(function (userId, doc) {});
Materiales.after.update(function (userId, doc, fieldNames, modifier, options) {});
Materiales.after.remove(function (userId, doc) {});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"ordenes.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/collections/ordenes.js                                                                                  //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Ordenes.allow({
  insert: function (userId, doc) {
    return false;
  },
  update: function (userId, doc, fields, modifier) {
    return false;
  },
  remove: function (userId, doc) {
    return false;
  }
});
Ordenes.before.insert(function (userId, doc) {
  doc.createdAt = new Date();
  doc.createdBy = userId;
  doc.modifiedAt = doc.createdAt;
  doc.modifiedBy = doc.createdBy;
  if (!doc.createdBy) doc.createdBy = userId;
});
Ordenes.before.update(function (userId, doc, fieldNames, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
});
Ordenes.before.upsert(function (userId, selector, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
  /*BEFORE_UPSERT_CODE*/
});
Ordenes.before.remove(function (userId, doc) {});
Ordenes.after.insert(function (userId, doc) {});
Ordenes.after.update(function (userId, doc, fieldNames, modifier, options) {});
Ordenes.after.remove(function (userId, doc) {});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"ordenes_items.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/collections/ordenes_items.js                                                                            //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
OrdenesItems.allow({
  insert: function (userId, doc) {
    return false;
  },
  update: function (userId, doc, fields, modifier) {
    return false;
  },
  remove: function (userId, doc) {
    return false;
  }
});
OrdenesItems.before.insert(function (userId, doc) {
  doc.createdAt = new Date();
  doc.createdBy = userId;
  doc.modifiedAt = doc.createdAt;
  doc.modifiedBy = doc.createdBy;
  if (!doc.createdBy) doc.createdBy = userId;
});
OrdenesItems.before.update(function (userId, doc, fieldNames, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
});
OrdenesItems.before.upsert(function (userId, selector, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
  /*BEFORE_UPSERT_CODE*/
});
OrdenesItems.before.remove(function (userId, doc) {});
OrdenesItems.after.insert(function (userId, doc) {});
OrdenesItems.after.update(function (userId, doc, fieldNames, modifier, options) {});
OrdenesItems.after.remove(function (userId, doc) {});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"proveedores.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/collections/proveedores.js                                                                              //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Proveedores.allow({
  insert: function (userId, doc) {
    return false;
  },
  update: function (userId, doc, fields, modifier) {
    return false;
  },
  remove: function (userId, doc) {
    return false;
  }
});
Proveedores.before.insert(function (userId, doc) {
  doc.createdAt = new Date();
  doc.createdBy = userId;
  doc.modifiedAt = doc.createdAt;
  doc.modifiedBy = doc.createdBy;
  if (!doc.createdBy) doc.createdBy = userId;
});
Proveedores.before.update(function (userId, doc, fieldNames, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
});
Proveedores.before.upsert(function (userId, selector, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
  /*BEFORE_UPSERT_CODE*/
});
Proveedores.before.remove(function (userId, doc) {});
Proveedores.after.insert(function (userId, doc) {});
Proveedores.after.update(function (userId, doc, fieldNames, modifier, options) {});
Proveedores.after.remove(function (userId, doc) {});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"proyectos.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/collections/proyectos.js                                                                                //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Proyectos.allow({
  insert: function (userId, doc) {
    return false;
  },
  update: function (userId, doc, fields, modifier) {
    return false;
  },
  remove: function (userId, doc) {
    return false;
  }
});
Proyectos.before.insert(function (userId, doc) {
  doc.createdAt = new Date();
  doc.createdBy = userId;
  doc.modifiedAt = doc.createdAt;
  doc.modifiedBy = doc.createdBy;
  if (!doc.createdBy) doc.createdBy = userId;
});
Proyectos.before.update(function (userId, doc, fieldNames, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
});
Proyectos.before.upsert(function (userId, selector, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
  /*BEFORE_UPSERT_CODE*/
});
Proyectos.before.remove(function (userId, doc) {});
Proyectos.after.insert(function (userId, doc) {});
Proyectos.after.update(function (userId, doc, fieldNames, modifier, options) {});
Proyectos.after.remove(function (userId, doc) {});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"requisiciones.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/collections/requisiciones.js                                                                            //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Requisiciones.allow({
  insert: function (userId, doc) {
    return false;
  },
  update: function (userId, doc, fields, modifier) {
    return false;
  },
  remove: function (userId, doc) {
    return false;
  }
});
Requisiciones.before.insert(function (userId, doc) {
  doc.createdAt = new Date();
  doc.createdBy = userId;
  doc.modifiedAt = doc.createdAt;
  doc.modifiedBy = doc.createdBy;
  if (!doc.createdBy) doc.createdBy = userId;
});
Requisiciones.before.update(function (userId, doc, fieldNames, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
});
Requisiciones.before.upsert(function (userId, selector, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
  /*BEFORE_UPSERT_CODE*/
});
Requisiciones.before.remove(function (userId, doc) {});
Requisiciones.after.insert(function (userId, doc) {});
Requisiciones.after.update(function (userId, doc, fieldNames, modifier, options) {});
Requisiciones.after.remove(function (userId, doc) {});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"requisiciones_items.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/collections/requisiciones_items.js                                                                      //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
RequisicionesItems.allow({
  insert: function (userId, doc) {
    return false;
  },
  update: function (userId, doc, fields, modifier) {
    return false;
  },
  remove: function (userId, doc) {
    return false;
  }
});
RequisicionesItems.before.insert(function (userId, doc) {
  doc.createdAt = new Date();
  doc.createdBy = userId;
  doc.modifiedAt = doc.createdAt;
  doc.modifiedBy = doc.createdBy;
  if (!doc.createdBy) doc.createdBy = userId;
});
RequisicionesItems.before.update(function (userId, doc, fieldNames, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
});
RequisicionesItems.before.upsert(function (userId, selector, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
  /*BEFORE_UPSERT_CODE*/
});
RequisicionesItems.before.remove(function (userId, doc) {});
RequisicionesItems.after.insert(function (userId, doc) {});
RequisicionesItems.after.update(function (userId, doc, fieldNames, modifier, options) {});
RequisicionesItems.after.remove(function (userId, doc) {});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"transacciones.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/collections/transacciones.js                                                                            //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Transacciones.allow({
  insert: function (userId, doc) {
    return false;
  },
  update: function (userId, doc, fields, modifier) {
    return false;
  },
  remove: function (userId, doc) {
    return false;
  }
});
Transacciones.before.insert(function (userId, doc) {
  doc.createdAt = new Date();
  doc.createdBy = userId;
  doc.modifiedAt = doc.createdAt;
  doc.modifiedBy = doc.createdBy;
  if (!doc.createdBy) doc.createdBy = userId;
});
Transacciones.before.update(function (userId, doc, fieldNames, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
});
Transacciones.before.upsert(function (userId, selector, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
  /*BEFORE_UPSERT_CODE*/
});
Transacciones.before.remove(function (userId, doc) {});
Transacciones.after.insert(function (userId, doc) {});
Transacciones.after.update(function (userId, doc, fieldNames, modifier, options) {});
Transacciones.after.remove(function (userId, doc) {});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"controllers":{"router.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/controllers/router.js                                                                                   //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Router.map(function () {});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods":{"contratistas.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/methods/contratistas.js                                                                                 //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.methods({
  "contratistasInsert": function (data) {
    if (!Contratistas.userCanInsert(this.userId, data)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    return Contratistas.insert(data);
  },
  "contratistasUpdate": function (id, data) {
    var doc = Contratistas.findOne({
      _id: id
    });

    if (!Contratistas.userCanUpdate(this.userId, doc)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    Contratistas.update({
      _id: id
    }, {
      $set: data
    });
  },
  "contratistasRemove": function (id) {
    var doc = Contratistas.findOne({
      _id: id
    });

    if (!Contratistas.userCanRemove(this.userId, doc)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    Contratistas.remove({
      _id: id
    });
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"inventario.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/methods/inventario.js                                                                                   //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.methods({
  "inventarioInsert": function (data) {
    if (!Inventario.userCanInsert(this.userId, data)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    return Inventario.insert(data);
  },
  "inventarioUpdate": function (id, data) {
    var doc = Inventario.findOne({
      _id: id
    });

    if (!Inventario.userCanUpdate(this.userId, doc)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    Inventario.update({
      _id: id
    }, {
      $set: data
    });
  },
  "inventarioRemove": function (id) {
    var doc = Inventario.findOne({
      _id: id
    });

    if (!Inventario.userCanRemove(this.userId, doc)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    Inventario.remove({
      _id: id
    });
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"materiales.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/methods/materiales.js                                                                                   //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.methods({
  "materialesInsert": function (data) {
    if (!Materiales.userCanInsert(this.userId, data)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    return Materiales.insert(data);
  },
  "materialesUpdate": function (id, data) {
    var doc = Materiales.findOne({
      _id: id
    });

    if (!Materiales.userCanUpdate(this.userId, doc)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    Materiales.update({
      _id: id
    }, {
      $set: data
    });
  },
  "materialesRemove": function (id) {
    var doc = Materiales.findOne({
      _id: id
    });

    if (!Materiales.userCanRemove(this.userId, doc)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    Materiales.remove({
      _id: id
    });
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"ordenes.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/methods/ordenes.js                                                                                      //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.methods({
  "ordenesInsert": function (data) {
    if (!Ordenes.userCanInsert(this.userId, data)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    return Ordenes.insert(data);
  },
  "ordenesUpdate": function (id, data) {
    var doc = Ordenes.findOne({
      _id: id
    });

    if (!Ordenes.userCanUpdate(this.userId, doc)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    Ordenes.update({
      _id: id
    }, {
      $set: data
    });
  },
  "ordenesRemove": function (id) {
    var doc = Ordenes.findOne({
      _id: id
    });

    if (!Ordenes.userCanRemove(this.userId, doc)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    Ordenes.remove({
      _id: id
    });
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"ordenes_items.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/methods/ordenes_items.js                                                                                //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.methods({
  "ordenesItemsInsert": function (data) {
    if (!OrdenesItems.userCanInsert(this.userId, data)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    return OrdenesItems.insert(data);
  },
  "ordenesItemsUpdate": function (id, data) {
    var doc = OrdenesItems.findOne({
      _id: id
    });

    if (!OrdenesItems.userCanUpdate(this.userId, doc)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    OrdenesItems.update({
      _id: id
    }, {
      $set: data
    });
  },
  "ordenesItemsRemove": function (id) {
    var doc = OrdenesItems.findOne({
      _id: id
    });

    if (!OrdenesItems.userCanRemove(this.userId, doc)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    OrdenesItems.remove({
      _id: id
    });
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"proveedores.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/methods/proveedores.js                                                                                  //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.methods({
  "proveedoresInsert": function (data) {
    if (!Proveedores.userCanInsert(this.userId, data)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    return Proveedores.insert(data);
  },
  "proveedoresUpdate": function (id, data) {
    var doc = Proveedores.findOne({
      _id: id
    });

    if (!Proveedores.userCanUpdate(this.userId, doc)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    Proveedores.update({
      _id: id
    }, {
      $set: data
    });
  },
  "proveedoresRemove": function (id) {
    var doc = Proveedores.findOne({
      _id: id
    });

    if (!Proveedores.userCanRemove(this.userId, doc)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    Proveedores.remove({
      _id: id
    });
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"proyectos.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/methods/proyectos.js                                                                                    //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.methods({
  "proyectosInsert": function (data) {
    if (!Proyectos.userCanInsert(this.userId, data)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    return Proyectos.insert(data);
  },
  "proyectosUpdate": function (id, data) {
    var doc = Proyectos.findOne({
      _id: id
    });

    if (!Proyectos.userCanUpdate(this.userId, doc)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    Proyectos.update({
      _id: id
    }, {
      $set: data
    });
  },
  "proyectosRemove": function (id) {
    var doc = Proyectos.findOne({
      _id: id
    });

    if (!Proyectos.userCanRemove(this.userId, doc)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    Proyectos.remove({
      _id: id
    });
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"requisiciones.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/methods/requisiciones.js                                                                                //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.methods({
  "requisicionesInsert": function (data) {
    if (!Requisiciones.userCanInsert(this.userId, data)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    return Requisiciones.insert(data);
  },
  "requisicionesUpdate": function (id, data) {
    var doc = Requisiciones.findOne({
      _id: id
    });

    if (!Requisiciones.userCanUpdate(this.userId, doc)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    Requisiciones.update({
      _id: id
    }, {
      $set: data
    });
  },
  "requisicionesRemove": function (id) {
    var doc = Requisiciones.findOne({
      _id: id
    });

    if (!Requisiciones.userCanRemove(this.userId, doc)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    Requisiciones.remove({
      _id: id
    });
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"requisiciones_items.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/methods/requisiciones_items.js                                                                          //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.methods({
  "requisicionesItemsInsert": function (data) {
    if (!RequisicionesItems.userCanInsert(this.userId, data)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    return RequisicionesItems.insert(data);
  },
  "requisicionesItemsUpdate": function (id, data) {
    var doc = RequisicionesItems.findOne({
      _id: id
    });

    if (!RequisicionesItems.userCanUpdate(this.userId, doc)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    RequisicionesItems.update({
      _id: id
    }, {
      $set: data
    });
  },
  "requisicionesItemsRemove": function (id) {
    var doc = RequisicionesItems.findOne({
      _id: id
    });

    if (!RequisicionesItems.userCanRemove(this.userId, doc)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    RequisicionesItems.remove({
      _id: id
    });
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"transacciones.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/methods/transacciones.js                                                                                //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.methods({
  "transaccionesInsert": function (data) {
    if (!Transacciones.userCanInsert(this.userId, data)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    return Transacciones.insert(data);
  },
  "transaccionesUpdate": function (id, data) {
    var doc = Transacciones.findOne({
      _id: id
    });

    if (!Transacciones.userCanUpdate(this.userId, doc)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    Transacciones.update({
      _id: id
    }, {
      $set: data
    });
  },
  "transaccionesRemove": function (id) {
    var doc = Transacciones.findOne({
      _id: id
    });

    if (!Transacciones.userCanRemove(this.userId, doc)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    Transacciones.remove({
      _id: id
    });
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"publish":{"contratistas.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/publish/contratistas.js                                                                                 //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.publish("contratista_list", function () {
  return Contratistas.find({}, {});
});
Meteor.publish("contratistas_null", function () {
  return Contratistas.find({
    _id: null
  }, {});
});
Meteor.publish("contratista", function (contratistaId) {
  return Contratistas.find({
    _id: contratistaId
  }, {});
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"inventario.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/publish/inventario.js                                                                                   //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"materiales.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/publish/materiales.js                                                                                   //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.publish("material_list", function () {
  return Materiales.find({}, {});
});
Meteor.publish("materiales_null", function () {
  return Materiales.find({
    _id: null
  }, {});
});
Meteor.publish("material", function (materialId) {
  return Materiales.find({
    _id: materialId
  }, {});
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"ordenes.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/publish/ordenes.js                                                                                      //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"ordenes_items.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/publish/ordenes_items.js                                                                                //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"proveedores.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/publish/proveedores.js                                                                                  //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.publish("proveedor_list", function () {
  return Proveedores.find({}, {});
});
Meteor.publish("proveedores_null", function () {
  return Proveedores.find({
    _id: null
  }, {});
});
Meteor.publish("proveedor", function (proveedorId) {
  return Proveedores.find({
    _id: proveedorId
  }, {});
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"proyectos.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/publish/proyectos.js                                                                                    //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.publish("proyecto_list", function () {
  return Proyectos.find({}, {});
});
Meteor.publish("proyectos_null", function () {
  return Proyectos.find({
    _id: null
  }, {});
});
Meteor.publish("proyecto", function (proyectoId) {
  return Proyectos.find({
    _id: proyectoId
  }, {});
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"requisiciones.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/publish/requisiciones.js                                                                                //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"requisiciones_items.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/publish/requisiciones_items.js                                                                          //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"transacciones.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/publish/transacciones.js                                                                                //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.publish("transaccion_list", function () {
  return Transacciones.find({}, {});
});
Meteor.publish("transacciones_null", function () {
  return Transacciones.find({
    _id: null
  }, {});
});
Meteor.publish("transaccion", function (transaccionId) {
  return Transacciones.find({
    _id: transaccionId
  }, {});
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/server.js                                                                                               //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
var verifyEmail = true;
Accounts.config({
  sendVerificationEmail: verifyEmail
});
Meteor.startup(function () {
  // read environment variables from Meteor.settings
  if (Meteor.settings && Meteor.settings.env && _.isObject(Meteor.settings.env)) {
    for (var variableName in Meteor.settings.env) {
      process.env[variableName] = Meteor.settings.env[variableName];
    }
  } //
  // Setup OAuth login service configuration (read from Meteor.settings)
  //
  // Your settings file should look like this:
  //
  // {
  //     "oauth": {
  //         "google": {
  //             "clientId": "yourClientId",
  //             "secret": "yourSecret"
  //         },
  //         "github": {
  //             "clientId": "yourClientId",
  //             "secret": "yourSecret"
  //         }
  //     }
  // }
  //


  if (Accounts && Accounts.loginServiceConfiguration && Meteor.settings && Meteor.settings.oauth && _.isObject(Meteor.settings.oauth)) {
    // google
    if (Meteor.settings.oauth.google && _.isObject(Meteor.settings.oauth.google)) {
      // remove old configuration
      Accounts.loginServiceConfiguration.remove({
        service: "google"
      });
      var settingsObject = Meteor.settings.oauth.google;
      settingsObject.service = "google"; // add new configuration

      Accounts.loginServiceConfiguration.insert(settingsObject);
    } // github


    if (Meteor.settings.oauth.github && _.isObject(Meteor.settings.oauth.github)) {
      // remove old configuration
      Accounts.loginServiceConfiguration.remove({
        service: "github"
      });
      var settingsObject = Meteor.settings.oauth.github;
      settingsObject.service = "github"; // add new configuration

      Accounts.loginServiceConfiguration.insert(settingsObject);
    } // linkedin


    if (Meteor.settings.oauth.linkedin && _.isObject(Meteor.settings.oauth.linkedin)) {
      // remove old configuration
      Accounts.loginServiceConfiguration.remove({
        service: "linkedin"
      });
      var settingsObject = Meteor.settings.oauth.linkedin;
      settingsObject.service = "linkedin"; // add new configuration

      Accounts.loginServiceConfiguration.insert(settingsObject);
    } // facebook


    if (Meteor.settings.oauth.facebook && _.isObject(Meteor.settings.oauth.facebook)) {
      // remove old configuration
      Accounts.loginServiceConfiguration.remove({
        service: "facebook"
      });
      var settingsObject = Meteor.settings.oauth.facebook;
      settingsObject.service = "facebook"; // add new configuration

      Accounts.loginServiceConfiguration.insert(settingsObject);
    } // twitter


    if (Meteor.settings.oauth.twitter && _.isObject(Meteor.settings.oauth.twitter)) {
      // remove old configuration
      Accounts.loginServiceConfiguration.remove({
        service: "twitter"
      });
      var settingsObject = Meteor.settings.oauth.twitter;
      settingsObject.service = "twitter"; // add new configuration

      Accounts.loginServiceConfiguration.insert(settingsObject);
    } // meteor


    if (Meteor.settings.oauth.meteor && _.isObject(Meteor.settings.oauth.meteor)) {
      // remove old configuration
      Accounts.loginServiceConfiguration.remove({
        service: "meteor-developer"
      });
      var settingsObject = Meteor.settings.oauth.meteor;
      settingsObject.service = "meteor-developer"; // add new configuration

      Accounts.loginServiceConfiguration.insert(settingsObject);
    }
  }
});
Meteor.methods({
  "createUserAccount": function (options) {
    if (!Users.isAdmin(Meteor.userId())) {
      throw new Meteor.Error(403, "Access denied.");
    }

    var userOptions = {};
    if (options.username) userOptions.username = options.username;
    if (options.email) userOptions.email = options.email;
    if (options.password) userOptions.password = options.password;
    if (options.profile) userOptions.profile = options.profile;
    if (options.profile && options.profile.email) userOptions.email = options.profile.email;
    Accounts.createUser(userOptions);
  },
  "updateUserAccount": function (userId, options) {
    // only admin or users own profile
    if (!(Users.isAdmin(Meteor.userId()) || userId == Meteor.userId())) {
      throw new Meteor.Error(403, "Access denied.");
    } // non-admin user can change only profile


    if (!Users.isAdmin(Meteor.userId())) {
      var keys = Object.keys(options);

      if (keys.length !== 1 || !options.profile) {
        throw new Meteor.Error(403, "Access denied.");
      }
    }

    var userOptions = {};
    if (options.username) userOptions.username = options.username;
    if (options.email) userOptions.email = options.email;
    if (options.password) userOptions.password = options.password;
    if (options.profile) userOptions.profile = options.profile;
    if (options.profile && options.profile.email) userOptions.email = options.profile.email;
    if (options.roles) userOptions.roles = options.roles;

    if (userOptions.email) {
      var email = userOptions.email;
      delete userOptions.email;
      var userData = Users.findOne(this.userId);

      if (userData.emails && !userData.emails.find(function (mail) {
        return mail.address == email;
      })) {
        userOptions.emails = [{
          address: email
        }];
      }
    }

    var password = "";

    if (userOptions.password) {
      password = userOptions.password;
      delete userOptions.password;
    }

    if (userOptions) {
      for (var key in userOptions) {
        var obj = userOptions[key];

        if (_.isObject(obj)) {
          for (var k in obj) {
            userOptions[key + "." + k] = obj[k];
          }

          delete userOptions[key];
        }
      }

      Users.update(userId, {
        $set: userOptions
      });
    }

    if (password) {
      Accounts.setPassword(userId, password);
    }
  },
  "sendMail": function (options) {
    this.unblock();
    Email.send(options);
  }
});
Accounts.onCreateUser(function (options, user) {
  user.roles = ["user"];

  if (options.profile) {
    user.profile = options.profile;
  }

  if (!Users.findOne({
    roles: "admin"
  }) && user.roles.indexOf("admin") < 0) {
    user.roles = ["admin"];
  }

  return user;
});
Accounts.validateLoginAttempt(function (info) {
  // reject users with role "blocked"
  if (info.user && Users.isInRole(info.user._id, "blocked")) {
    throw new Meteor.Error(403, "Your account is blocked.");
  }

  if (verifyEmail && info.user && info.user.emails && info.user.emails.length && !info.user.emails[0].verified) {
    throw new Meteor.Error(499, "E-mail not verified.");
  }

  return true;
});
Users.before.insert(function (userId, doc) {
  if (doc.emails && doc.emails[0] && doc.emails[0].address) {
    doc.profile = doc.profile || {};
    doc.profile.email = doc.emails[0].address;
  } else {
    // oauth
    if (doc.services) {
      // google e-mail
      if (doc.services.google && doc.services.google.email) {
        doc.profile = doc.profile || {};
        doc.profile.email = doc.services.google.email;
      } else {
        // github e-mail
        if (doc.services.github && doc.services.github.accessToken) {
          var github = new GitHub({
            version: "3.0.0",
            timeout: 5000
          });
          github.authenticate({
            type: "oauth",
            token: doc.services.github.accessToken
          });

          try {
            var result = github.user.getEmails({});

            var email = _.findWhere(result, {
              primary: true
            });

            if (!email && result.length && _.isString(result[0])) {
              email = {
                email: result[0]
              };
            }

            if (email) {
              doc.profile = doc.profile || {};
              doc.profile.email = email.email;
            }
          } catch (e) {
            console.log(e);
          }
        } else {
          // linkedin email
          if (doc.services.linkedin && doc.services.linkedin.emailAddress) {
            doc.profile = doc.profile || {};
            doc.profile.name = doc.services.linkedin.firstName + " " + doc.services.linkedin.lastName;
            doc.profile.email = doc.services.linkedin.emailAddress;
          } else {
            if (doc.services.facebook && doc.services.facebook.email) {
              doc.profile = doc.profile || {};
              doc.profile.email = doc.services.facebook.email;
            } else {
              if (doc.services.twitter && doc.services.twitter.email) {
                doc.profile = doc.profile || {};
                doc.profile.email = doc.services.twitter.email;
              } else {
                if (doc.services["meteor-developer"] && doc.services["meteor-developer"].emails && doc.services["meteor-developer"].emails.length) {
                  doc.profile = doc.profile || {};
                  doc.profile.email = doc.services["meteor-developer"].emails[0].address;
                }
              }
            }
          }
        }
      }
    }
  }
});
Users.before.update(function (userId, doc, fieldNames, modifier, options) {
  if (modifier.$set && modifier.$set.emails && modifier.$set.emails.length && modifier.$set.emails[0].address) {
    modifier.$set.profile.email = modifier.$set.emails[0].address;
  }
});
Accounts.onLogin(function (info) {});

Accounts.urls.resetPassword = function (token) {
  return Meteor.absoluteUrl('reset_password/' + token);
};

Accounts.urls.verifyEmail = function (token) {
  return Meteor.absoluteUrl('verify_email/' + token);
};

Accounts.urls.enrollAccount = function (token) {
  return Meteor.absoluteUrl('create_password/' + token);
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("/lib/case_utils.js");
require("/lib/object_utils.js");
require("/lib/string_utils.js");
require("/both/collections/contratistas.js");
require("/both/collections/inventario.js");
require("/both/collections/materiales.js");
require("/both/collections/ordenes.js");
require("/both/collections/ordenes_items.js");
require("/both/collections/proveedores.js");
require("/both/collections/proyectos.js");
require("/both/collections/requisiciones.js");
require("/both/collections/requisiciones_items.js");
require("/both/collections/transacciones.js");
require("/server/collections/contratistas.js");
require("/server/collections/inventario.js");
require("/server/collections/materiales.js");
require("/server/collections/ordenes.js");
require("/server/collections/ordenes_items.js");
require("/server/collections/proveedores.js");
require("/server/collections/proyectos.js");
require("/server/collections/requisiciones.js");
require("/server/collections/requisiciones_items.js");
require("/server/collections/transacciones.js");
require("/server/controllers/router.js");
require("/server/methods/contratistas.js");
require("/server/methods/inventario.js");
require("/server/methods/materiales.js");
require("/server/methods/ordenes.js");
require("/server/methods/ordenes_items.js");
require("/server/methods/proveedores.js");
require("/server/methods/proyectos.js");
require("/server/methods/requisiciones.js");
require("/server/methods/requisiciones_items.js");
require("/server/methods/transacciones.js");
require("/server/publish/contratistas.js");
require("/server/publish/inventario.js");
require("/server/publish/materiales.js");
require("/server/publish/ordenes.js");
require("/server/publish/ordenes_items.js");
require("/server/publish/proveedores.js");
require("/server/publish/proyectos.js");
require("/server/publish/requisiciones.js");
require("/server/publish/requisiciones_items.js");
require("/server/publish/transacciones.js");
require("/server/server.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvbGliL2Nhc2VfdXRpbHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2xpYi9vYmplY3RfdXRpbHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2xpYi9zdHJpbmdfdXRpbHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2JvdGgvY29sbGVjdGlvbnMvY29udHJhdGlzdGFzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9ib3RoL2NvbGxlY3Rpb25zL2ludmVudGFyaW8uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2JvdGgvY29sbGVjdGlvbnMvbWF0ZXJpYWxlcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvYm90aC9jb2xsZWN0aW9ucy9vcmRlbmVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9ib3RoL2NvbGxlY3Rpb25zL29yZGVuZXNfaXRlbXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2JvdGgvY29sbGVjdGlvbnMvcHJvdmVlZG9yZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2JvdGgvY29sbGVjdGlvbnMvcHJveWVjdG9zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9ib3RoL2NvbGxlY3Rpb25zL3JlcXVpc2ljaW9uZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2JvdGgvY29sbGVjdGlvbnMvcmVxdWlzaWNpb25lc19pdGVtcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvYm90aC9jb2xsZWN0aW9ucy90cmFuc2FjY2lvbmVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvY29sbGVjdGlvbnMvY29udHJhdGlzdGFzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvY29sbGVjdGlvbnMvaW52ZW50YXJpby5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2NvbGxlY3Rpb25zL21hdGVyaWFsZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9jb2xsZWN0aW9ucy9vcmRlbmVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvY29sbGVjdGlvbnMvb3JkZW5lc19pdGVtcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2NvbGxlY3Rpb25zL3Byb3ZlZWRvcmVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvY29sbGVjdGlvbnMvcHJveWVjdG9zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvY29sbGVjdGlvbnMvcmVxdWlzaWNpb25lcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2NvbGxlY3Rpb25zL3JlcXVpc2ljaW9uZXNfaXRlbXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9jb2xsZWN0aW9ucy90cmFuc2FjY2lvbmVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvY29udHJvbGxlcnMvcm91dGVyLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWV0aG9kcy9jb250cmF0aXN0YXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tZXRob2RzL2ludmVudGFyaW8uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tZXRob2RzL21hdGVyaWFsZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tZXRob2RzL29yZGVuZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tZXRob2RzL29yZGVuZXNfaXRlbXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tZXRob2RzL3Byb3ZlZWRvcmVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWV0aG9kcy9wcm95ZWN0b3MuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tZXRob2RzL3JlcXVpc2ljaW9uZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tZXRob2RzL3JlcXVpc2ljaW9uZXNfaXRlbXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tZXRob2RzL3RyYW5zYWNjaW9uZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9wdWJsaXNoL2NvbnRyYXRpc3Rhcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3B1Ymxpc2gvbWF0ZXJpYWxlcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3B1Ymxpc2gvcHJvdmVlZG9yZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9wdWJsaXNoL3Byb3llY3Rvcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3B1Ymxpc2gvdHJhbnNhY2Npb25lcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3NlcnZlci5qcyJdLCJuYW1lcyI6WyJoYXNTcGFjZSIsImhhc1NlcGFyYXRvciIsImhhc0NhbWVsIiwidG9Ob0Nhc2UiLCJzdHJpbmciLCJ0ZXN0IiwidG9Mb3dlckNhc2UiLCJ1bnNlcGFyYXRlIiwidW5jYW1lbGl6ZSIsInNlcGFyYXRvclNwbGl0dGVyIiwicmVwbGFjZSIsIm0iLCJuZXh0IiwiY2FtZWxTcGxpdHRlciIsInByZXZpb3VzIiwidXBwZXJzIiwic3BsaXQiLCJqb2luIiwidG9TcGFjZUNhc2UiLCJtYXRjaGVzIiwibWF0Y2giLCJ0cmltIiwidG9DYW1lbENhc2UiLCJsZXR0ZXIiLCJ0b1VwcGVyQ2FzZSIsInRvU25ha2VDYXNlIiwidG9LZWJhYkNhc2UiLCJ0b1RpdGxlQ2FzZSIsInN0ciIsImNoYXJBdCIsInNsaWNlIiwiZ2V0UHJvcGVydHlWYWx1ZSIsInByb3BlcnR5TmFtZSIsIm9iaiIsInByb3BzIiwicmVzIiwiaSIsImxlbmd0aCIsImRlZXBlbiIsIm8iLCJvbyIsInQiLCJwYXJ0cyIsInBhcnQiLCJrIiwia2V5IiwicG9wIiwic2hpZnQiLCJleHBvcnRBcnJheU9mT2JqZWN0cyIsImRhdGEiLCJleHBvcnRGaWVsZHMiLCJmaWxlVHlwZSIsInRtcCIsIl8iLCJlYWNoIiwiZG9jIiwiZmllbGQiLCJwdXNoIiwiSlNPTiIsInN0cmluZ2lmeSIsImNvbHVtblNlcGFyYXRvciIsIlN0cmluZyIsImZyb21DaGFyQ29kZSIsInZhbHVlIiwibWVyZ2VPYmplY3RzIiwidGFyZ2V0Iiwic291cmNlIiwicHJvcGVydHkiLCJoYXNPd25Qcm9wZXJ0eSIsInNvdXJjZVByb3BlcnR5IiwiYSIsImwiLCJhcmd1bWVudHMiLCJlc2NhcGVSZWdFeCIsInJlcGxhY2VTdWJzdHJpbmdzIiwiZmluZCIsIlJlZ0V4cCIsImpvaW5TdHJpbmdzIiwic3RyaW5nQXJyYXkiLCJzZXAiLCJjb252ZXJ0VG9TbHVnIiwidGV4dCIsInRvU3RyaW5nIiwiQ29udHJhdGlzdGFzIiwiTW9uZ28iLCJDb2xsZWN0aW9uIiwidXNlckNhbkluc2VydCIsInVzZXJJZCIsInVzZXJDYW5VcGRhdGUiLCJ1c2VyQ2FuUmVtb3ZlIiwiSW52ZW50YXJpbyIsIk1hdGVyaWFsZXMiLCJPcmRlbmVzIiwiT3JkZW5lc0l0ZW1zIiwiUHJvdmVlZG9yZXMiLCJQcm95ZWN0b3MiLCJSZXF1aXNpY2lvbmVzIiwiUmVxdWlzaWNpb25lc0l0ZW1zIiwiVHJhbnNhY2Npb25lcyIsImFsbG93IiwiaW5zZXJ0IiwidXBkYXRlIiwiZmllbGRzIiwibW9kaWZpZXIiLCJyZW1vdmUiLCJiZWZvcmUiLCJjcmVhdGVkQXQiLCJEYXRlIiwiY3JlYXRlZEJ5IiwibW9kaWZpZWRBdCIsIm1vZGlmaWVkQnkiLCJmaWVsZE5hbWVzIiwib3B0aW9ucyIsIiRzZXQiLCJ1cHNlcnQiLCJzZWxlY3RvciIsImFmdGVyIiwiUm91dGVyIiwibWFwIiwiTWV0ZW9yIiwibWV0aG9kcyIsIkVycm9yIiwiaWQiLCJmaW5kT25lIiwiX2lkIiwicHVibGlzaCIsImNvbnRyYXRpc3RhSWQiLCJtYXRlcmlhbElkIiwicHJvdmVlZG9ySWQiLCJwcm95ZWN0b0lkIiwidHJhbnNhY2Npb25JZCIsInZlcmlmeUVtYWlsIiwiQWNjb3VudHMiLCJjb25maWciLCJzZW5kVmVyaWZpY2F0aW9uRW1haWwiLCJzdGFydHVwIiwic2V0dGluZ3MiLCJlbnYiLCJpc09iamVjdCIsInZhcmlhYmxlTmFtZSIsInByb2Nlc3MiLCJsb2dpblNlcnZpY2VDb25maWd1cmF0aW9uIiwib2F1dGgiLCJnb29nbGUiLCJzZXJ2aWNlIiwic2V0dGluZ3NPYmplY3QiLCJnaXRodWIiLCJsaW5rZWRpbiIsImZhY2Vib29rIiwidHdpdHRlciIsIm1ldGVvciIsIlVzZXJzIiwiaXNBZG1pbiIsInVzZXJPcHRpb25zIiwidXNlcm5hbWUiLCJlbWFpbCIsInBhc3N3b3JkIiwicHJvZmlsZSIsImNyZWF0ZVVzZXIiLCJrZXlzIiwiT2JqZWN0Iiwicm9sZXMiLCJ1c2VyRGF0YSIsImVtYWlscyIsIm1haWwiLCJhZGRyZXNzIiwic2V0UGFzc3dvcmQiLCJ1bmJsb2NrIiwiRW1haWwiLCJzZW5kIiwib25DcmVhdGVVc2VyIiwidXNlciIsImluZGV4T2YiLCJ2YWxpZGF0ZUxvZ2luQXR0ZW1wdCIsImluZm8iLCJpc0luUm9sZSIsInZlcmlmaWVkIiwic2VydmljZXMiLCJhY2Nlc3NUb2tlbiIsIkdpdEh1YiIsInZlcnNpb24iLCJ0aW1lb3V0IiwiYXV0aGVudGljYXRlIiwidHlwZSIsInRva2VuIiwicmVzdWx0IiwiZ2V0RW1haWxzIiwiZmluZFdoZXJlIiwicHJpbWFyeSIsImlzU3RyaW5nIiwiZSIsImNvbnNvbGUiLCJsb2ciLCJlbWFpbEFkZHJlc3MiLCJuYW1lIiwiZmlyc3ROYW1lIiwibGFzdE5hbWUiLCJvbkxvZ2luIiwidXJscyIsInJlc2V0UGFzc3dvcmQiLCJhYnNvbHV0ZVVybCIsImVucm9sbEFjY291bnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUEsSUFBSUEsV0FBVyxJQUFmO0FBQ0EsSUFBSUMsZUFBZSxPQUFuQjtBQUNBLElBQUlDLFdBQVcseUJBQWY7QUFFQTs7Ozs7Ozs7QUFRQSxLQUFLQyxRQUFMLEdBQWdCLFVBQVNDLE1BQVQsRUFBaUI7QUFDL0IsTUFBSUosU0FBU0ssSUFBVCxDQUFjRCxNQUFkLENBQUosRUFBMkIsT0FBT0EsT0FBT0UsV0FBUCxFQUFQO0FBQzNCLE1BQUlMLGFBQWFJLElBQWIsQ0FBa0JELE1BQWxCLENBQUosRUFBK0IsT0FBTyxDQUFDRyxXQUFXSCxNQUFYLEtBQXNCQSxNQUF2QixFQUErQkUsV0FBL0IsRUFBUDtBQUMvQixNQUFJSixTQUFTRyxJQUFULENBQWNELE1BQWQsQ0FBSixFQUEyQixPQUFPSSxXQUFXSixNQUFYLEVBQW1CRSxXQUFuQixFQUFQO0FBQzNCLFNBQU9GLE9BQU9FLFdBQVAsRUFBUDtBQUNELENBTEQ7QUFPQTs7Ozs7QUFJQSxJQUFJRyxvQkFBb0IsY0FBeEI7QUFFQTs7Ozs7OztBQU9BLFNBQVNGLFVBQVQsQ0FBb0JILE1BQXBCLEVBQTRCO0FBQzFCLFNBQU9BLE9BQU9NLE9BQVAsQ0FBZUQsaUJBQWYsRUFBa0MsVUFBVUUsQ0FBVixFQUFhQyxJQUFiLEVBQW1CO0FBQzFELFdBQU9BLE9BQU8sTUFBTUEsSUFBYixHQUFvQixFQUEzQjtBQUNELEdBRk0sQ0FBUDtBQUdEO0FBRUQ7Ozs7O0FBSUEsSUFBSUMsZ0JBQWdCLGNBQXBCO0FBRUE7Ozs7Ozs7QUFPQSxTQUFTTCxVQUFULENBQW9CSixNQUFwQixFQUE0QjtBQUMxQixTQUFPQSxPQUFPTSxPQUFQLENBQWVHLGFBQWYsRUFBOEIsVUFBVUYsQ0FBVixFQUFhRyxRQUFiLEVBQXVCQyxNQUF2QixFQUErQjtBQUNsRSxXQUFPRCxXQUFXLEdBQVgsR0FBaUJDLE9BQU9ULFdBQVAsR0FBcUJVLEtBQXJCLENBQTJCLEVBQTNCLEVBQStCQyxJQUEvQixDQUFvQyxHQUFwQyxDQUF4QjtBQUNELEdBRk0sQ0FBUDtBQUdEOztBQUVELEtBQUtDLFdBQUwsR0FBbUIsVUFBU2QsTUFBVCxFQUFpQjtBQUNsQyxTQUFPRCxTQUFTQyxNQUFULEVBQWlCTSxPQUFqQixDQUF5QixjQUF6QixFQUF5QyxVQUFVUyxPQUFWLEVBQW1CQyxLQUFuQixFQUEwQjtBQUN4RSxXQUFPQSxRQUFRLE1BQU1BLEtBQWQsR0FBc0IsRUFBN0I7QUFDRCxHQUZNLEVBRUpDLElBRkksRUFBUDtBQUdELENBSkQ7O0FBTUEsS0FBS0MsV0FBTCxHQUFtQixVQUFTbEIsTUFBVCxFQUFpQjtBQUNsQyxTQUFPYyxZQUFZZCxNQUFaLEVBQW9CTSxPQUFwQixDQUE0QixTQUE1QixFQUF1QyxVQUFVUyxPQUFWLEVBQW1CSSxNQUFuQixFQUEyQjtBQUN2RSxXQUFPQSxPQUFPQyxXQUFQLEVBQVA7QUFDRCxHQUZNLENBQVA7QUFHRCxDQUpEOztBQU1BLEtBQUtDLFdBQUwsR0FBbUIsVUFBU3JCLE1BQVQsRUFBaUI7QUFDbEMsU0FBT2MsWUFBWWQsTUFBWixFQUFvQk0sT0FBcEIsQ0FBNEIsS0FBNUIsRUFBbUMsR0FBbkMsQ0FBUDtBQUNELENBRkQ7O0FBSUEsS0FBS2dCLFdBQUwsR0FBbUIsVUFBU3RCLE1BQVQsRUFBaUI7QUFDbEMsU0FBT2MsWUFBWWQsTUFBWixFQUFvQk0sT0FBcEIsQ0FBNEIsS0FBNUIsRUFBbUMsR0FBbkMsQ0FBUDtBQUNELENBRkQ7O0FBSUEsS0FBS2lCLFdBQUwsR0FBbUIsVUFBU3ZCLE1BQVQsRUFBaUI7QUFDbEMsTUFBSXdCLE1BQU1WLFlBQVlkLE1BQVosRUFBb0JNLE9BQXBCLENBQTRCLFNBQTVCLEVBQXVDLFVBQVNTLE9BQVQsRUFBa0JJLE1BQWxCLEVBQTBCO0FBQ3pFLFdBQU8sTUFBTUEsT0FBT0MsV0FBUCxFQUFiO0FBQ0QsR0FGUyxDQUFWOztBQUlBLE1BQUdJLEdBQUgsRUFBUTtBQUNOQSxVQUFNQSxJQUFJQyxNQUFKLENBQVcsQ0FBWCxFQUFjTCxXQUFkLEtBQThCSSxJQUFJRSxLQUFKLENBQVUsQ0FBVixDQUFwQztBQUNEOztBQUNELFNBQU9GLEdBQVA7QUFDRCxDQVRELEM7Ozs7Ozs7Ozs7O0FDN0VBOzs7Ozs7O0FBUUEsS0FBS0csZ0JBQUwsR0FBd0IsVUFBU0MsWUFBVCxFQUF1QkMsR0FBdkIsRUFBNEI7QUFDbkQsTUFBSUMsUUFBUUYsYUFBYWhCLEtBQWIsQ0FBbUIsR0FBbkIsQ0FBWjtBQUNBLE1BQUltQixNQUFNRixHQUFWOztBQUNBLE9BQUksSUFBSUcsSUFBSSxDQUFaLEVBQWVBLElBQUlGLE1BQU1HLE1BQXpCLEVBQWlDRCxHQUFqQyxFQUFzQztBQUNyQ0QsVUFBTUEsSUFBSUQsTUFBTUUsQ0FBTixDQUFKLENBQU47O0FBQ0EsUUFBRyxPQUFPRCxHQUFQLElBQWMsV0FBakIsRUFBOEI7QUFDN0IsYUFBT0EsR0FBUDtBQUNBO0FBQ0Q7O0FBQ0QsU0FBT0EsR0FBUDtBQUNBLENBVkQ7QUFhQTs7Ozs7QUFJQSxLQUFLRyxNQUFMLEdBQWMsVUFBU0MsQ0FBVCxFQUFZO0FBQ3pCLE1BQUlDLEtBQUssRUFBVDtBQUFBLE1BQWFDLENBQWI7QUFBQSxNQUFnQkMsS0FBaEI7QUFBQSxNQUF1QkMsSUFBdkI7O0FBQ0EsT0FBSyxJQUFJQyxDQUFULElBQWNMLENBQWQsRUFBaUI7QUFDaEJFLFFBQUlELEVBQUo7QUFDQUUsWUFBUUUsRUFBRTVCLEtBQUYsQ0FBUSxHQUFSLENBQVI7QUFDQSxRQUFJNkIsTUFBTUgsTUFBTUksR0FBTixFQUFWOztBQUNBLFdBQU9KLE1BQU1MLE1BQWIsRUFBcUI7QUFDcEJNLGFBQU9ELE1BQU1LLEtBQU4sRUFBUDtBQUNBTixVQUFJQSxFQUFFRSxJQUFGLElBQVVGLEVBQUVFLElBQUYsS0FBVyxFQUF6QjtBQUNBOztBQUNERixNQUFFSSxHQUFGLElBQVNOLEVBQUVLLENBQUYsQ0FBVDtBQUNBOztBQUNELFNBQU9KLEVBQVA7QUFDQSxDQWJEO0FBZUE7Ozs7Ozs7O0FBT0EsS0FBS1Esb0JBQUwsR0FBNEIsVUFBU0MsSUFBVCxFQUFlQyxZQUFmLEVBQTZCQyxRQUE3QixFQUF1QztBQUNsRUYsU0FBT0EsUUFBUSxFQUFmO0FBQ0FFLGFBQVdBLFlBQVksS0FBdkI7QUFDQUQsaUJBQWVBLGdCQUFnQixFQUEvQjtBQUVBLE1BQUl0QixNQUFNLEVBQVYsQ0FMa0UsQ0FNbEU7O0FBQ0EsTUFBR3VCLFlBQVksTUFBZixFQUF1QjtBQUV0QixRQUFJQyxNQUFNLEVBQVY7O0FBQ0FDLE1BQUVDLElBQUYsQ0FBT0wsSUFBUCxFQUFhLFVBQVNNLEdBQVQsRUFBYztBQUMxQixVQUFJdEIsTUFBTSxFQUFWOztBQUNBb0IsUUFBRUMsSUFBRixDQUFPSixZQUFQLEVBQXFCLFVBQVNNLEtBQVQsRUFBZ0I7QUFDcEN2QixZQUFJdUIsS0FBSixJQUFhRCxJQUFJQyxLQUFKLENBQWI7QUFDQSxPQUZEOztBQUdBSixVQUFJSyxJQUFKLENBQVN4QixHQUFUO0FBQ0EsS0FORDs7QUFRQUwsVUFBTThCLEtBQUtDLFNBQUwsQ0FBZVAsR0FBZixDQUFOO0FBQ0EsR0FuQmlFLENBcUJsRTs7O0FBQ0EsTUFBR0QsWUFBWSxLQUFaLElBQXFCQSxZQUFZLEtBQXBDLEVBQTJDO0FBQzFDLFFBQUlTLGtCQUFrQixFQUF0Qjs7QUFDQSxRQUFHVCxZQUFZLEtBQWYsRUFBc0I7QUFDckJTLHdCQUFrQixHQUFsQjtBQUNBOztBQUNELFFBQUdULFlBQVksS0FBZixFQUFzQjtBQUNyQjtBQUNBUyx3QkFBa0JDLE9BQU9DLFlBQVAsQ0FBb0IsQ0FBcEIsQ0FBbEI7QUFDQTs7QUFFRFQsTUFBRUMsSUFBRixDQUFPSixZQUFQLEVBQXFCLFVBQVNNLEtBQVQsRUFBZ0JwQixDQUFoQixFQUFtQjtBQUN2QyxVQUFHQSxJQUFJLENBQVAsRUFBVTtBQUNUUixjQUFNQSxNQUFNZ0MsZUFBWjtBQUNBOztBQUNEaEMsWUFBTUEsTUFBTSxJQUFOLEdBQWE0QixLQUFiLEdBQXFCLElBQTNCO0FBQ0EsS0FMRCxFQVYwQyxDQWdCMUM7OztBQUNBNUIsVUFBTUEsTUFBTWlDLE9BQU9DLFlBQVAsQ0FBb0IsRUFBcEIsQ0FBTixHQUFnQyxJQUF0Qzs7QUFFQVQsTUFBRUMsSUFBRixDQUFPTCxJQUFQLEVBQWEsVUFBU00sR0FBVCxFQUFjO0FBQzFCRixRQUFFQyxJQUFGLENBQU9KLFlBQVAsRUFBcUIsVUFBU00sS0FBVCxFQUFnQnBCLENBQWhCLEVBQW1CO0FBQ3ZDLFlBQUdBLElBQUksQ0FBUCxFQUFVO0FBQ1RSLGdCQUFNQSxNQUFNZ0MsZUFBWjtBQUNBOztBQUVELFlBQUlHLFFBQVFoQyxpQkFBaUJ5QixLQUFqQixFQUF3QkQsR0FBeEIsSUFBK0IsRUFBM0M7QUFDQVEsZ0JBQVFBLE1BQU1yRCxPQUFOLENBQWMsSUFBZCxFQUFvQixJQUFwQixDQUFSO0FBQ0EsWUFBRyxPQUFPcUQsS0FBUCxJQUFpQixXQUFwQixFQUNDbkMsTUFBTUEsTUFBTSxNQUFaLENBREQsS0FHQ0EsTUFBTUEsTUFBTSxJQUFOLEdBQWFtQyxLQUFiLEdBQXFCLElBQTNCO0FBQ0QsT0FYRCxFQUQwQixDQWExQjs7O0FBQ0FuQyxZQUFNQSxNQUFNaUMsT0FBT0MsWUFBUCxDQUFvQixFQUFwQixDQUFOLEdBQWdDLElBQXRDO0FBQ0EsS0FmRDtBQWdCQTs7QUFFRCxTQUFPbEMsR0FBUDtBQUNBLENBNUREOztBQStEQSxLQUFLb0MsWUFBTCxHQUFvQixVQUFTQyxNQUFULEVBQWlCQyxNQUFqQixFQUF5QjtBQUU1Qzs7QUFHQSxNQUFHLE9BQU9ELE1BQVAsS0FBa0IsUUFBckIsRUFBK0I7QUFDOUJBLGFBQVMsRUFBVDtBQUNBOztBQUVELE9BQUksSUFBSUUsUUFBUixJQUFvQkQsTUFBcEIsRUFBNEI7QUFFM0IsUUFBR0EsT0FBT0UsY0FBUCxDQUFzQkQsUUFBdEIsQ0FBSCxFQUFvQztBQUVuQyxVQUFJRSxpQkFBaUJILE9BQVFDLFFBQVIsQ0FBckI7O0FBRUEsVUFBRyxPQUFPRSxjQUFQLEtBQTBCLFFBQTdCLEVBQXVDO0FBQ3RDSixlQUFPRSxRQUFQLElBQW1CSCxhQUFhQyxPQUFPRSxRQUFQLENBQWIsRUFBK0JFLGNBQS9CLENBQW5CO0FBQ0E7QUFDQTs7QUFFREosYUFBT0UsUUFBUCxJQUFtQkUsY0FBbkI7QUFDQTtBQUNEOztBQUVELE9BQUksSUFBSUMsSUFBSSxDQUFSLEVBQVdDLElBQUlDLFVBQVVuQyxNQUE3QixFQUFxQ2lDLElBQUlDLENBQXpDLEVBQTRDRCxHQUE1QyxFQUFpRDtBQUNoRE4saUJBQWFDLE1BQWIsRUFBcUJPLFVBQVVGLENBQVYsQ0FBckI7QUFDQTs7QUFFRCxTQUFPTCxNQUFQO0FBQ0EsQ0E3QkQsQzs7Ozs7Ozs7Ozs7QUM5R0EsS0FBS1EsV0FBTCxHQUFtQixVQUFVckUsTUFBVixFQUFrQjtBQUNwQyxTQUFPQSxPQUFPTSxPQUFQLENBQWUsNkJBQWYsRUFBOEMsTUFBOUMsQ0FBUDtBQUNBLENBRkQ7O0FBSUEsS0FBS2dFLGlCQUFMLEdBQXlCLFVBQVN0RSxNQUFULEVBQWlCdUUsSUFBakIsRUFBdUJqRSxPQUF2QixFQUFnQztBQUN4RCxTQUFPTixPQUFPTSxPQUFQLENBQWUsSUFBSWtFLE1BQUosQ0FBV0gsWUFBWUUsSUFBWixDQUFYLEVBQThCLEdBQTlCLENBQWYsRUFBbURqRSxPQUFuRCxDQUFQO0FBQ0EsQ0FGRDs7QUFJQSxLQUFLbUUsV0FBTCxHQUFtQixVQUFTQyxXQUFULEVBQXNCN0QsSUFBdEIsRUFBNEI7QUFDOUMsTUFBSThELE1BQU05RCxRQUFRLElBQWxCO0FBQ0EsTUFBSWtCLE1BQU0sRUFBVjs7QUFDQWtCLElBQUVDLElBQUYsQ0FBT3dCLFdBQVAsRUFBb0IsVUFBU2xELEdBQVQsRUFBYztBQUNqQyxRQUFHQSxHQUFILEVBQVE7QUFDUCxVQUFHTyxHQUFILEVBQ0NBLE1BQU1BLE1BQU00QyxHQUFaO0FBQ0Q1QyxZQUFNQSxNQUFNUCxHQUFaO0FBQ0E7QUFDRCxHQU5EOztBQU9BLFNBQU9PLEdBQVA7QUFDQSxDQVhEOztBQWFBLEtBQUs2QyxhQUFMLEdBQXFCLFVBQVNDLElBQVQsRUFBZTtBQUNsQyxTQUFPQSxLQUFLQyxRQUFMLEdBQWdCNUUsV0FBaEIsR0FDSkksT0FESSxDQUNJLE1BREosRUFDWSxHQURaLEVBQzJCO0FBRDNCLEdBRUpBLE9BRkksQ0FFSSxXQUZKLEVBRWlCLEVBRmpCLEVBRTJCO0FBRjNCLEdBR0pBLE9BSEksQ0FHSSxRQUhKLEVBR2MsR0FIZCxFQUcyQjtBQUgzQixHQUlKQSxPQUpJLENBSUksS0FKSixFQUlXLEVBSlgsRUFJMkI7QUFKM0IsR0FLSkEsT0FMSSxDQUtJLEtBTEosRUFLVyxFQUxYLENBQVAsQ0FEa0MsQ0FNQTtBQUNuQyxDQVBELEM7Ozs7Ozs7Ozs7O0FDckJBLEtBQUt5RSxZQUFMLEdBQW9CLElBQUlDLE1BQU1DLFVBQVYsQ0FBcUIsY0FBckIsQ0FBcEI7O0FBRUEsS0FBS0YsWUFBTCxDQUFrQkcsYUFBbEIsR0FBa0MsVUFBU0MsTUFBVCxFQUFpQmhDLEdBQWpCLEVBQXNCO0FBQ3ZELFNBQU8sSUFBUDtBQUNBLENBRkQ7O0FBSUEsS0FBSzRCLFlBQUwsQ0FBa0JLLGFBQWxCLEdBQWtDLFVBQVNELE1BQVQsRUFBaUJoQyxHQUFqQixFQUFzQjtBQUN2RCxTQUFPLElBQVA7QUFDQSxDQUZEOztBQUlBLEtBQUs0QixZQUFMLENBQWtCTSxhQUFsQixHQUFrQyxVQUFTRixNQUFULEVBQWlCaEMsR0FBakIsRUFBc0I7QUFDdkQsU0FBTyxJQUFQO0FBQ0EsQ0FGRCxDOzs7Ozs7Ozs7OztBQ1ZBLEtBQUttQyxVQUFMLEdBQWtCLElBQUlOLE1BQU1DLFVBQVYsQ0FBcUIsWUFBckIsQ0FBbEI7O0FBRUEsS0FBS0ssVUFBTCxDQUFnQkosYUFBaEIsR0FBZ0MsVUFBU0MsTUFBVCxFQUFpQmhDLEdBQWpCLEVBQXNCO0FBQ3JELFNBQU8sSUFBUDtBQUNBLENBRkQ7O0FBSUEsS0FBS21DLFVBQUwsQ0FBZ0JGLGFBQWhCLEdBQWdDLFVBQVNELE1BQVQsRUFBaUJoQyxHQUFqQixFQUFzQjtBQUNyRCxTQUFPLElBQVA7QUFDQSxDQUZEOztBQUlBLEtBQUttQyxVQUFMLENBQWdCRCxhQUFoQixHQUFnQyxVQUFTRixNQUFULEVBQWlCaEMsR0FBakIsRUFBc0I7QUFDckQsU0FBTyxJQUFQO0FBQ0EsQ0FGRCxDOzs7Ozs7Ozs7OztBQ1ZBLEtBQUtvQyxVQUFMLEdBQWtCLElBQUlQLE1BQU1DLFVBQVYsQ0FBcUIsWUFBckIsQ0FBbEI7O0FBRUEsS0FBS00sVUFBTCxDQUFnQkwsYUFBaEIsR0FBZ0MsVUFBU0MsTUFBVCxFQUFpQmhDLEdBQWpCLEVBQXNCO0FBQ3JELFNBQU8sSUFBUDtBQUNBLENBRkQ7O0FBSUEsS0FBS29DLFVBQUwsQ0FBZ0JILGFBQWhCLEdBQWdDLFVBQVNELE1BQVQsRUFBaUJoQyxHQUFqQixFQUFzQjtBQUNyRCxTQUFPLElBQVA7QUFDQSxDQUZEOztBQUlBLEtBQUtvQyxVQUFMLENBQWdCRixhQUFoQixHQUFnQyxVQUFTRixNQUFULEVBQWlCaEMsR0FBakIsRUFBc0I7QUFDckQsU0FBTyxJQUFQO0FBQ0EsQ0FGRCxDOzs7Ozs7Ozs7OztBQ1ZBLEtBQUtxQyxPQUFMLEdBQWUsSUFBSVIsTUFBTUMsVUFBVixDQUFxQixTQUFyQixDQUFmOztBQUVBLEtBQUtPLE9BQUwsQ0FBYU4sYUFBYixHQUE2QixVQUFTQyxNQUFULEVBQWlCaEMsR0FBakIsRUFBc0I7QUFDbEQsU0FBTyxJQUFQO0FBQ0EsQ0FGRDs7QUFJQSxLQUFLcUMsT0FBTCxDQUFhSixhQUFiLEdBQTZCLFVBQVNELE1BQVQsRUFBaUJoQyxHQUFqQixFQUFzQjtBQUNsRCxTQUFPLElBQVA7QUFDQSxDQUZEOztBQUlBLEtBQUtxQyxPQUFMLENBQWFILGFBQWIsR0FBNkIsVUFBU0YsTUFBVCxFQUFpQmhDLEdBQWpCLEVBQXNCO0FBQ2xELFNBQU8sSUFBUDtBQUNBLENBRkQsQzs7Ozs7Ozs7Ozs7QUNWQSxLQUFLc0MsWUFBTCxHQUFvQixJQUFJVCxNQUFNQyxVQUFWLENBQXFCLGVBQXJCLENBQXBCOztBQUVBLEtBQUtRLFlBQUwsQ0FBa0JQLGFBQWxCLEdBQWtDLFVBQVNDLE1BQVQsRUFBaUJoQyxHQUFqQixFQUFzQjtBQUN2RCxTQUFPLElBQVA7QUFDQSxDQUZEOztBQUlBLEtBQUtzQyxZQUFMLENBQWtCTCxhQUFsQixHQUFrQyxVQUFTRCxNQUFULEVBQWlCaEMsR0FBakIsRUFBc0I7QUFDdkQsU0FBTyxJQUFQO0FBQ0EsQ0FGRDs7QUFJQSxLQUFLc0MsWUFBTCxDQUFrQkosYUFBbEIsR0FBa0MsVUFBU0YsTUFBVCxFQUFpQmhDLEdBQWpCLEVBQXNCO0FBQ3ZELFNBQU8sSUFBUDtBQUNBLENBRkQsQzs7Ozs7Ozs7Ozs7QUNWQSxLQUFLdUMsV0FBTCxHQUFtQixJQUFJVixNQUFNQyxVQUFWLENBQXFCLGFBQXJCLENBQW5COztBQUVBLEtBQUtTLFdBQUwsQ0FBaUJSLGFBQWpCLEdBQWlDLFVBQVNDLE1BQVQsRUFBaUJoQyxHQUFqQixFQUFzQjtBQUN0RCxTQUFPLElBQVA7QUFDQSxDQUZEOztBQUlBLEtBQUt1QyxXQUFMLENBQWlCTixhQUFqQixHQUFpQyxVQUFTRCxNQUFULEVBQWlCaEMsR0FBakIsRUFBc0I7QUFDdEQsU0FBTyxJQUFQO0FBQ0EsQ0FGRDs7QUFJQSxLQUFLdUMsV0FBTCxDQUFpQkwsYUFBakIsR0FBaUMsVUFBU0YsTUFBVCxFQUFpQmhDLEdBQWpCLEVBQXNCO0FBQ3RELFNBQU8sSUFBUDtBQUNBLENBRkQsQzs7Ozs7Ozs7Ozs7QUNWQSxLQUFLd0MsU0FBTCxHQUFpQixJQUFJWCxNQUFNQyxVQUFWLENBQXFCLFdBQXJCLENBQWpCOztBQUVBLEtBQUtVLFNBQUwsQ0FBZVQsYUFBZixHQUErQixVQUFTQyxNQUFULEVBQWlCaEMsR0FBakIsRUFBc0I7QUFDcEQsU0FBTyxJQUFQO0FBQ0EsQ0FGRDs7QUFJQSxLQUFLd0MsU0FBTCxDQUFlUCxhQUFmLEdBQStCLFVBQVNELE1BQVQsRUFBaUJoQyxHQUFqQixFQUFzQjtBQUNwRCxTQUFPLElBQVA7QUFDQSxDQUZEOztBQUlBLEtBQUt3QyxTQUFMLENBQWVOLGFBQWYsR0FBK0IsVUFBU0YsTUFBVCxFQUFpQmhDLEdBQWpCLEVBQXNCO0FBQ3BELFNBQU8sSUFBUDtBQUNBLENBRkQsQzs7Ozs7Ozs7Ozs7QUNWQSxLQUFLeUMsYUFBTCxHQUFxQixJQUFJWixNQUFNQyxVQUFWLENBQXFCLGVBQXJCLENBQXJCOztBQUVBLEtBQUtXLGFBQUwsQ0FBbUJWLGFBQW5CLEdBQW1DLFVBQVNDLE1BQVQsRUFBaUJoQyxHQUFqQixFQUFzQjtBQUN4RCxTQUFPLElBQVA7QUFDQSxDQUZEOztBQUlBLEtBQUt5QyxhQUFMLENBQW1CUixhQUFuQixHQUFtQyxVQUFTRCxNQUFULEVBQWlCaEMsR0FBakIsRUFBc0I7QUFDeEQsU0FBTyxJQUFQO0FBQ0EsQ0FGRDs7QUFJQSxLQUFLeUMsYUFBTCxDQUFtQlAsYUFBbkIsR0FBbUMsVUFBU0YsTUFBVCxFQUFpQmhDLEdBQWpCLEVBQXNCO0FBQ3hELFNBQU8sSUFBUDtBQUNBLENBRkQsQzs7Ozs7Ozs7Ozs7QUNWQSxLQUFLMEMsa0JBQUwsR0FBMEIsSUFBSWIsTUFBTUMsVUFBVixDQUFxQixxQkFBckIsQ0FBMUI7O0FBRUEsS0FBS1ksa0JBQUwsQ0FBd0JYLGFBQXhCLEdBQXdDLFVBQVNDLE1BQVQsRUFBaUJoQyxHQUFqQixFQUFzQjtBQUM3RCxTQUFPLElBQVA7QUFDQSxDQUZEOztBQUlBLEtBQUswQyxrQkFBTCxDQUF3QlQsYUFBeEIsR0FBd0MsVUFBU0QsTUFBVCxFQUFpQmhDLEdBQWpCLEVBQXNCO0FBQzdELFNBQU8sSUFBUDtBQUNBLENBRkQ7O0FBSUEsS0FBSzBDLGtCQUFMLENBQXdCUixhQUF4QixHQUF3QyxVQUFTRixNQUFULEVBQWlCaEMsR0FBakIsRUFBc0I7QUFDN0QsU0FBTyxJQUFQO0FBQ0EsQ0FGRCxDOzs7Ozs7Ozs7OztBQ1ZBLEtBQUsyQyxhQUFMLEdBQXFCLElBQUlkLE1BQU1DLFVBQVYsQ0FBcUIsZUFBckIsQ0FBckI7O0FBRUEsS0FBS2EsYUFBTCxDQUFtQlosYUFBbkIsR0FBbUMsVUFBU0MsTUFBVCxFQUFpQmhDLEdBQWpCLEVBQXNCO0FBQ3hELFNBQU8sSUFBUDtBQUNBLENBRkQ7O0FBSUEsS0FBSzJDLGFBQUwsQ0FBbUJWLGFBQW5CLEdBQW1DLFVBQVNELE1BQVQsRUFBaUJoQyxHQUFqQixFQUFzQjtBQUN4RCxTQUFPLElBQVA7QUFDQSxDQUZEOztBQUlBLEtBQUsyQyxhQUFMLENBQW1CVCxhQUFuQixHQUFtQyxVQUFTRixNQUFULEVBQWlCaEMsR0FBakIsRUFBc0I7QUFDeEQsU0FBTyxJQUFQO0FBQ0EsQ0FGRCxDOzs7Ozs7Ozs7OztBQ1ZBNEIsYUFBYWdCLEtBQWIsQ0FBbUI7QUFDbEJDLFVBQVEsVUFBVWIsTUFBVixFQUFrQmhDLEdBQWxCLEVBQXVCO0FBQzlCLFdBQU8sS0FBUDtBQUNBLEdBSGlCO0FBS2xCOEMsVUFBUSxVQUFVZCxNQUFWLEVBQWtCaEMsR0FBbEIsRUFBdUIrQyxNQUF2QixFQUErQkMsUUFBL0IsRUFBeUM7QUFDaEQsV0FBTyxLQUFQO0FBQ0EsR0FQaUI7QUFTbEJDLFVBQVEsVUFBVWpCLE1BQVYsRUFBa0JoQyxHQUFsQixFQUF1QjtBQUM5QixXQUFPLEtBQVA7QUFDQTtBQVhpQixDQUFuQjtBQWNBNEIsYUFBYXNCLE1BQWIsQ0FBb0JMLE1BQXBCLENBQTJCLFVBQVNiLE1BQVQsRUFBaUJoQyxHQUFqQixFQUFzQjtBQUNoREEsTUFBSW1ELFNBQUosR0FBZ0IsSUFBSUMsSUFBSixFQUFoQjtBQUNBcEQsTUFBSXFELFNBQUosR0FBZ0JyQixNQUFoQjtBQUNBaEMsTUFBSXNELFVBQUosR0FBaUJ0RCxJQUFJbUQsU0FBckI7QUFDQW5ELE1BQUl1RCxVQUFKLEdBQWlCdkQsSUFBSXFELFNBQXJCO0FBR0EsTUFBRyxDQUFDckQsSUFBSXFELFNBQVIsRUFBbUJyRCxJQUFJcUQsU0FBSixHQUFnQnJCLE1BQWhCO0FBQ25CLENBUkQ7QUFVQUosYUFBYXNCLE1BQWIsQ0FBb0JKLE1BQXBCLENBQTJCLFVBQVNkLE1BQVQsRUFBaUJoQyxHQUFqQixFQUFzQndELFVBQXRCLEVBQWtDUixRQUFsQyxFQUE0Q1MsT0FBNUMsRUFBcUQ7QUFDL0VULFdBQVNVLElBQVQsR0FBZ0JWLFNBQVNVLElBQVQsSUFBaUIsRUFBakM7QUFDQVYsV0FBU1UsSUFBVCxDQUFjSixVQUFkLEdBQTJCLElBQUlGLElBQUosRUFBM0I7QUFDQUosV0FBU1UsSUFBVCxDQUFjSCxVQUFkLEdBQTJCdkIsTUFBM0I7QUFHQSxDQU5EO0FBUUFKLGFBQWFzQixNQUFiLENBQW9CUyxNQUFwQixDQUEyQixVQUFTM0IsTUFBVCxFQUFpQjRCLFFBQWpCLEVBQTJCWixRQUEzQixFQUFxQ1MsT0FBckMsRUFBOEM7QUFDeEVULFdBQVNVLElBQVQsR0FBZ0JWLFNBQVNVLElBQVQsSUFBaUIsRUFBakM7QUFDQVYsV0FBU1UsSUFBVCxDQUFjSixVQUFkLEdBQTJCLElBQUlGLElBQUosRUFBM0I7QUFDQUosV0FBU1UsSUFBVCxDQUFjSCxVQUFkLEdBQTJCdkIsTUFBM0I7QUFFQTtBQUNBLENBTkQ7QUFRQUosYUFBYXNCLE1BQWIsQ0FBb0JELE1BQXBCLENBQTJCLFVBQVNqQixNQUFULEVBQWlCaEMsR0FBakIsRUFBc0IsQ0FFaEQsQ0FGRDtBQUlBNEIsYUFBYWlDLEtBQWIsQ0FBbUJoQixNQUFuQixDQUEwQixVQUFTYixNQUFULEVBQWlCaEMsR0FBakIsRUFBc0IsQ0FFL0MsQ0FGRDtBQUlBNEIsYUFBYWlDLEtBQWIsQ0FBbUJmLE1BQW5CLENBQTBCLFVBQVNkLE1BQVQsRUFBaUJoQyxHQUFqQixFQUFzQndELFVBQXRCLEVBQWtDUixRQUFsQyxFQUE0Q1MsT0FBNUMsRUFBcUQsQ0FFOUUsQ0FGRDtBQUlBN0IsYUFBYWlDLEtBQWIsQ0FBbUJaLE1BQW5CLENBQTBCLFVBQVNqQixNQUFULEVBQWlCaEMsR0FBakIsRUFBc0IsQ0FFL0MsQ0FGRCxFOzs7Ozs7Ozs7OztBQ3BEQW1DLFdBQVdTLEtBQVgsQ0FBaUI7QUFDaEJDLFVBQVEsVUFBVWIsTUFBVixFQUFrQmhDLEdBQWxCLEVBQXVCO0FBQzlCLFdBQU8sS0FBUDtBQUNBLEdBSGU7QUFLaEI4QyxVQUFRLFVBQVVkLE1BQVYsRUFBa0JoQyxHQUFsQixFQUF1QitDLE1BQXZCLEVBQStCQyxRQUEvQixFQUF5QztBQUNoRCxXQUFPLEtBQVA7QUFDQSxHQVBlO0FBU2hCQyxVQUFRLFVBQVVqQixNQUFWLEVBQWtCaEMsR0FBbEIsRUFBdUI7QUFDOUIsV0FBTyxLQUFQO0FBQ0E7QUFYZSxDQUFqQjtBQWNBbUMsV0FBV2UsTUFBWCxDQUFrQkwsTUFBbEIsQ0FBeUIsVUFBU2IsTUFBVCxFQUFpQmhDLEdBQWpCLEVBQXNCO0FBQzlDQSxNQUFJbUQsU0FBSixHQUFnQixJQUFJQyxJQUFKLEVBQWhCO0FBQ0FwRCxNQUFJcUQsU0FBSixHQUFnQnJCLE1BQWhCO0FBQ0FoQyxNQUFJc0QsVUFBSixHQUFpQnRELElBQUltRCxTQUFyQjtBQUNBbkQsTUFBSXVELFVBQUosR0FBaUJ2RCxJQUFJcUQsU0FBckI7QUFHQSxNQUFHLENBQUNyRCxJQUFJcUQsU0FBUixFQUFtQnJELElBQUlxRCxTQUFKLEdBQWdCckIsTUFBaEI7QUFDbkIsQ0FSRDtBQVVBRyxXQUFXZSxNQUFYLENBQWtCSixNQUFsQixDQUF5QixVQUFTZCxNQUFULEVBQWlCaEMsR0FBakIsRUFBc0J3RCxVQUF0QixFQUFrQ1IsUUFBbEMsRUFBNENTLE9BQTVDLEVBQXFEO0FBQzdFVCxXQUFTVSxJQUFULEdBQWdCVixTQUFTVSxJQUFULElBQWlCLEVBQWpDO0FBQ0FWLFdBQVNVLElBQVQsQ0FBY0osVUFBZCxHQUEyQixJQUFJRixJQUFKLEVBQTNCO0FBQ0FKLFdBQVNVLElBQVQsQ0FBY0gsVUFBZCxHQUEyQnZCLE1BQTNCO0FBR0EsQ0FORDtBQVFBRyxXQUFXZSxNQUFYLENBQWtCUyxNQUFsQixDQUF5QixVQUFTM0IsTUFBVCxFQUFpQjRCLFFBQWpCLEVBQTJCWixRQUEzQixFQUFxQ1MsT0FBckMsRUFBOEM7QUFDdEVULFdBQVNVLElBQVQsR0FBZ0JWLFNBQVNVLElBQVQsSUFBaUIsRUFBakM7QUFDQVYsV0FBU1UsSUFBVCxDQUFjSixVQUFkLEdBQTJCLElBQUlGLElBQUosRUFBM0I7QUFDQUosV0FBU1UsSUFBVCxDQUFjSCxVQUFkLEdBQTJCdkIsTUFBM0I7QUFFQTtBQUNBLENBTkQ7QUFRQUcsV0FBV2UsTUFBWCxDQUFrQkQsTUFBbEIsQ0FBeUIsVUFBU2pCLE1BQVQsRUFBaUJoQyxHQUFqQixFQUFzQixDQUU5QyxDQUZEO0FBSUFtQyxXQUFXMEIsS0FBWCxDQUFpQmhCLE1BQWpCLENBQXdCLFVBQVNiLE1BQVQsRUFBaUJoQyxHQUFqQixFQUFzQixDQUU3QyxDQUZEO0FBSUFtQyxXQUFXMEIsS0FBWCxDQUFpQmYsTUFBakIsQ0FBd0IsVUFBU2QsTUFBVCxFQUFpQmhDLEdBQWpCLEVBQXNCd0QsVUFBdEIsRUFBa0NSLFFBQWxDLEVBQTRDUyxPQUE1QyxFQUFxRCxDQUU1RSxDQUZEO0FBSUF0QixXQUFXMEIsS0FBWCxDQUFpQlosTUFBakIsQ0FBd0IsVUFBU2pCLE1BQVQsRUFBaUJoQyxHQUFqQixFQUFzQixDQUU3QyxDQUZELEU7Ozs7Ozs7Ozs7O0FDcERBb0MsV0FBV1EsS0FBWCxDQUFpQjtBQUNoQkMsVUFBUSxVQUFVYixNQUFWLEVBQWtCaEMsR0FBbEIsRUFBdUI7QUFDOUIsV0FBTyxLQUFQO0FBQ0EsR0FIZTtBQUtoQjhDLFVBQVEsVUFBVWQsTUFBVixFQUFrQmhDLEdBQWxCLEVBQXVCK0MsTUFBdkIsRUFBK0JDLFFBQS9CLEVBQXlDO0FBQ2hELFdBQU8sS0FBUDtBQUNBLEdBUGU7QUFTaEJDLFVBQVEsVUFBVWpCLE1BQVYsRUFBa0JoQyxHQUFsQixFQUF1QjtBQUM5QixXQUFPLEtBQVA7QUFDQTtBQVhlLENBQWpCO0FBY0FvQyxXQUFXYyxNQUFYLENBQWtCTCxNQUFsQixDQUF5QixVQUFTYixNQUFULEVBQWlCaEMsR0FBakIsRUFBc0I7QUFDOUNBLE1BQUltRCxTQUFKLEdBQWdCLElBQUlDLElBQUosRUFBaEI7QUFDQXBELE1BQUlxRCxTQUFKLEdBQWdCckIsTUFBaEI7QUFDQWhDLE1BQUlzRCxVQUFKLEdBQWlCdEQsSUFBSW1ELFNBQXJCO0FBQ0FuRCxNQUFJdUQsVUFBSixHQUFpQnZELElBQUlxRCxTQUFyQjtBQUdBLE1BQUcsQ0FBQ3JELElBQUlxRCxTQUFSLEVBQW1CckQsSUFBSXFELFNBQUosR0FBZ0JyQixNQUFoQjtBQUNuQixDQVJEO0FBVUFJLFdBQVdjLE1BQVgsQ0FBa0JKLE1BQWxCLENBQXlCLFVBQVNkLE1BQVQsRUFBaUJoQyxHQUFqQixFQUFzQndELFVBQXRCLEVBQWtDUixRQUFsQyxFQUE0Q1MsT0FBNUMsRUFBcUQ7QUFDN0VULFdBQVNVLElBQVQsR0FBZ0JWLFNBQVNVLElBQVQsSUFBaUIsRUFBakM7QUFDQVYsV0FBU1UsSUFBVCxDQUFjSixVQUFkLEdBQTJCLElBQUlGLElBQUosRUFBM0I7QUFDQUosV0FBU1UsSUFBVCxDQUFjSCxVQUFkLEdBQTJCdkIsTUFBM0I7QUFHQSxDQU5EO0FBUUFJLFdBQVdjLE1BQVgsQ0FBa0JTLE1BQWxCLENBQXlCLFVBQVMzQixNQUFULEVBQWlCNEIsUUFBakIsRUFBMkJaLFFBQTNCLEVBQXFDUyxPQUFyQyxFQUE4QztBQUN0RVQsV0FBU1UsSUFBVCxHQUFnQlYsU0FBU1UsSUFBVCxJQUFpQixFQUFqQztBQUNBVixXQUFTVSxJQUFULENBQWNKLFVBQWQsR0FBMkIsSUFBSUYsSUFBSixFQUEzQjtBQUNBSixXQUFTVSxJQUFULENBQWNILFVBQWQsR0FBMkJ2QixNQUEzQjtBQUVBO0FBQ0EsQ0FORDtBQVFBSSxXQUFXYyxNQUFYLENBQWtCRCxNQUFsQixDQUF5QixVQUFTakIsTUFBVCxFQUFpQmhDLEdBQWpCLEVBQXNCLENBRTlDLENBRkQ7QUFJQW9DLFdBQVd5QixLQUFYLENBQWlCaEIsTUFBakIsQ0FBd0IsVUFBU2IsTUFBVCxFQUFpQmhDLEdBQWpCLEVBQXNCLENBRTdDLENBRkQ7QUFJQW9DLFdBQVd5QixLQUFYLENBQWlCZixNQUFqQixDQUF3QixVQUFTZCxNQUFULEVBQWlCaEMsR0FBakIsRUFBc0J3RCxVQUF0QixFQUFrQ1IsUUFBbEMsRUFBNENTLE9BQTVDLEVBQXFELENBRTVFLENBRkQ7QUFJQXJCLFdBQVd5QixLQUFYLENBQWlCWixNQUFqQixDQUF3QixVQUFTakIsTUFBVCxFQUFpQmhDLEdBQWpCLEVBQXNCLENBRTdDLENBRkQsRTs7Ozs7Ozs7Ozs7QUNwREFxQyxRQUFRTyxLQUFSLENBQWM7QUFDYkMsVUFBUSxVQUFVYixNQUFWLEVBQWtCaEMsR0FBbEIsRUFBdUI7QUFDOUIsV0FBTyxLQUFQO0FBQ0EsR0FIWTtBQUtiOEMsVUFBUSxVQUFVZCxNQUFWLEVBQWtCaEMsR0FBbEIsRUFBdUIrQyxNQUF2QixFQUErQkMsUUFBL0IsRUFBeUM7QUFDaEQsV0FBTyxLQUFQO0FBQ0EsR0FQWTtBQVNiQyxVQUFRLFVBQVVqQixNQUFWLEVBQWtCaEMsR0FBbEIsRUFBdUI7QUFDOUIsV0FBTyxLQUFQO0FBQ0E7QUFYWSxDQUFkO0FBY0FxQyxRQUFRYSxNQUFSLENBQWVMLE1BQWYsQ0FBc0IsVUFBU2IsTUFBVCxFQUFpQmhDLEdBQWpCLEVBQXNCO0FBQzNDQSxNQUFJbUQsU0FBSixHQUFnQixJQUFJQyxJQUFKLEVBQWhCO0FBQ0FwRCxNQUFJcUQsU0FBSixHQUFnQnJCLE1BQWhCO0FBQ0FoQyxNQUFJc0QsVUFBSixHQUFpQnRELElBQUltRCxTQUFyQjtBQUNBbkQsTUFBSXVELFVBQUosR0FBaUJ2RCxJQUFJcUQsU0FBckI7QUFHQSxNQUFHLENBQUNyRCxJQUFJcUQsU0FBUixFQUFtQnJELElBQUlxRCxTQUFKLEdBQWdCckIsTUFBaEI7QUFDbkIsQ0FSRDtBQVVBSyxRQUFRYSxNQUFSLENBQWVKLE1BQWYsQ0FBc0IsVUFBU2QsTUFBVCxFQUFpQmhDLEdBQWpCLEVBQXNCd0QsVUFBdEIsRUFBa0NSLFFBQWxDLEVBQTRDUyxPQUE1QyxFQUFxRDtBQUMxRVQsV0FBU1UsSUFBVCxHQUFnQlYsU0FBU1UsSUFBVCxJQUFpQixFQUFqQztBQUNBVixXQUFTVSxJQUFULENBQWNKLFVBQWQsR0FBMkIsSUFBSUYsSUFBSixFQUEzQjtBQUNBSixXQUFTVSxJQUFULENBQWNILFVBQWQsR0FBMkJ2QixNQUEzQjtBQUdBLENBTkQ7QUFRQUssUUFBUWEsTUFBUixDQUFlUyxNQUFmLENBQXNCLFVBQVMzQixNQUFULEVBQWlCNEIsUUFBakIsRUFBMkJaLFFBQTNCLEVBQXFDUyxPQUFyQyxFQUE4QztBQUNuRVQsV0FBU1UsSUFBVCxHQUFnQlYsU0FBU1UsSUFBVCxJQUFpQixFQUFqQztBQUNBVixXQUFTVSxJQUFULENBQWNKLFVBQWQsR0FBMkIsSUFBSUYsSUFBSixFQUEzQjtBQUNBSixXQUFTVSxJQUFULENBQWNILFVBQWQsR0FBMkJ2QixNQUEzQjtBQUVBO0FBQ0EsQ0FORDtBQVFBSyxRQUFRYSxNQUFSLENBQWVELE1BQWYsQ0FBc0IsVUFBU2pCLE1BQVQsRUFBaUJoQyxHQUFqQixFQUFzQixDQUUzQyxDQUZEO0FBSUFxQyxRQUFRd0IsS0FBUixDQUFjaEIsTUFBZCxDQUFxQixVQUFTYixNQUFULEVBQWlCaEMsR0FBakIsRUFBc0IsQ0FFMUMsQ0FGRDtBQUlBcUMsUUFBUXdCLEtBQVIsQ0FBY2YsTUFBZCxDQUFxQixVQUFTZCxNQUFULEVBQWlCaEMsR0FBakIsRUFBc0J3RCxVQUF0QixFQUFrQ1IsUUFBbEMsRUFBNENTLE9BQTVDLEVBQXFELENBRXpFLENBRkQ7QUFJQXBCLFFBQVF3QixLQUFSLENBQWNaLE1BQWQsQ0FBcUIsVUFBU2pCLE1BQVQsRUFBaUJoQyxHQUFqQixFQUFzQixDQUUxQyxDQUZELEU7Ozs7Ozs7Ozs7O0FDcERBc0MsYUFBYU0sS0FBYixDQUFtQjtBQUNsQkMsVUFBUSxVQUFVYixNQUFWLEVBQWtCaEMsR0FBbEIsRUFBdUI7QUFDOUIsV0FBTyxLQUFQO0FBQ0EsR0FIaUI7QUFLbEI4QyxVQUFRLFVBQVVkLE1BQVYsRUFBa0JoQyxHQUFsQixFQUF1QitDLE1BQXZCLEVBQStCQyxRQUEvQixFQUF5QztBQUNoRCxXQUFPLEtBQVA7QUFDQSxHQVBpQjtBQVNsQkMsVUFBUSxVQUFVakIsTUFBVixFQUFrQmhDLEdBQWxCLEVBQXVCO0FBQzlCLFdBQU8sS0FBUDtBQUNBO0FBWGlCLENBQW5CO0FBY0FzQyxhQUFhWSxNQUFiLENBQW9CTCxNQUFwQixDQUEyQixVQUFTYixNQUFULEVBQWlCaEMsR0FBakIsRUFBc0I7QUFDaERBLE1BQUltRCxTQUFKLEdBQWdCLElBQUlDLElBQUosRUFBaEI7QUFDQXBELE1BQUlxRCxTQUFKLEdBQWdCckIsTUFBaEI7QUFDQWhDLE1BQUlzRCxVQUFKLEdBQWlCdEQsSUFBSW1ELFNBQXJCO0FBQ0FuRCxNQUFJdUQsVUFBSixHQUFpQnZELElBQUlxRCxTQUFyQjtBQUdBLE1BQUcsQ0FBQ3JELElBQUlxRCxTQUFSLEVBQW1CckQsSUFBSXFELFNBQUosR0FBZ0JyQixNQUFoQjtBQUNuQixDQVJEO0FBVUFNLGFBQWFZLE1BQWIsQ0FBb0JKLE1BQXBCLENBQTJCLFVBQVNkLE1BQVQsRUFBaUJoQyxHQUFqQixFQUFzQndELFVBQXRCLEVBQWtDUixRQUFsQyxFQUE0Q1MsT0FBNUMsRUFBcUQ7QUFDL0VULFdBQVNVLElBQVQsR0FBZ0JWLFNBQVNVLElBQVQsSUFBaUIsRUFBakM7QUFDQVYsV0FBU1UsSUFBVCxDQUFjSixVQUFkLEdBQTJCLElBQUlGLElBQUosRUFBM0I7QUFDQUosV0FBU1UsSUFBVCxDQUFjSCxVQUFkLEdBQTJCdkIsTUFBM0I7QUFHQSxDQU5EO0FBUUFNLGFBQWFZLE1BQWIsQ0FBb0JTLE1BQXBCLENBQTJCLFVBQVMzQixNQUFULEVBQWlCNEIsUUFBakIsRUFBMkJaLFFBQTNCLEVBQXFDUyxPQUFyQyxFQUE4QztBQUN4RVQsV0FBU1UsSUFBVCxHQUFnQlYsU0FBU1UsSUFBVCxJQUFpQixFQUFqQztBQUNBVixXQUFTVSxJQUFULENBQWNKLFVBQWQsR0FBMkIsSUFBSUYsSUFBSixFQUEzQjtBQUNBSixXQUFTVSxJQUFULENBQWNILFVBQWQsR0FBMkJ2QixNQUEzQjtBQUVBO0FBQ0EsQ0FORDtBQVFBTSxhQUFhWSxNQUFiLENBQW9CRCxNQUFwQixDQUEyQixVQUFTakIsTUFBVCxFQUFpQmhDLEdBQWpCLEVBQXNCLENBRWhELENBRkQ7QUFJQXNDLGFBQWF1QixLQUFiLENBQW1CaEIsTUFBbkIsQ0FBMEIsVUFBU2IsTUFBVCxFQUFpQmhDLEdBQWpCLEVBQXNCLENBRS9DLENBRkQ7QUFJQXNDLGFBQWF1QixLQUFiLENBQW1CZixNQUFuQixDQUEwQixVQUFTZCxNQUFULEVBQWlCaEMsR0FBakIsRUFBc0J3RCxVQUF0QixFQUFrQ1IsUUFBbEMsRUFBNENTLE9BQTVDLEVBQXFELENBRTlFLENBRkQ7QUFJQW5CLGFBQWF1QixLQUFiLENBQW1CWixNQUFuQixDQUEwQixVQUFTakIsTUFBVCxFQUFpQmhDLEdBQWpCLEVBQXNCLENBRS9DLENBRkQsRTs7Ozs7Ozs7Ozs7QUNwREF1QyxZQUFZSyxLQUFaLENBQWtCO0FBQ2pCQyxVQUFRLFVBQVViLE1BQVYsRUFBa0JoQyxHQUFsQixFQUF1QjtBQUM5QixXQUFPLEtBQVA7QUFDQSxHQUhnQjtBQUtqQjhDLFVBQVEsVUFBVWQsTUFBVixFQUFrQmhDLEdBQWxCLEVBQXVCK0MsTUFBdkIsRUFBK0JDLFFBQS9CLEVBQXlDO0FBQ2hELFdBQU8sS0FBUDtBQUNBLEdBUGdCO0FBU2pCQyxVQUFRLFVBQVVqQixNQUFWLEVBQWtCaEMsR0FBbEIsRUFBdUI7QUFDOUIsV0FBTyxLQUFQO0FBQ0E7QUFYZ0IsQ0FBbEI7QUFjQXVDLFlBQVlXLE1BQVosQ0FBbUJMLE1BQW5CLENBQTBCLFVBQVNiLE1BQVQsRUFBaUJoQyxHQUFqQixFQUFzQjtBQUMvQ0EsTUFBSW1ELFNBQUosR0FBZ0IsSUFBSUMsSUFBSixFQUFoQjtBQUNBcEQsTUFBSXFELFNBQUosR0FBZ0JyQixNQUFoQjtBQUNBaEMsTUFBSXNELFVBQUosR0FBaUJ0RCxJQUFJbUQsU0FBckI7QUFDQW5ELE1BQUl1RCxVQUFKLEdBQWlCdkQsSUFBSXFELFNBQXJCO0FBR0EsTUFBRyxDQUFDckQsSUFBSXFELFNBQVIsRUFBbUJyRCxJQUFJcUQsU0FBSixHQUFnQnJCLE1BQWhCO0FBQ25CLENBUkQ7QUFVQU8sWUFBWVcsTUFBWixDQUFtQkosTUFBbkIsQ0FBMEIsVUFBU2QsTUFBVCxFQUFpQmhDLEdBQWpCLEVBQXNCd0QsVUFBdEIsRUFBa0NSLFFBQWxDLEVBQTRDUyxPQUE1QyxFQUFxRDtBQUM5RVQsV0FBU1UsSUFBVCxHQUFnQlYsU0FBU1UsSUFBVCxJQUFpQixFQUFqQztBQUNBVixXQUFTVSxJQUFULENBQWNKLFVBQWQsR0FBMkIsSUFBSUYsSUFBSixFQUEzQjtBQUNBSixXQUFTVSxJQUFULENBQWNILFVBQWQsR0FBMkJ2QixNQUEzQjtBQUdBLENBTkQ7QUFRQU8sWUFBWVcsTUFBWixDQUFtQlMsTUFBbkIsQ0FBMEIsVUFBUzNCLE1BQVQsRUFBaUI0QixRQUFqQixFQUEyQlosUUFBM0IsRUFBcUNTLE9BQXJDLEVBQThDO0FBQ3ZFVCxXQUFTVSxJQUFULEdBQWdCVixTQUFTVSxJQUFULElBQWlCLEVBQWpDO0FBQ0FWLFdBQVNVLElBQVQsQ0FBY0osVUFBZCxHQUEyQixJQUFJRixJQUFKLEVBQTNCO0FBQ0FKLFdBQVNVLElBQVQsQ0FBY0gsVUFBZCxHQUEyQnZCLE1BQTNCO0FBRUE7QUFDQSxDQU5EO0FBUUFPLFlBQVlXLE1BQVosQ0FBbUJELE1BQW5CLENBQTBCLFVBQVNqQixNQUFULEVBQWlCaEMsR0FBakIsRUFBc0IsQ0FFL0MsQ0FGRDtBQUlBdUMsWUFBWXNCLEtBQVosQ0FBa0JoQixNQUFsQixDQUF5QixVQUFTYixNQUFULEVBQWlCaEMsR0FBakIsRUFBc0IsQ0FFOUMsQ0FGRDtBQUlBdUMsWUFBWXNCLEtBQVosQ0FBa0JmLE1BQWxCLENBQXlCLFVBQVNkLE1BQVQsRUFBaUJoQyxHQUFqQixFQUFzQndELFVBQXRCLEVBQWtDUixRQUFsQyxFQUE0Q1MsT0FBNUMsRUFBcUQsQ0FFN0UsQ0FGRDtBQUlBbEIsWUFBWXNCLEtBQVosQ0FBa0JaLE1BQWxCLENBQXlCLFVBQVNqQixNQUFULEVBQWlCaEMsR0FBakIsRUFBc0IsQ0FFOUMsQ0FGRCxFOzs7Ozs7Ozs7OztBQ3BEQXdDLFVBQVVJLEtBQVYsQ0FBZ0I7QUFDZkMsVUFBUSxVQUFVYixNQUFWLEVBQWtCaEMsR0FBbEIsRUFBdUI7QUFDOUIsV0FBTyxLQUFQO0FBQ0EsR0FIYztBQUtmOEMsVUFBUSxVQUFVZCxNQUFWLEVBQWtCaEMsR0FBbEIsRUFBdUIrQyxNQUF2QixFQUErQkMsUUFBL0IsRUFBeUM7QUFDaEQsV0FBTyxLQUFQO0FBQ0EsR0FQYztBQVNmQyxVQUFRLFVBQVVqQixNQUFWLEVBQWtCaEMsR0FBbEIsRUFBdUI7QUFDOUIsV0FBTyxLQUFQO0FBQ0E7QUFYYyxDQUFoQjtBQWNBd0MsVUFBVVUsTUFBVixDQUFpQkwsTUFBakIsQ0FBd0IsVUFBU2IsTUFBVCxFQUFpQmhDLEdBQWpCLEVBQXNCO0FBQzdDQSxNQUFJbUQsU0FBSixHQUFnQixJQUFJQyxJQUFKLEVBQWhCO0FBQ0FwRCxNQUFJcUQsU0FBSixHQUFnQnJCLE1BQWhCO0FBQ0FoQyxNQUFJc0QsVUFBSixHQUFpQnRELElBQUltRCxTQUFyQjtBQUNBbkQsTUFBSXVELFVBQUosR0FBaUJ2RCxJQUFJcUQsU0FBckI7QUFHQSxNQUFHLENBQUNyRCxJQUFJcUQsU0FBUixFQUFtQnJELElBQUlxRCxTQUFKLEdBQWdCckIsTUFBaEI7QUFDbkIsQ0FSRDtBQVVBUSxVQUFVVSxNQUFWLENBQWlCSixNQUFqQixDQUF3QixVQUFTZCxNQUFULEVBQWlCaEMsR0FBakIsRUFBc0J3RCxVQUF0QixFQUFrQ1IsUUFBbEMsRUFBNENTLE9BQTVDLEVBQXFEO0FBQzVFVCxXQUFTVSxJQUFULEdBQWdCVixTQUFTVSxJQUFULElBQWlCLEVBQWpDO0FBQ0FWLFdBQVNVLElBQVQsQ0FBY0osVUFBZCxHQUEyQixJQUFJRixJQUFKLEVBQTNCO0FBQ0FKLFdBQVNVLElBQVQsQ0FBY0gsVUFBZCxHQUEyQnZCLE1BQTNCO0FBR0EsQ0FORDtBQVFBUSxVQUFVVSxNQUFWLENBQWlCUyxNQUFqQixDQUF3QixVQUFTM0IsTUFBVCxFQUFpQjRCLFFBQWpCLEVBQTJCWixRQUEzQixFQUFxQ1MsT0FBckMsRUFBOEM7QUFDckVULFdBQVNVLElBQVQsR0FBZ0JWLFNBQVNVLElBQVQsSUFBaUIsRUFBakM7QUFDQVYsV0FBU1UsSUFBVCxDQUFjSixVQUFkLEdBQTJCLElBQUlGLElBQUosRUFBM0I7QUFDQUosV0FBU1UsSUFBVCxDQUFjSCxVQUFkLEdBQTJCdkIsTUFBM0I7QUFFQTtBQUNBLENBTkQ7QUFRQVEsVUFBVVUsTUFBVixDQUFpQkQsTUFBakIsQ0FBd0IsVUFBU2pCLE1BQVQsRUFBaUJoQyxHQUFqQixFQUFzQixDQUU3QyxDQUZEO0FBSUF3QyxVQUFVcUIsS0FBVixDQUFnQmhCLE1BQWhCLENBQXVCLFVBQVNiLE1BQVQsRUFBaUJoQyxHQUFqQixFQUFzQixDQUU1QyxDQUZEO0FBSUF3QyxVQUFVcUIsS0FBVixDQUFnQmYsTUFBaEIsQ0FBdUIsVUFBU2QsTUFBVCxFQUFpQmhDLEdBQWpCLEVBQXNCd0QsVUFBdEIsRUFBa0NSLFFBQWxDLEVBQTRDUyxPQUE1QyxFQUFxRCxDQUUzRSxDQUZEO0FBSUFqQixVQUFVcUIsS0FBVixDQUFnQlosTUFBaEIsQ0FBdUIsVUFBU2pCLE1BQVQsRUFBaUJoQyxHQUFqQixFQUFzQixDQUU1QyxDQUZELEU7Ozs7Ozs7Ozs7O0FDcERBeUMsY0FBY0csS0FBZCxDQUFvQjtBQUNuQkMsVUFBUSxVQUFVYixNQUFWLEVBQWtCaEMsR0FBbEIsRUFBdUI7QUFDOUIsV0FBTyxLQUFQO0FBQ0EsR0FIa0I7QUFLbkI4QyxVQUFRLFVBQVVkLE1BQVYsRUFBa0JoQyxHQUFsQixFQUF1QitDLE1BQXZCLEVBQStCQyxRQUEvQixFQUF5QztBQUNoRCxXQUFPLEtBQVA7QUFDQSxHQVBrQjtBQVNuQkMsVUFBUSxVQUFVakIsTUFBVixFQUFrQmhDLEdBQWxCLEVBQXVCO0FBQzlCLFdBQU8sS0FBUDtBQUNBO0FBWGtCLENBQXBCO0FBY0F5QyxjQUFjUyxNQUFkLENBQXFCTCxNQUFyQixDQUE0QixVQUFTYixNQUFULEVBQWlCaEMsR0FBakIsRUFBc0I7QUFDakRBLE1BQUltRCxTQUFKLEdBQWdCLElBQUlDLElBQUosRUFBaEI7QUFDQXBELE1BQUlxRCxTQUFKLEdBQWdCckIsTUFBaEI7QUFDQWhDLE1BQUlzRCxVQUFKLEdBQWlCdEQsSUFBSW1ELFNBQXJCO0FBQ0FuRCxNQUFJdUQsVUFBSixHQUFpQnZELElBQUlxRCxTQUFyQjtBQUdBLE1BQUcsQ0FBQ3JELElBQUlxRCxTQUFSLEVBQW1CckQsSUFBSXFELFNBQUosR0FBZ0JyQixNQUFoQjtBQUNuQixDQVJEO0FBVUFTLGNBQWNTLE1BQWQsQ0FBcUJKLE1BQXJCLENBQTRCLFVBQVNkLE1BQVQsRUFBaUJoQyxHQUFqQixFQUFzQndELFVBQXRCLEVBQWtDUixRQUFsQyxFQUE0Q1MsT0FBNUMsRUFBcUQ7QUFDaEZULFdBQVNVLElBQVQsR0FBZ0JWLFNBQVNVLElBQVQsSUFBaUIsRUFBakM7QUFDQVYsV0FBU1UsSUFBVCxDQUFjSixVQUFkLEdBQTJCLElBQUlGLElBQUosRUFBM0I7QUFDQUosV0FBU1UsSUFBVCxDQUFjSCxVQUFkLEdBQTJCdkIsTUFBM0I7QUFHQSxDQU5EO0FBUUFTLGNBQWNTLE1BQWQsQ0FBcUJTLE1BQXJCLENBQTRCLFVBQVMzQixNQUFULEVBQWlCNEIsUUFBakIsRUFBMkJaLFFBQTNCLEVBQXFDUyxPQUFyQyxFQUE4QztBQUN6RVQsV0FBU1UsSUFBVCxHQUFnQlYsU0FBU1UsSUFBVCxJQUFpQixFQUFqQztBQUNBVixXQUFTVSxJQUFULENBQWNKLFVBQWQsR0FBMkIsSUFBSUYsSUFBSixFQUEzQjtBQUNBSixXQUFTVSxJQUFULENBQWNILFVBQWQsR0FBMkJ2QixNQUEzQjtBQUVBO0FBQ0EsQ0FORDtBQVFBUyxjQUFjUyxNQUFkLENBQXFCRCxNQUFyQixDQUE0QixVQUFTakIsTUFBVCxFQUFpQmhDLEdBQWpCLEVBQXNCLENBRWpELENBRkQ7QUFJQXlDLGNBQWNvQixLQUFkLENBQW9CaEIsTUFBcEIsQ0FBMkIsVUFBU2IsTUFBVCxFQUFpQmhDLEdBQWpCLEVBQXNCLENBRWhELENBRkQ7QUFJQXlDLGNBQWNvQixLQUFkLENBQW9CZixNQUFwQixDQUEyQixVQUFTZCxNQUFULEVBQWlCaEMsR0FBakIsRUFBc0J3RCxVQUF0QixFQUFrQ1IsUUFBbEMsRUFBNENTLE9BQTVDLEVBQXFELENBRS9FLENBRkQ7QUFJQWhCLGNBQWNvQixLQUFkLENBQW9CWixNQUFwQixDQUEyQixVQUFTakIsTUFBVCxFQUFpQmhDLEdBQWpCLEVBQXNCLENBRWhELENBRkQsRTs7Ozs7Ozs7Ozs7QUNwREEwQyxtQkFBbUJFLEtBQW5CLENBQXlCO0FBQ3hCQyxVQUFRLFVBQVViLE1BQVYsRUFBa0JoQyxHQUFsQixFQUF1QjtBQUM5QixXQUFPLEtBQVA7QUFDQSxHQUh1QjtBQUt4QjhDLFVBQVEsVUFBVWQsTUFBVixFQUFrQmhDLEdBQWxCLEVBQXVCK0MsTUFBdkIsRUFBK0JDLFFBQS9CLEVBQXlDO0FBQ2hELFdBQU8sS0FBUDtBQUNBLEdBUHVCO0FBU3hCQyxVQUFRLFVBQVVqQixNQUFWLEVBQWtCaEMsR0FBbEIsRUFBdUI7QUFDOUIsV0FBTyxLQUFQO0FBQ0E7QUFYdUIsQ0FBekI7QUFjQTBDLG1CQUFtQlEsTUFBbkIsQ0FBMEJMLE1BQTFCLENBQWlDLFVBQVNiLE1BQVQsRUFBaUJoQyxHQUFqQixFQUFzQjtBQUN0REEsTUFBSW1ELFNBQUosR0FBZ0IsSUFBSUMsSUFBSixFQUFoQjtBQUNBcEQsTUFBSXFELFNBQUosR0FBZ0JyQixNQUFoQjtBQUNBaEMsTUFBSXNELFVBQUosR0FBaUJ0RCxJQUFJbUQsU0FBckI7QUFDQW5ELE1BQUl1RCxVQUFKLEdBQWlCdkQsSUFBSXFELFNBQXJCO0FBR0EsTUFBRyxDQUFDckQsSUFBSXFELFNBQVIsRUFBbUJyRCxJQUFJcUQsU0FBSixHQUFnQnJCLE1BQWhCO0FBQ25CLENBUkQ7QUFVQVUsbUJBQW1CUSxNQUFuQixDQUEwQkosTUFBMUIsQ0FBaUMsVUFBU2QsTUFBVCxFQUFpQmhDLEdBQWpCLEVBQXNCd0QsVUFBdEIsRUFBa0NSLFFBQWxDLEVBQTRDUyxPQUE1QyxFQUFxRDtBQUNyRlQsV0FBU1UsSUFBVCxHQUFnQlYsU0FBU1UsSUFBVCxJQUFpQixFQUFqQztBQUNBVixXQUFTVSxJQUFULENBQWNKLFVBQWQsR0FBMkIsSUFBSUYsSUFBSixFQUEzQjtBQUNBSixXQUFTVSxJQUFULENBQWNILFVBQWQsR0FBMkJ2QixNQUEzQjtBQUdBLENBTkQ7QUFRQVUsbUJBQW1CUSxNQUFuQixDQUEwQlMsTUFBMUIsQ0FBaUMsVUFBUzNCLE1BQVQsRUFBaUI0QixRQUFqQixFQUEyQlosUUFBM0IsRUFBcUNTLE9BQXJDLEVBQThDO0FBQzlFVCxXQUFTVSxJQUFULEdBQWdCVixTQUFTVSxJQUFULElBQWlCLEVBQWpDO0FBQ0FWLFdBQVNVLElBQVQsQ0FBY0osVUFBZCxHQUEyQixJQUFJRixJQUFKLEVBQTNCO0FBQ0FKLFdBQVNVLElBQVQsQ0FBY0gsVUFBZCxHQUEyQnZCLE1BQTNCO0FBRUE7QUFDQSxDQU5EO0FBUUFVLG1CQUFtQlEsTUFBbkIsQ0FBMEJELE1BQTFCLENBQWlDLFVBQVNqQixNQUFULEVBQWlCaEMsR0FBakIsRUFBc0IsQ0FFdEQsQ0FGRDtBQUlBMEMsbUJBQW1CbUIsS0FBbkIsQ0FBeUJoQixNQUF6QixDQUFnQyxVQUFTYixNQUFULEVBQWlCaEMsR0FBakIsRUFBc0IsQ0FFckQsQ0FGRDtBQUlBMEMsbUJBQW1CbUIsS0FBbkIsQ0FBeUJmLE1BQXpCLENBQWdDLFVBQVNkLE1BQVQsRUFBaUJoQyxHQUFqQixFQUFzQndELFVBQXRCLEVBQWtDUixRQUFsQyxFQUE0Q1MsT0FBNUMsRUFBcUQsQ0FFcEYsQ0FGRDtBQUlBZixtQkFBbUJtQixLQUFuQixDQUF5QlosTUFBekIsQ0FBZ0MsVUFBU2pCLE1BQVQsRUFBaUJoQyxHQUFqQixFQUFzQixDQUVyRCxDQUZELEU7Ozs7Ozs7Ozs7O0FDcERBMkMsY0FBY0MsS0FBZCxDQUFvQjtBQUNuQkMsVUFBUSxVQUFVYixNQUFWLEVBQWtCaEMsR0FBbEIsRUFBdUI7QUFDOUIsV0FBTyxLQUFQO0FBQ0EsR0FIa0I7QUFLbkI4QyxVQUFRLFVBQVVkLE1BQVYsRUFBa0JoQyxHQUFsQixFQUF1QitDLE1BQXZCLEVBQStCQyxRQUEvQixFQUF5QztBQUNoRCxXQUFPLEtBQVA7QUFDQSxHQVBrQjtBQVNuQkMsVUFBUSxVQUFVakIsTUFBVixFQUFrQmhDLEdBQWxCLEVBQXVCO0FBQzlCLFdBQU8sS0FBUDtBQUNBO0FBWGtCLENBQXBCO0FBY0EyQyxjQUFjTyxNQUFkLENBQXFCTCxNQUFyQixDQUE0QixVQUFTYixNQUFULEVBQWlCaEMsR0FBakIsRUFBc0I7QUFDakRBLE1BQUltRCxTQUFKLEdBQWdCLElBQUlDLElBQUosRUFBaEI7QUFDQXBELE1BQUlxRCxTQUFKLEdBQWdCckIsTUFBaEI7QUFDQWhDLE1BQUlzRCxVQUFKLEdBQWlCdEQsSUFBSW1ELFNBQXJCO0FBQ0FuRCxNQUFJdUQsVUFBSixHQUFpQnZELElBQUlxRCxTQUFyQjtBQUdBLE1BQUcsQ0FBQ3JELElBQUlxRCxTQUFSLEVBQW1CckQsSUFBSXFELFNBQUosR0FBZ0JyQixNQUFoQjtBQUNuQixDQVJEO0FBVUFXLGNBQWNPLE1BQWQsQ0FBcUJKLE1BQXJCLENBQTRCLFVBQVNkLE1BQVQsRUFBaUJoQyxHQUFqQixFQUFzQndELFVBQXRCLEVBQWtDUixRQUFsQyxFQUE0Q1MsT0FBNUMsRUFBcUQ7QUFDaEZULFdBQVNVLElBQVQsR0FBZ0JWLFNBQVNVLElBQVQsSUFBaUIsRUFBakM7QUFDQVYsV0FBU1UsSUFBVCxDQUFjSixVQUFkLEdBQTJCLElBQUlGLElBQUosRUFBM0I7QUFDQUosV0FBU1UsSUFBVCxDQUFjSCxVQUFkLEdBQTJCdkIsTUFBM0I7QUFHQSxDQU5EO0FBUUFXLGNBQWNPLE1BQWQsQ0FBcUJTLE1BQXJCLENBQTRCLFVBQVMzQixNQUFULEVBQWlCNEIsUUFBakIsRUFBMkJaLFFBQTNCLEVBQXFDUyxPQUFyQyxFQUE4QztBQUN6RVQsV0FBU1UsSUFBVCxHQUFnQlYsU0FBU1UsSUFBVCxJQUFpQixFQUFqQztBQUNBVixXQUFTVSxJQUFULENBQWNKLFVBQWQsR0FBMkIsSUFBSUYsSUFBSixFQUEzQjtBQUNBSixXQUFTVSxJQUFULENBQWNILFVBQWQsR0FBMkJ2QixNQUEzQjtBQUVBO0FBQ0EsQ0FORDtBQVFBVyxjQUFjTyxNQUFkLENBQXFCRCxNQUFyQixDQUE0QixVQUFTakIsTUFBVCxFQUFpQmhDLEdBQWpCLEVBQXNCLENBRWpELENBRkQ7QUFJQTJDLGNBQWNrQixLQUFkLENBQW9CaEIsTUFBcEIsQ0FBMkIsVUFBU2IsTUFBVCxFQUFpQmhDLEdBQWpCLEVBQXNCLENBRWhELENBRkQ7QUFJQTJDLGNBQWNrQixLQUFkLENBQW9CZixNQUFwQixDQUEyQixVQUFTZCxNQUFULEVBQWlCaEMsR0FBakIsRUFBc0J3RCxVQUF0QixFQUFrQ1IsUUFBbEMsRUFBNENTLE9BQTVDLEVBQXFELENBRS9FLENBRkQ7QUFJQWQsY0FBY2tCLEtBQWQsQ0FBb0JaLE1BQXBCLENBQTJCLFVBQVNqQixNQUFULEVBQWlCaEMsR0FBakIsRUFBc0IsQ0FFaEQsQ0FGRCxFOzs7Ozs7Ozs7OztBQ3BEQThELE9BQU9DLEdBQVAsQ0FBVyxZQUFZLENBRXRCLENBRkQsRTs7Ozs7Ozs7Ozs7QUNBQUMsT0FBT0MsT0FBUCxDQUFlO0FBQ2Qsd0JBQXNCLFVBQVN2RSxJQUFULEVBQWU7QUFDcEMsUUFBRyxDQUFDa0MsYUFBYUcsYUFBYixDQUEyQixLQUFLQyxNQUFoQyxFQUF3Q3RDLElBQXhDLENBQUosRUFBbUQ7QUFDbEQsWUFBTSxJQUFJc0UsT0FBT0UsS0FBWCxDQUFpQixHQUFqQixFQUFzQixZQUF0QixDQUFOO0FBQ0E7O0FBRUQsV0FBT3RDLGFBQWFpQixNQUFiLENBQW9CbkQsSUFBcEIsQ0FBUDtBQUNBLEdBUGE7QUFTZCx3QkFBc0IsVUFBU3lFLEVBQVQsRUFBYXpFLElBQWIsRUFBbUI7QUFDeEMsUUFBSU0sTUFBTTRCLGFBQWF3QyxPQUFiLENBQXFCO0FBQUVDLFdBQUtGO0FBQVAsS0FBckIsQ0FBVjs7QUFDQSxRQUFHLENBQUN2QyxhQUFhSyxhQUFiLENBQTJCLEtBQUtELE1BQWhDLEVBQXdDaEMsR0FBeEMsQ0FBSixFQUFrRDtBQUNqRCxZQUFNLElBQUlnRSxPQUFPRSxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLFlBQXRCLENBQU47QUFDQTs7QUFFRHRDLGlCQUFha0IsTUFBYixDQUFvQjtBQUFFdUIsV0FBS0Y7QUFBUCxLQUFwQixFQUFpQztBQUFFVCxZQUFNaEU7QUFBUixLQUFqQztBQUNBLEdBaEJhO0FBa0JkLHdCQUFzQixVQUFTeUUsRUFBVCxFQUFhO0FBQ2xDLFFBQUluRSxNQUFNNEIsYUFBYXdDLE9BQWIsQ0FBcUI7QUFBRUMsV0FBS0Y7QUFBUCxLQUFyQixDQUFWOztBQUNBLFFBQUcsQ0FBQ3ZDLGFBQWFNLGFBQWIsQ0FBMkIsS0FBS0YsTUFBaEMsRUFBd0NoQyxHQUF4QyxDQUFKLEVBQWtEO0FBQ2pELFlBQU0sSUFBSWdFLE9BQU9FLEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsWUFBdEIsQ0FBTjtBQUNBOztBQUVEdEMsaUJBQWFxQixNQUFiLENBQW9CO0FBQUVvQixXQUFLRjtBQUFQLEtBQXBCO0FBQ0E7QUF6QmEsQ0FBZixFOzs7Ozs7Ozs7OztBQ0FBSCxPQUFPQyxPQUFQLENBQWU7QUFDZCxzQkFBb0IsVUFBU3ZFLElBQVQsRUFBZTtBQUNsQyxRQUFHLENBQUN5QyxXQUFXSixhQUFYLENBQXlCLEtBQUtDLE1BQTlCLEVBQXNDdEMsSUFBdEMsQ0FBSixFQUFpRDtBQUNoRCxZQUFNLElBQUlzRSxPQUFPRSxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLFlBQXRCLENBQU47QUFDQTs7QUFFRCxXQUFPL0IsV0FBV1UsTUFBWCxDQUFrQm5ELElBQWxCLENBQVA7QUFDQSxHQVBhO0FBU2Qsc0JBQW9CLFVBQVN5RSxFQUFULEVBQWF6RSxJQUFiLEVBQW1CO0FBQ3RDLFFBQUlNLE1BQU1tQyxXQUFXaUMsT0FBWCxDQUFtQjtBQUFFQyxXQUFLRjtBQUFQLEtBQW5CLENBQVY7O0FBQ0EsUUFBRyxDQUFDaEMsV0FBV0YsYUFBWCxDQUF5QixLQUFLRCxNQUE5QixFQUFzQ2hDLEdBQXRDLENBQUosRUFBZ0Q7QUFDL0MsWUFBTSxJQUFJZ0UsT0FBT0UsS0FBWCxDQUFpQixHQUFqQixFQUFzQixZQUF0QixDQUFOO0FBQ0E7O0FBRUQvQixlQUFXVyxNQUFYLENBQWtCO0FBQUV1QixXQUFLRjtBQUFQLEtBQWxCLEVBQStCO0FBQUVULFlBQU1oRTtBQUFSLEtBQS9CO0FBQ0EsR0FoQmE7QUFrQmQsc0JBQW9CLFVBQVN5RSxFQUFULEVBQWE7QUFDaEMsUUFBSW5FLE1BQU1tQyxXQUFXaUMsT0FBWCxDQUFtQjtBQUFFQyxXQUFLRjtBQUFQLEtBQW5CLENBQVY7O0FBQ0EsUUFBRyxDQUFDaEMsV0FBV0QsYUFBWCxDQUF5QixLQUFLRixNQUE5QixFQUFzQ2hDLEdBQXRDLENBQUosRUFBZ0Q7QUFDL0MsWUFBTSxJQUFJZ0UsT0FBT0UsS0FBWCxDQUFpQixHQUFqQixFQUFzQixZQUF0QixDQUFOO0FBQ0E7O0FBRUQvQixlQUFXYyxNQUFYLENBQWtCO0FBQUVvQixXQUFLRjtBQUFQLEtBQWxCO0FBQ0E7QUF6QmEsQ0FBZixFOzs7Ozs7Ozs7OztBQ0FBSCxPQUFPQyxPQUFQLENBQWU7QUFDZCxzQkFBb0IsVUFBU3ZFLElBQVQsRUFBZTtBQUNsQyxRQUFHLENBQUMwQyxXQUFXTCxhQUFYLENBQXlCLEtBQUtDLE1BQTlCLEVBQXNDdEMsSUFBdEMsQ0FBSixFQUFpRDtBQUNoRCxZQUFNLElBQUlzRSxPQUFPRSxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLFlBQXRCLENBQU47QUFDQTs7QUFFRCxXQUFPOUIsV0FBV1MsTUFBWCxDQUFrQm5ELElBQWxCLENBQVA7QUFDQSxHQVBhO0FBU2Qsc0JBQW9CLFVBQVN5RSxFQUFULEVBQWF6RSxJQUFiLEVBQW1CO0FBQ3RDLFFBQUlNLE1BQU1vQyxXQUFXZ0MsT0FBWCxDQUFtQjtBQUFFQyxXQUFLRjtBQUFQLEtBQW5CLENBQVY7O0FBQ0EsUUFBRyxDQUFDL0IsV0FBV0gsYUFBWCxDQUF5QixLQUFLRCxNQUE5QixFQUFzQ2hDLEdBQXRDLENBQUosRUFBZ0Q7QUFDL0MsWUFBTSxJQUFJZ0UsT0FBT0UsS0FBWCxDQUFpQixHQUFqQixFQUFzQixZQUF0QixDQUFOO0FBQ0E7O0FBRUQ5QixlQUFXVSxNQUFYLENBQWtCO0FBQUV1QixXQUFLRjtBQUFQLEtBQWxCLEVBQStCO0FBQUVULFlBQU1oRTtBQUFSLEtBQS9CO0FBQ0EsR0FoQmE7QUFrQmQsc0JBQW9CLFVBQVN5RSxFQUFULEVBQWE7QUFDaEMsUUFBSW5FLE1BQU1vQyxXQUFXZ0MsT0FBWCxDQUFtQjtBQUFFQyxXQUFLRjtBQUFQLEtBQW5CLENBQVY7O0FBQ0EsUUFBRyxDQUFDL0IsV0FBV0YsYUFBWCxDQUF5QixLQUFLRixNQUE5QixFQUFzQ2hDLEdBQXRDLENBQUosRUFBZ0Q7QUFDL0MsWUFBTSxJQUFJZ0UsT0FBT0UsS0FBWCxDQUFpQixHQUFqQixFQUFzQixZQUF0QixDQUFOO0FBQ0E7O0FBRUQ5QixlQUFXYSxNQUFYLENBQWtCO0FBQUVvQixXQUFLRjtBQUFQLEtBQWxCO0FBQ0E7QUF6QmEsQ0FBZixFOzs7Ozs7Ozs7OztBQ0FBSCxPQUFPQyxPQUFQLENBQWU7QUFDZCxtQkFBaUIsVUFBU3ZFLElBQVQsRUFBZTtBQUMvQixRQUFHLENBQUMyQyxRQUFRTixhQUFSLENBQXNCLEtBQUtDLE1BQTNCLEVBQW1DdEMsSUFBbkMsQ0FBSixFQUE4QztBQUM3QyxZQUFNLElBQUlzRSxPQUFPRSxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLFlBQXRCLENBQU47QUFDQTs7QUFFRCxXQUFPN0IsUUFBUVEsTUFBUixDQUFlbkQsSUFBZixDQUFQO0FBQ0EsR0FQYTtBQVNkLG1CQUFpQixVQUFTeUUsRUFBVCxFQUFhekUsSUFBYixFQUFtQjtBQUNuQyxRQUFJTSxNQUFNcUMsUUFBUStCLE9BQVIsQ0FBZ0I7QUFBRUMsV0FBS0Y7QUFBUCxLQUFoQixDQUFWOztBQUNBLFFBQUcsQ0FBQzlCLFFBQVFKLGFBQVIsQ0FBc0IsS0FBS0QsTUFBM0IsRUFBbUNoQyxHQUFuQyxDQUFKLEVBQTZDO0FBQzVDLFlBQU0sSUFBSWdFLE9BQU9FLEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsWUFBdEIsQ0FBTjtBQUNBOztBQUVEN0IsWUFBUVMsTUFBUixDQUFlO0FBQUV1QixXQUFLRjtBQUFQLEtBQWYsRUFBNEI7QUFBRVQsWUFBTWhFO0FBQVIsS0FBNUI7QUFDQSxHQWhCYTtBQWtCZCxtQkFBaUIsVUFBU3lFLEVBQVQsRUFBYTtBQUM3QixRQUFJbkUsTUFBTXFDLFFBQVErQixPQUFSLENBQWdCO0FBQUVDLFdBQUtGO0FBQVAsS0FBaEIsQ0FBVjs7QUFDQSxRQUFHLENBQUM5QixRQUFRSCxhQUFSLENBQXNCLEtBQUtGLE1BQTNCLEVBQW1DaEMsR0FBbkMsQ0FBSixFQUE2QztBQUM1QyxZQUFNLElBQUlnRSxPQUFPRSxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLFlBQXRCLENBQU47QUFDQTs7QUFFRDdCLFlBQVFZLE1BQVIsQ0FBZTtBQUFFb0IsV0FBS0Y7QUFBUCxLQUFmO0FBQ0E7QUF6QmEsQ0FBZixFOzs7Ozs7Ozs7OztBQ0FBSCxPQUFPQyxPQUFQLENBQWU7QUFDZCx3QkFBc0IsVUFBU3ZFLElBQVQsRUFBZTtBQUNwQyxRQUFHLENBQUM0QyxhQUFhUCxhQUFiLENBQTJCLEtBQUtDLE1BQWhDLEVBQXdDdEMsSUFBeEMsQ0FBSixFQUFtRDtBQUNsRCxZQUFNLElBQUlzRSxPQUFPRSxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLFlBQXRCLENBQU47QUFDQTs7QUFFRCxXQUFPNUIsYUFBYU8sTUFBYixDQUFvQm5ELElBQXBCLENBQVA7QUFDQSxHQVBhO0FBU2Qsd0JBQXNCLFVBQVN5RSxFQUFULEVBQWF6RSxJQUFiLEVBQW1CO0FBQ3hDLFFBQUlNLE1BQU1zQyxhQUFhOEIsT0FBYixDQUFxQjtBQUFFQyxXQUFLRjtBQUFQLEtBQXJCLENBQVY7O0FBQ0EsUUFBRyxDQUFDN0IsYUFBYUwsYUFBYixDQUEyQixLQUFLRCxNQUFoQyxFQUF3Q2hDLEdBQXhDLENBQUosRUFBa0Q7QUFDakQsWUFBTSxJQUFJZ0UsT0FBT0UsS0FBWCxDQUFpQixHQUFqQixFQUFzQixZQUF0QixDQUFOO0FBQ0E7O0FBRUQ1QixpQkFBYVEsTUFBYixDQUFvQjtBQUFFdUIsV0FBS0Y7QUFBUCxLQUFwQixFQUFpQztBQUFFVCxZQUFNaEU7QUFBUixLQUFqQztBQUNBLEdBaEJhO0FBa0JkLHdCQUFzQixVQUFTeUUsRUFBVCxFQUFhO0FBQ2xDLFFBQUluRSxNQUFNc0MsYUFBYThCLE9BQWIsQ0FBcUI7QUFBRUMsV0FBS0Y7QUFBUCxLQUFyQixDQUFWOztBQUNBLFFBQUcsQ0FBQzdCLGFBQWFKLGFBQWIsQ0FBMkIsS0FBS0YsTUFBaEMsRUFBd0NoQyxHQUF4QyxDQUFKLEVBQWtEO0FBQ2pELFlBQU0sSUFBSWdFLE9BQU9FLEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsWUFBdEIsQ0FBTjtBQUNBOztBQUVENUIsaUJBQWFXLE1BQWIsQ0FBb0I7QUFBRW9CLFdBQUtGO0FBQVAsS0FBcEI7QUFDQTtBQXpCYSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDQUFILE9BQU9DLE9BQVAsQ0FBZTtBQUNkLHVCQUFxQixVQUFTdkUsSUFBVCxFQUFlO0FBQ25DLFFBQUcsQ0FBQzZDLFlBQVlSLGFBQVosQ0FBMEIsS0FBS0MsTUFBL0IsRUFBdUN0QyxJQUF2QyxDQUFKLEVBQWtEO0FBQ2pELFlBQU0sSUFBSXNFLE9BQU9FLEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsWUFBdEIsQ0FBTjtBQUNBOztBQUVELFdBQU8zQixZQUFZTSxNQUFaLENBQW1CbkQsSUFBbkIsQ0FBUDtBQUNBLEdBUGE7QUFTZCx1QkFBcUIsVUFBU3lFLEVBQVQsRUFBYXpFLElBQWIsRUFBbUI7QUFDdkMsUUFBSU0sTUFBTXVDLFlBQVk2QixPQUFaLENBQW9CO0FBQUVDLFdBQUtGO0FBQVAsS0FBcEIsQ0FBVjs7QUFDQSxRQUFHLENBQUM1QixZQUFZTixhQUFaLENBQTBCLEtBQUtELE1BQS9CLEVBQXVDaEMsR0FBdkMsQ0FBSixFQUFpRDtBQUNoRCxZQUFNLElBQUlnRSxPQUFPRSxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLFlBQXRCLENBQU47QUFDQTs7QUFFRDNCLGdCQUFZTyxNQUFaLENBQW1CO0FBQUV1QixXQUFLRjtBQUFQLEtBQW5CLEVBQWdDO0FBQUVULFlBQU1oRTtBQUFSLEtBQWhDO0FBQ0EsR0FoQmE7QUFrQmQsdUJBQXFCLFVBQVN5RSxFQUFULEVBQWE7QUFDakMsUUFBSW5FLE1BQU11QyxZQUFZNkIsT0FBWixDQUFvQjtBQUFFQyxXQUFLRjtBQUFQLEtBQXBCLENBQVY7O0FBQ0EsUUFBRyxDQUFDNUIsWUFBWUwsYUFBWixDQUEwQixLQUFLRixNQUEvQixFQUF1Q2hDLEdBQXZDLENBQUosRUFBaUQ7QUFDaEQsWUFBTSxJQUFJZ0UsT0FBT0UsS0FBWCxDQUFpQixHQUFqQixFQUFzQixZQUF0QixDQUFOO0FBQ0E7O0FBRUQzQixnQkFBWVUsTUFBWixDQUFtQjtBQUFFb0IsV0FBS0Y7QUFBUCxLQUFuQjtBQUNBO0FBekJhLENBQWYsRTs7Ozs7Ozs7Ozs7QUNBQUgsT0FBT0MsT0FBUCxDQUFlO0FBQ2QscUJBQW1CLFVBQVN2RSxJQUFULEVBQWU7QUFDakMsUUFBRyxDQUFDOEMsVUFBVVQsYUFBVixDQUF3QixLQUFLQyxNQUE3QixFQUFxQ3RDLElBQXJDLENBQUosRUFBZ0Q7QUFDL0MsWUFBTSxJQUFJc0UsT0FBT0UsS0FBWCxDQUFpQixHQUFqQixFQUFzQixZQUF0QixDQUFOO0FBQ0E7O0FBRUQsV0FBTzFCLFVBQVVLLE1BQVYsQ0FBaUJuRCxJQUFqQixDQUFQO0FBQ0EsR0FQYTtBQVNkLHFCQUFtQixVQUFTeUUsRUFBVCxFQUFhekUsSUFBYixFQUFtQjtBQUNyQyxRQUFJTSxNQUFNd0MsVUFBVTRCLE9BQVYsQ0FBa0I7QUFBRUMsV0FBS0Y7QUFBUCxLQUFsQixDQUFWOztBQUNBLFFBQUcsQ0FBQzNCLFVBQVVQLGFBQVYsQ0FBd0IsS0FBS0QsTUFBN0IsRUFBcUNoQyxHQUFyQyxDQUFKLEVBQStDO0FBQzlDLFlBQU0sSUFBSWdFLE9BQU9FLEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsWUFBdEIsQ0FBTjtBQUNBOztBQUVEMUIsY0FBVU0sTUFBVixDQUFpQjtBQUFFdUIsV0FBS0Y7QUFBUCxLQUFqQixFQUE4QjtBQUFFVCxZQUFNaEU7QUFBUixLQUE5QjtBQUNBLEdBaEJhO0FBa0JkLHFCQUFtQixVQUFTeUUsRUFBVCxFQUFhO0FBQy9CLFFBQUluRSxNQUFNd0MsVUFBVTRCLE9BQVYsQ0FBa0I7QUFBRUMsV0FBS0Y7QUFBUCxLQUFsQixDQUFWOztBQUNBLFFBQUcsQ0FBQzNCLFVBQVVOLGFBQVYsQ0FBd0IsS0FBS0YsTUFBN0IsRUFBcUNoQyxHQUFyQyxDQUFKLEVBQStDO0FBQzlDLFlBQU0sSUFBSWdFLE9BQU9FLEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsWUFBdEIsQ0FBTjtBQUNBOztBQUVEMUIsY0FBVVMsTUFBVixDQUFpQjtBQUFFb0IsV0FBS0Y7QUFBUCxLQUFqQjtBQUNBO0FBekJhLENBQWYsRTs7Ozs7Ozs7Ozs7QUNBQUgsT0FBT0MsT0FBUCxDQUFlO0FBQ2QseUJBQXVCLFVBQVN2RSxJQUFULEVBQWU7QUFDckMsUUFBRyxDQUFDK0MsY0FBY1YsYUFBZCxDQUE0QixLQUFLQyxNQUFqQyxFQUF5Q3RDLElBQXpDLENBQUosRUFBb0Q7QUFDbkQsWUFBTSxJQUFJc0UsT0FBT0UsS0FBWCxDQUFpQixHQUFqQixFQUFzQixZQUF0QixDQUFOO0FBQ0E7O0FBRUQsV0FBT3pCLGNBQWNJLE1BQWQsQ0FBcUJuRCxJQUFyQixDQUFQO0FBQ0EsR0FQYTtBQVNkLHlCQUF1QixVQUFTeUUsRUFBVCxFQUFhekUsSUFBYixFQUFtQjtBQUN6QyxRQUFJTSxNQUFNeUMsY0FBYzJCLE9BQWQsQ0FBc0I7QUFBRUMsV0FBS0Y7QUFBUCxLQUF0QixDQUFWOztBQUNBLFFBQUcsQ0FBQzFCLGNBQWNSLGFBQWQsQ0FBNEIsS0FBS0QsTUFBakMsRUFBeUNoQyxHQUF6QyxDQUFKLEVBQW1EO0FBQ2xELFlBQU0sSUFBSWdFLE9BQU9FLEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsWUFBdEIsQ0FBTjtBQUNBOztBQUVEekIsa0JBQWNLLE1BQWQsQ0FBcUI7QUFBRXVCLFdBQUtGO0FBQVAsS0FBckIsRUFBa0M7QUFBRVQsWUFBTWhFO0FBQVIsS0FBbEM7QUFDQSxHQWhCYTtBQWtCZCx5QkFBdUIsVUFBU3lFLEVBQVQsRUFBYTtBQUNuQyxRQUFJbkUsTUFBTXlDLGNBQWMyQixPQUFkLENBQXNCO0FBQUVDLFdBQUtGO0FBQVAsS0FBdEIsQ0FBVjs7QUFDQSxRQUFHLENBQUMxQixjQUFjUCxhQUFkLENBQTRCLEtBQUtGLE1BQWpDLEVBQXlDaEMsR0FBekMsQ0FBSixFQUFtRDtBQUNsRCxZQUFNLElBQUlnRSxPQUFPRSxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLFlBQXRCLENBQU47QUFDQTs7QUFFRHpCLGtCQUFjUSxNQUFkLENBQXFCO0FBQUVvQixXQUFLRjtBQUFQLEtBQXJCO0FBQ0E7QUF6QmEsQ0FBZixFOzs7Ozs7Ozs7OztBQ0FBSCxPQUFPQyxPQUFQLENBQWU7QUFDZCw4QkFBNEIsVUFBU3ZFLElBQVQsRUFBZTtBQUMxQyxRQUFHLENBQUNnRCxtQkFBbUJYLGFBQW5CLENBQWlDLEtBQUtDLE1BQXRDLEVBQThDdEMsSUFBOUMsQ0FBSixFQUF5RDtBQUN4RCxZQUFNLElBQUlzRSxPQUFPRSxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLFlBQXRCLENBQU47QUFDQTs7QUFFRCxXQUFPeEIsbUJBQW1CRyxNQUFuQixDQUEwQm5ELElBQTFCLENBQVA7QUFDQSxHQVBhO0FBU2QsOEJBQTRCLFVBQVN5RSxFQUFULEVBQWF6RSxJQUFiLEVBQW1CO0FBQzlDLFFBQUlNLE1BQU0wQyxtQkFBbUIwQixPQUFuQixDQUEyQjtBQUFFQyxXQUFLRjtBQUFQLEtBQTNCLENBQVY7O0FBQ0EsUUFBRyxDQUFDekIsbUJBQW1CVCxhQUFuQixDQUFpQyxLQUFLRCxNQUF0QyxFQUE4Q2hDLEdBQTlDLENBQUosRUFBd0Q7QUFDdkQsWUFBTSxJQUFJZ0UsT0FBT0UsS0FBWCxDQUFpQixHQUFqQixFQUFzQixZQUF0QixDQUFOO0FBQ0E7O0FBRUR4Qix1QkFBbUJJLE1BQW5CLENBQTBCO0FBQUV1QixXQUFLRjtBQUFQLEtBQTFCLEVBQXVDO0FBQUVULFlBQU1oRTtBQUFSLEtBQXZDO0FBQ0EsR0FoQmE7QUFrQmQsOEJBQTRCLFVBQVN5RSxFQUFULEVBQWE7QUFDeEMsUUFBSW5FLE1BQU0wQyxtQkFBbUIwQixPQUFuQixDQUEyQjtBQUFFQyxXQUFLRjtBQUFQLEtBQTNCLENBQVY7O0FBQ0EsUUFBRyxDQUFDekIsbUJBQW1CUixhQUFuQixDQUFpQyxLQUFLRixNQUF0QyxFQUE4Q2hDLEdBQTlDLENBQUosRUFBd0Q7QUFDdkQsWUFBTSxJQUFJZ0UsT0FBT0UsS0FBWCxDQUFpQixHQUFqQixFQUFzQixZQUF0QixDQUFOO0FBQ0E7O0FBRUR4Qix1QkFBbUJPLE1BQW5CLENBQTBCO0FBQUVvQixXQUFLRjtBQUFQLEtBQTFCO0FBQ0E7QUF6QmEsQ0FBZixFOzs7Ozs7Ozs7OztBQ0FBSCxPQUFPQyxPQUFQLENBQWU7QUFDZCx5QkFBdUIsVUFBU3ZFLElBQVQsRUFBZTtBQUNyQyxRQUFHLENBQUNpRCxjQUFjWixhQUFkLENBQTRCLEtBQUtDLE1BQWpDLEVBQXlDdEMsSUFBekMsQ0FBSixFQUFvRDtBQUNuRCxZQUFNLElBQUlzRSxPQUFPRSxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLFlBQXRCLENBQU47QUFDQTs7QUFFRCxXQUFPdkIsY0FBY0UsTUFBZCxDQUFxQm5ELElBQXJCLENBQVA7QUFDQSxHQVBhO0FBU2QseUJBQXVCLFVBQVN5RSxFQUFULEVBQWF6RSxJQUFiLEVBQW1CO0FBQ3pDLFFBQUlNLE1BQU0yQyxjQUFjeUIsT0FBZCxDQUFzQjtBQUFFQyxXQUFLRjtBQUFQLEtBQXRCLENBQVY7O0FBQ0EsUUFBRyxDQUFDeEIsY0FBY1YsYUFBZCxDQUE0QixLQUFLRCxNQUFqQyxFQUF5Q2hDLEdBQXpDLENBQUosRUFBbUQ7QUFDbEQsWUFBTSxJQUFJZ0UsT0FBT0UsS0FBWCxDQUFpQixHQUFqQixFQUFzQixZQUF0QixDQUFOO0FBQ0E7O0FBRUR2QixrQkFBY0csTUFBZCxDQUFxQjtBQUFFdUIsV0FBS0Y7QUFBUCxLQUFyQixFQUFrQztBQUFFVCxZQUFNaEU7QUFBUixLQUFsQztBQUNBLEdBaEJhO0FBa0JkLHlCQUF1QixVQUFTeUUsRUFBVCxFQUFhO0FBQ25DLFFBQUluRSxNQUFNMkMsY0FBY3lCLE9BQWQsQ0FBc0I7QUFBRUMsV0FBS0Y7QUFBUCxLQUF0QixDQUFWOztBQUNBLFFBQUcsQ0FBQ3hCLGNBQWNULGFBQWQsQ0FBNEIsS0FBS0YsTUFBakMsRUFBeUNoQyxHQUF6QyxDQUFKLEVBQW1EO0FBQ2xELFlBQU0sSUFBSWdFLE9BQU9FLEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsWUFBdEIsQ0FBTjtBQUNBOztBQUVEdkIsa0JBQWNNLE1BQWQsQ0FBcUI7QUFBRW9CLFdBQUtGO0FBQVAsS0FBckI7QUFDQTtBQXpCYSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDQUFILE9BQU9NLE9BQVAsQ0FBZSxrQkFBZixFQUFtQyxZQUFXO0FBQzdDLFNBQU8xQyxhQUFhUixJQUFiLENBQWtCLEVBQWxCLEVBQXNCLEVBQXRCLENBQVA7QUFDQSxDQUZEO0FBSUE0QyxPQUFPTSxPQUFQLENBQWUsbUJBQWYsRUFBb0MsWUFBVztBQUM5QyxTQUFPMUMsYUFBYVIsSUFBYixDQUFrQjtBQUFDaUQsU0FBSTtBQUFMLEdBQWxCLEVBQThCLEVBQTlCLENBQVA7QUFDQSxDQUZEO0FBSUFMLE9BQU9NLE9BQVAsQ0FBZSxhQUFmLEVBQThCLFVBQVNDLGFBQVQsRUFBd0I7QUFDckQsU0FBTzNDLGFBQWFSLElBQWIsQ0FBa0I7QUFBQ2lELFNBQUlFO0FBQUwsR0FBbEIsRUFBdUMsRUFBdkMsQ0FBUDtBQUNBLENBRkQsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDUkFQLE9BQU9NLE9BQVAsQ0FBZSxlQUFmLEVBQWdDLFlBQVc7QUFDMUMsU0FBT2xDLFdBQVdoQixJQUFYLENBQWdCLEVBQWhCLEVBQW9CLEVBQXBCLENBQVA7QUFDQSxDQUZEO0FBSUE0QyxPQUFPTSxPQUFQLENBQWUsaUJBQWYsRUFBa0MsWUFBVztBQUM1QyxTQUFPbEMsV0FBV2hCLElBQVgsQ0FBZ0I7QUFBQ2lELFNBQUk7QUFBTCxHQUFoQixFQUE0QixFQUE1QixDQUFQO0FBQ0EsQ0FGRDtBQUlBTCxPQUFPTSxPQUFQLENBQWUsVUFBZixFQUEyQixVQUFTRSxVQUFULEVBQXFCO0FBQy9DLFNBQU9wQyxXQUFXaEIsSUFBWCxDQUFnQjtBQUFDaUQsU0FBSUc7QUFBTCxHQUFoQixFQUFrQyxFQUFsQyxDQUFQO0FBQ0EsQ0FGRCxFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDUkFSLE9BQU9NLE9BQVAsQ0FBZSxnQkFBZixFQUFpQyxZQUFXO0FBQzNDLFNBQU8vQixZQUFZbkIsSUFBWixDQUFpQixFQUFqQixFQUFxQixFQUFyQixDQUFQO0FBQ0EsQ0FGRDtBQUlBNEMsT0FBT00sT0FBUCxDQUFlLGtCQUFmLEVBQW1DLFlBQVc7QUFDN0MsU0FBTy9CLFlBQVluQixJQUFaLENBQWlCO0FBQUNpRCxTQUFJO0FBQUwsR0FBakIsRUFBNkIsRUFBN0IsQ0FBUDtBQUNBLENBRkQ7QUFJQUwsT0FBT00sT0FBUCxDQUFlLFdBQWYsRUFBNEIsVUFBU0csV0FBVCxFQUFzQjtBQUNqRCxTQUFPbEMsWUFBWW5CLElBQVosQ0FBaUI7QUFBQ2lELFNBQUlJO0FBQUwsR0FBakIsRUFBb0MsRUFBcEMsQ0FBUDtBQUNBLENBRkQsRTs7Ozs7Ozs7Ozs7QUNSQVQsT0FBT00sT0FBUCxDQUFlLGVBQWYsRUFBZ0MsWUFBVztBQUMxQyxTQUFPOUIsVUFBVXBCLElBQVYsQ0FBZSxFQUFmLEVBQW1CLEVBQW5CLENBQVA7QUFDQSxDQUZEO0FBSUE0QyxPQUFPTSxPQUFQLENBQWUsZ0JBQWYsRUFBaUMsWUFBVztBQUMzQyxTQUFPOUIsVUFBVXBCLElBQVYsQ0FBZTtBQUFDaUQsU0FBSTtBQUFMLEdBQWYsRUFBMkIsRUFBM0IsQ0FBUDtBQUNBLENBRkQ7QUFJQUwsT0FBT00sT0FBUCxDQUFlLFVBQWYsRUFBMkIsVUFBU0ksVUFBVCxFQUFxQjtBQUMvQyxTQUFPbEMsVUFBVXBCLElBQVYsQ0FBZTtBQUFDaUQsU0FBSUs7QUFBTCxHQUFmLEVBQWlDLEVBQWpDLENBQVA7QUFDQSxDQUZELEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNSQVYsT0FBT00sT0FBUCxDQUFlLGtCQUFmLEVBQW1DLFlBQVc7QUFDN0MsU0FBTzNCLGNBQWN2QixJQUFkLENBQW1CLEVBQW5CLEVBQXVCLEVBQXZCLENBQVA7QUFDQSxDQUZEO0FBSUE0QyxPQUFPTSxPQUFQLENBQWUsb0JBQWYsRUFBcUMsWUFBVztBQUMvQyxTQUFPM0IsY0FBY3ZCLElBQWQsQ0FBbUI7QUFBQ2lELFNBQUk7QUFBTCxHQUFuQixFQUErQixFQUEvQixDQUFQO0FBQ0EsQ0FGRDtBQUlBTCxPQUFPTSxPQUFQLENBQWUsYUFBZixFQUE4QixVQUFTSyxhQUFULEVBQXdCO0FBQ3JELFNBQU9oQyxjQUFjdkIsSUFBZCxDQUFtQjtBQUFDaUQsU0FBSU07QUFBTCxHQUFuQixFQUF3QyxFQUF4QyxDQUFQO0FBQ0EsQ0FGRCxFOzs7Ozs7Ozs7OztBQ1JBLElBQUlDLGNBQWMsSUFBbEI7QUFFQUMsU0FBU0MsTUFBVCxDQUFnQjtBQUFFQyx5QkFBdUJIO0FBQXpCLENBQWhCO0FBRUFaLE9BQU9nQixPQUFQLENBQWUsWUFBVztBQUN6QjtBQUNBLE1BQUdoQixPQUFPaUIsUUFBUCxJQUFtQmpCLE9BQU9pQixRQUFQLENBQWdCQyxHQUFuQyxJQUEwQ3BGLEVBQUVxRixRQUFGLENBQVduQixPQUFPaUIsUUFBUCxDQUFnQkMsR0FBM0IsQ0FBN0MsRUFBOEU7QUFDN0UsU0FBSSxJQUFJRSxZQUFSLElBQXdCcEIsT0FBT2lCLFFBQVAsQ0FBZ0JDLEdBQXhDLEVBQTZDO0FBQzVDRyxjQUFRSCxHQUFSLENBQVlFLFlBQVosSUFBNEJwQixPQUFPaUIsUUFBUCxDQUFnQkMsR0FBaEIsQ0FBb0JFLFlBQXBCLENBQTVCO0FBQ0E7QUFDRCxHQU53QixDQVF6QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBLE1BQUdQLFlBQVlBLFNBQVNTLHlCQUFyQixJQUFrRHRCLE9BQU9pQixRQUF6RCxJQUFxRWpCLE9BQU9pQixRQUFQLENBQWdCTSxLQUFyRixJQUE4RnpGLEVBQUVxRixRQUFGLENBQVduQixPQUFPaUIsUUFBUCxDQUFnQk0sS0FBM0IsQ0FBakcsRUFBb0k7QUFDbkk7QUFDQSxRQUFHdkIsT0FBT2lCLFFBQVAsQ0FBZ0JNLEtBQWhCLENBQXNCQyxNQUF0QixJQUFnQzFGLEVBQUVxRixRQUFGLENBQVduQixPQUFPaUIsUUFBUCxDQUFnQk0sS0FBaEIsQ0FBc0JDLE1BQWpDLENBQW5DLEVBQTZFO0FBQzVFO0FBQ0FYLGVBQVNTLHlCQUFULENBQW1DckMsTUFBbkMsQ0FBMEM7QUFDekN3QyxpQkFBUztBQURnQyxPQUExQztBQUlBLFVBQUlDLGlCQUFpQjFCLE9BQU9pQixRQUFQLENBQWdCTSxLQUFoQixDQUFzQkMsTUFBM0M7QUFDQUUscUJBQWVELE9BQWYsR0FBeUIsUUFBekIsQ0FQNEUsQ0FTNUU7O0FBQ0FaLGVBQVNTLHlCQUFULENBQW1DekMsTUFBbkMsQ0FBMEM2QyxjQUExQztBQUNBLEtBYmtJLENBY25JOzs7QUFDQSxRQUFHMUIsT0FBT2lCLFFBQVAsQ0FBZ0JNLEtBQWhCLENBQXNCSSxNQUF0QixJQUFnQzdGLEVBQUVxRixRQUFGLENBQVduQixPQUFPaUIsUUFBUCxDQUFnQk0sS0FBaEIsQ0FBc0JJLE1BQWpDLENBQW5DLEVBQTZFO0FBQzVFO0FBQ0FkLGVBQVNTLHlCQUFULENBQW1DckMsTUFBbkMsQ0FBMEM7QUFDekN3QyxpQkFBUztBQURnQyxPQUExQztBQUlBLFVBQUlDLGlCQUFpQjFCLE9BQU9pQixRQUFQLENBQWdCTSxLQUFoQixDQUFzQkksTUFBM0M7QUFDQUQscUJBQWVELE9BQWYsR0FBeUIsUUFBekIsQ0FQNEUsQ0FTNUU7O0FBQ0FaLGVBQVNTLHlCQUFULENBQW1DekMsTUFBbkMsQ0FBMEM2QyxjQUExQztBQUNBLEtBMUJrSSxDQTJCbkk7OztBQUNBLFFBQUcxQixPQUFPaUIsUUFBUCxDQUFnQk0sS0FBaEIsQ0FBc0JLLFFBQXRCLElBQWtDOUYsRUFBRXFGLFFBQUYsQ0FBV25CLE9BQU9pQixRQUFQLENBQWdCTSxLQUFoQixDQUFzQkssUUFBakMsQ0FBckMsRUFBaUY7QUFDaEY7QUFDQWYsZUFBU1MseUJBQVQsQ0FBbUNyQyxNQUFuQyxDQUEwQztBQUN6Q3dDLGlCQUFTO0FBRGdDLE9BQTFDO0FBSUEsVUFBSUMsaUJBQWlCMUIsT0FBT2lCLFFBQVAsQ0FBZ0JNLEtBQWhCLENBQXNCSyxRQUEzQztBQUNBRixxQkFBZUQsT0FBZixHQUF5QixVQUF6QixDQVBnRixDQVNoRjs7QUFDQVosZUFBU1MseUJBQVQsQ0FBbUN6QyxNQUFuQyxDQUEwQzZDLGNBQTFDO0FBQ0EsS0F2Q2tJLENBd0NuSTs7O0FBQ0EsUUFBRzFCLE9BQU9pQixRQUFQLENBQWdCTSxLQUFoQixDQUFzQk0sUUFBdEIsSUFBa0MvRixFQUFFcUYsUUFBRixDQUFXbkIsT0FBT2lCLFFBQVAsQ0FBZ0JNLEtBQWhCLENBQXNCTSxRQUFqQyxDQUFyQyxFQUFpRjtBQUNoRjtBQUNBaEIsZUFBU1MseUJBQVQsQ0FBbUNyQyxNQUFuQyxDQUEwQztBQUN6Q3dDLGlCQUFTO0FBRGdDLE9BQTFDO0FBSUEsVUFBSUMsaUJBQWlCMUIsT0FBT2lCLFFBQVAsQ0FBZ0JNLEtBQWhCLENBQXNCTSxRQUEzQztBQUNBSCxxQkFBZUQsT0FBZixHQUF5QixVQUF6QixDQVBnRixDQVNoRjs7QUFDQVosZUFBU1MseUJBQVQsQ0FBbUN6QyxNQUFuQyxDQUEwQzZDLGNBQTFDO0FBQ0EsS0FwRGtJLENBcURuSTs7O0FBQ0EsUUFBRzFCLE9BQU9pQixRQUFQLENBQWdCTSxLQUFoQixDQUFzQk8sT0FBdEIsSUFBaUNoRyxFQUFFcUYsUUFBRixDQUFXbkIsT0FBT2lCLFFBQVAsQ0FBZ0JNLEtBQWhCLENBQXNCTyxPQUFqQyxDQUFwQyxFQUErRTtBQUM5RTtBQUNBakIsZUFBU1MseUJBQVQsQ0FBbUNyQyxNQUFuQyxDQUEwQztBQUN6Q3dDLGlCQUFTO0FBRGdDLE9BQTFDO0FBSUEsVUFBSUMsaUJBQWlCMUIsT0FBT2lCLFFBQVAsQ0FBZ0JNLEtBQWhCLENBQXNCTyxPQUEzQztBQUNBSixxQkFBZUQsT0FBZixHQUF5QixTQUF6QixDQVA4RSxDQVM5RTs7QUFDQVosZUFBU1MseUJBQVQsQ0FBbUN6QyxNQUFuQyxDQUEwQzZDLGNBQTFDO0FBQ0EsS0FqRWtJLENBa0VuSTs7O0FBQ0EsUUFBRzFCLE9BQU9pQixRQUFQLENBQWdCTSxLQUFoQixDQUFzQlEsTUFBdEIsSUFBZ0NqRyxFQUFFcUYsUUFBRixDQUFXbkIsT0FBT2lCLFFBQVAsQ0FBZ0JNLEtBQWhCLENBQXNCUSxNQUFqQyxDQUFuQyxFQUE2RTtBQUM1RTtBQUNBbEIsZUFBU1MseUJBQVQsQ0FBbUNyQyxNQUFuQyxDQUEwQztBQUN6Q3dDLGlCQUFTO0FBRGdDLE9BQTFDO0FBSUEsVUFBSUMsaUJBQWlCMUIsT0FBT2lCLFFBQVAsQ0FBZ0JNLEtBQWhCLENBQXNCUSxNQUEzQztBQUNBTCxxQkFBZUQsT0FBZixHQUF5QixrQkFBekIsQ0FQNEUsQ0FTNUU7O0FBQ0FaLGVBQVNTLHlCQUFULENBQW1DekMsTUFBbkMsQ0FBMEM2QyxjQUExQztBQUNBO0FBQ0Q7QUFHRCxDQTVHRDtBQThHQTFCLE9BQU9DLE9BQVAsQ0FBZTtBQUNkLHVCQUFxQixVQUFTUixPQUFULEVBQWtCO0FBQ3RDLFFBQUcsQ0FBQ3VDLE1BQU1DLE9BQU4sQ0FBY2pDLE9BQU9oQyxNQUFQLEVBQWQsQ0FBSixFQUFvQztBQUNuQyxZQUFNLElBQUlnQyxPQUFPRSxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLGdCQUF0QixDQUFOO0FBQ0E7O0FBRUQsUUFBSWdDLGNBQWMsRUFBbEI7QUFDQSxRQUFHekMsUUFBUTBDLFFBQVgsRUFBcUJELFlBQVlDLFFBQVosR0FBdUIxQyxRQUFRMEMsUUFBL0I7QUFDckIsUUFBRzFDLFFBQVEyQyxLQUFYLEVBQWtCRixZQUFZRSxLQUFaLEdBQW9CM0MsUUFBUTJDLEtBQTVCO0FBQ2xCLFFBQUczQyxRQUFRNEMsUUFBWCxFQUFxQkgsWUFBWUcsUUFBWixHQUF1QjVDLFFBQVE0QyxRQUEvQjtBQUNyQixRQUFHNUMsUUFBUTZDLE9BQVgsRUFBb0JKLFlBQVlJLE9BQVosR0FBc0I3QyxRQUFRNkMsT0FBOUI7QUFDcEIsUUFBRzdDLFFBQVE2QyxPQUFSLElBQW1CN0MsUUFBUTZDLE9BQVIsQ0FBZ0JGLEtBQXRDLEVBQTZDRixZQUFZRSxLQUFaLEdBQW9CM0MsUUFBUTZDLE9BQVIsQ0FBZ0JGLEtBQXBDO0FBRTdDdkIsYUFBUzBCLFVBQVQsQ0FBb0JMLFdBQXBCO0FBQ0EsR0FkYTtBQWVkLHVCQUFxQixVQUFTbEUsTUFBVCxFQUFpQnlCLE9BQWpCLEVBQTBCO0FBQzlDO0FBQ0EsUUFBRyxFQUFFdUMsTUFBTUMsT0FBTixDQUFjakMsT0FBT2hDLE1BQVAsRUFBZCxLQUFrQ0EsVUFBVWdDLE9BQU9oQyxNQUFQLEVBQTlDLENBQUgsRUFBbUU7QUFDbEUsWUFBTSxJQUFJZ0MsT0FBT0UsS0FBWCxDQUFpQixHQUFqQixFQUFzQixnQkFBdEIsQ0FBTjtBQUNBLEtBSjZDLENBTTlDOzs7QUFDQSxRQUFHLENBQUM4QixNQUFNQyxPQUFOLENBQWNqQyxPQUFPaEMsTUFBUCxFQUFkLENBQUosRUFBb0M7QUFDbkMsVUFBSXdFLE9BQU9DLE9BQU9ELElBQVAsQ0FBWS9DLE9BQVosQ0FBWDs7QUFDQSxVQUFHK0MsS0FBSzFILE1BQUwsS0FBZ0IsQ0FBaEIsSUFBcUIsQ0FBQzJFLFFBQVE2QyxPQUFqQyxFQUEwQztBQUN6QyxjQUFNLElBQUl0QyxPQUFPRSxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLGdCQUF0QixDQUFOO0FBQ0E7QUFDRDs7QUFFRCxRQUFJZ0MsY0FBYyxFQUFsQjtBQUNBLFFBQUd6QyxRQUFRMEMsUUFBWCxFQUFxQkQsWUFBWUMsUUFBWixHQUF1QjFDLFFBQVEwQyxRQUEvQjtBQUNyQixRQUFHMUMsUUFBUTJDLEtBQVgsRUFBa0JGLFlBQVlFLEtBQVosR0FBb0IzQyxRQUFRMkMsS0FBNUI7QUFDbEIsUUFBRzNDLFFBQVE0QyxRQUFYLEVBQXFCSCxZQUFZRyxRQUFaLEdBQXVCNUMsUUFBUTRDLFFBQS9CO0FBQ3JCLFFBQUc1QyxRQUFRNkMsT0FBWCxFQUFvQkosWUFBWUksT0FBWixHQUFzQjdDLFFBQVE2QyxPQUE5QjtBQUVwQixRQUFHN0MsUUFBUTZDLE9BQVIsSUFBbUI3QyxRQUFRNkMsT0FBUixDQUFnQkYsS0FBdEMsRUFBNkNGLFlBQVlFLEtBQVosR0FBb0IzQyxRQUFRNkMsT0FBUixDQUFnQkYsS0FBcEM7QUFDN0MsUUFBRzNDLFFBQVFpRCxLQUFYLEVBQWtCUixZQUFZUSxLQUFaLEdBQW9CakQsUUFBUWlELEtBQTVCOztBQUVsQixRQUFHUixZQUFZRSxLQUFmLEVBQXNCO0FBQ3JCLFVBQUlBLFFBQVFGLFlBQVlFLEtBQXhCO0FBQ0EsYUFBT0YsWUFBWUUsS0FBbkI7QUFDQSxVQUFJTyxXQUFXWCxNQUFNNUIsT0FBTixDQUFjLEtBQUtwQyxNQUFuQixDQUFmOztBQUNBLFVBQUcyRSxTQUFTQyxNQUFULElBQW1CLENBQUNELFNBQVNDLE1BQVQsQ0FBZ0J4RixJQUFoQixDQUFxQixVQUFTeUYsSUFBVCxFQUFlO0FBQUUsZUFBT0EsS0FBS0MsT0FBTCxJQUFnQlYsS0FBdkI7QUFBK0IsT0FBckUsQ0FBdkIsRUFBK0Y7QUFDOUZGLG9CQUFZVSxNQUFaLEdBQXFCLENBQUM7QUFBRUUsbUJBQVNWO0FBQVgsU0FBRCxDQUFyQjtBQUNBO0FBQ0Q7O0FBRUQsUUFBSUMsV0FBVyxFQUFmOztBQUNBLFFBQUdILFlBQVlHLFFBQWYsRUFBeUI7QUFDeEJBLGlCQUFXSCxZQUFZRyxRQUF2QjtBQUNBLGFBQU9ILFlBQVlHLFFBQW5CO0FBQ0E7O0FBRUQsUUFBR0gsV0FBSCxFQUFnQjtBQUNmLFdBQUksSUFBSTVHLEdBQVIsSUFBZTRHLFdBQWYsRUFBNEI7QUFDM0IsWUFBSXhILE1BQU13SCxZQUFZNUcsR0FBWixDQUFWOztBQUNBLFlBQUdRLEVBQUVxRixRQUFGLENBQVd6RyxHQUFYLENBQUgsRUFBb0I7QUFDbkIsZUFBSSxJQUFJVyxDQUFSLElBQWFYLEdBQWIsRUFBa0I7QUFDakJ3SCx3QkFBWTVHLE1BQU0sR0FBTixHQUFZRCxDQUF4QixJQUE2QlgsSUFBSVcsQ0FBSixDQUE3QjtBQUNBOztBQUNELGlCQUFPNkcsWUFBWTVHLEdBQVosQ0FBUDtBQUNBO0FBQ0Q7O0FBQ0QwRyxZQUFNbEQsTUFBTixDQUFhZCxNQUFiLEVBQXFCO0FBQUUwQixjQUFNd0M7QUFBUixPQUFyQjtBQUNBOztBQUVELFFBQUdHLFFBQUgsRUFBYTtBQUNaeEIsZUFBU2tDLFdBQVQsQ0FBcUIvRSxNQUFyQixFQUE2QnFFLFFBQTdCO0FBQ0E7QUFDRCxHQXJFYTtBQXVFZCxjQUFZLFVBQVM1QyxPQUFULEVBQWtCO0FBQzdCLFNBQUt1RCxPQUFMO0FBRUFDLFVBQU1DLElBQU4sQ0FBV3pELE9BQVg7QUFDQTtBQTNFYSxDQUFmO0FBOEVBb0IsU0FBU3NDLFlBQVQsQ0FBc0IsVUFBVTFELE9BQVYsRUFBbUIyRCxJQUFuQixFQUF5QjtBQUM5Q0EsT0FBS1YsS0FBTCxHQUFhLENBQUMsTUFBRCxDQUFiOztBQUVBLE1BQUdqRCxRQUFRNkMsT0FBWCxFQUFvQjtBQUNuQmMsU0FBS2QsT0FBTCxHQUFlN0MsUUFBUTZDLE9BQXZCO0FBQ0E7O0FBRUQsTUFBRyxDQUFDTixNQUFNNUIsT0FBTixDQUFjO0FBQUVzQyxXQUFPO0FBQVQsR0FBZCxDQUFELElBQXNDVSxLQUFLVixLQUFMLENBQVdXLE9BQVgsQ0FBbUIsT0FBbkIsSUFBOEIsQ0FBdkUsRUFBMEU7QUFDekVELFNBQUtWLEtBQUwsR0FBYSxDQUFDLE9BQUQsQ0FBYjtBQUNDOztBQUVGLFNBQU9VLElBQVA7QUFDQSxDQVpEO0FBY0F2QyxTQUFTeUMsb0JBQVQsQ0FBOEIsVUFBU0MsSUFBVCxFQUFlO0FBRTVDO0FBQ0EsTUFBR0EsS0FBS0gsSUFBTCxJQUFhcEIsTUFBTXdCLFFBQU4sQ0FBZUQsS0FBS0gsSUFBTCxDQUFVL0MsR0FBekIsRUFBOEIsU0FBOUIsQ0FBaEIsRUFBMEQ7QUFDekQsVUFBTSxJQUFJTCxPQUFPRSxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLDBCQUF0QixDQUFOO0FBQ0E7O0FBRUEsTUFBR1UsZUFBZTJDLEtBQUtILElBQXBCLElBQTRCRyxLQUFLSCxJQUFMLENBQVVSLE1BQXRDLElBQWdEVyxLQUFLSCxJQUFMLENBQVVSLE1BQVYsQ0FBaUI5SCxNQUFqRSxJQUEyRSxDQUFDeUksS0FBS0gsSUFBTCxDQUFVUixNQUFWLENBQWlCLENBQWpCLEVBQW9CYSxRQUFuRyxFQUE4RztBQUM3RyxVQUFNLElBQUl6RCxPQUFPRSxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLHNCQUF0QixDQUFOO0FBQ0E7O0FBRUYsU0FBTyxJQUFQO0FBQ0EsQ0FaRDtBQWVBOEIsTUFBTTlDLE1BQU4sQ0FBYUwsTUFBYixDQUFvQixVQUFTYixNQUFULEVBQWlCaEMsR0FBakIsRUFBc0I7QUFDekMsTUFBR0EsSUFBSTRHLE1BQUosSUFBYzVHLElBQUk0RyxNQUFKLENBQVcsQ0FBWCxDQUFkLElBQStCNUcsSUFBSTRHLE1BQUosQ0FBVyxDQUFYLEVBQWNFLE9BQWhELEVBQXlEO0FBQ3hEOUcsUUFBSXNHLE9BQUosR0FBY3RHLElBQUlzRyxPQUFKLElBQWUsRUFBN0I7QUFDQXRHLFFBQUlzRyxPQUFKLENBQVlGLEtBQVosR0FBb0JwRyxJQUFJNEcsTUFBSixDQUFXLENBQVgsRUFBY0UsT0FBbEM7QUFDQSxHQUhELE1BR087QUFDTjtBQUNBLFFBQUc5RyxJQUFJMEgsUUFBUCxFQUFpQjtBQUNoQjtBQUNBLFVBQUcxSCxJQUFJMEgsUUFBSixDQUFhbEMsTUFBYixJQUF1QnhGLElBQUkwSCxRQUFKLENBQWFsQyxNQUFiLENBQW9CWSxLQUE5QyxFQUFxRDtBQUNwRHBHLFlBQUlzRyxPQUFKLEdBQWN0RyxJQUFJc0csT0FBSixJQUFlLEVBQTdCO0FBQ0F0RyxZQUFJc0csT0FBSixDQUFZRixLQUFaLEdBQW9CcEcsSUFBSTBILFFBQUosQ0FBYWxDLE1BQWIsQ0FBb0JZLEtBQXhDO0FBQ0EsT0FIRCxNQUdPO0FBQ047QUFDQSxZQUFHcEcsSUFBSTBILFFBQUosQ0FBYS9CLE1BQWIsSUFBdUIzRixJQUFJMEgsUUFBSixDQUFhL0IsTUFBYixDQUFvQmdDLFdBQTlDLEVBQTJEO0FBQzFELGNBQUloQyxTQUFTLElBQUlpQyxNQUFKLENBQVc7QUFDdkJDLHFCQUFTLE9BRGM7QUFFdkJDLHFCQUFTO0FBRmMsV0FBWCxDQUFiO0FBS0FuQyxpQkFBT29DLFlBQVAsQ0FBb0I7QUFDbkJDLGtCQUFNLE9BRGE7QUFFbkJDLG1CQUFPakksSUFBSTBILFFBQUosQ0FBYS9CLE1BQWIsQ0FBb0JnQztBQUZSLFdBQXBCOztBQUtBLGNBQUk7QUFDSCxnQkFBSU8sU0FBU3ZDLE9BQU95QixJQUFQLENBQVllLFNBQVosQ0FBc0IsRUFBdEIsQ0FBYjs7QUFDQSxnQkFBSS9CLFFBQVF0RyxFQUFFc0ksU0FBRixDQUFZRixNQUFaLEVBQW9CO0FBQUVHLHVCQUFTO0FBQVgsYUFBcEIsQ0FBWjs7QUFDQSxnQkFBRyxDQUFDakMsS0FBRCxJQUFVOEIsT0FBT3BKLE1BQWpCLElBQTJCZ0IsRUFBRXdJLFFBQUYsQ0FBV0osT0FBTyxDQUFQLENBQVgsQ0FBOUIsRUFBcUQ7QUFDcEQ5QixzQkFBUTtBQUFFQSx1QkFBTzhCLE9BQU8sQ0FBUDtBQUFULGVBQVI7QUFDQTs7QUFFRCxnQkFBRzlCLEtBQUgsRUFBVTtBQUNUcEcsa0JBQUlzRyxPQUFKLEdBQWN0RyxJQUFJc0csT0FBSixJQUFlLEVBQTdCO0FBQ0F0RyxrQkFBSXNHLE9BQUosQ0FBWUYsS0FBWixHQUFvQkEsTUFBTUEsS0FBMUI7QUFDQTtBQUNELFdBWEQsQ0FXRSxPQUFNbUMsQ0FBTixFQUFTO0FBQ1ZDLG9CQUFRQyxHQUFSLENBQVlGLENBQVo7QUFDQTtBQUNELFNBekJELE1BeUJPO0FBQ047QUFDQSxjQUFHdkksSUFBSTBILFFBQUosQ0FBYTlCLFFBQWIsSUFBeUI1RixJQUFJMEgsUUFBSixDQUFhOUIsUUFBYixDQUFzQjhDLFlBQWxELEVBQWdFO0FBQy9EMUksZ0JBQUlzRyxPQUFKLEdBQWN0RyxJQUFJc0csT0FBSixJQUFlLEVBQTdCO0FBQ0F0RyxnQkFBSXNHLE9BQUosQ0FBWXFDLElBQVosR0FBbUIzSSxJQUFJMEgsUUFBSixDQUFhOUIsUUFBYixDQUFzQmdELFNBQXRCLEdBQWtDLEdBQWxDLEdBQXdDNUksSUFBSTBILFFBQUosQ0FBYTlCLFFBQWIsQ0FBc0JpRCxRQUFqRjtBQUNBN0ksZ0JBQUlzRyxPQUFKLENBQVlGLEtBQVosR0FBb0JwRyxJQUFJMEgsUUFBSixDQUFhOUIsUUFBYixDQUFzQjhDLFlBQTFDO0FBQ0EsV0FKRCxNQUlPO0FBQ04sZ0JBQUcxSSxJQUFJMEgsUUFBSixDQUFhN0IsUUFBYixJQUF5QjdGLElBQUkwSCxRQUFKLENBQWE3QixRQUFiLENBQXNCTyxLQUFsRCxFQUF5RDtBQUN4RHBHLGtCQUFJc0csT0FBSixHQUFjdEcsSUFBSXNHLE9BQUosSUFBZSxFQUE3QjtBQUNBdEcsa0JBQUlzRyxPQUFKLENBQVlGLEtBQVosR0FBb0JwRyxJQUFJMEgsUUFBSixDQUFhN0IsUUFBYixDQUFzQk8sS0FBMUM7QUFDQSxhQUhELE1BR087QUFDTixrQkFBR3BHLElBQUkwSCxRQUFKLENBQWE1QixPQUFiLElBQXdCOUYsSUFBSTBILFFBQUosQ0FBYTVCLE9BQWIsQ0FBcUJNLEtBQWhELEVBQXVEO0FBQ3REcEcsb0JBQUlzRyxPQUFKLEdBQWN0RyxJQUFJc0csT0FBSixJQUFlLEVBQTdCO0FBQ0F0RyxvQkFBSXNHLE9BQUosQ0FBWUYsS0FBWixHQUFvQnBHLElBQUkwSCxRQUFKLENBQWE1QixPQUFiLENBQXFCTSxLQUF6QztBQUNBLGVBSEQsTUFHTztBQUNOLG9CQUFHcEcsSUFBSTBILFFBQUosQ0FBYSxrQkFBYixLQUFvQzFILElBQUkwSCxRQUFKLENBQWEsa0JBQWIsRUFBaUNkLE1BQXJFLElBQStFNUcsSUFBSTBILFFBQUosQ0FBYSxrQkFBYixFQUFpQ2QsTUFBakMsQ0FBd0M5SCxNQUExSCxFQUFrSTtBQUNqSWtCLHNCQUFJc0csT0FBSixHQUFjdEcsSUFBSXNHLE9BQUosSUFBZSxFQUE3QjtBQUNBdEcsc0JBQUlzRyxPQUFKLENBQVlGLEtBQVosR0FBb0JwRyxJQUFJMEgsUUFBSixDQUFhLGtCQUFiLEVBQWlDZCxNQUFqQyxDQUF3QyxDQUF4QyxFQUEyQ0UsT0FBL0Q7QUFDQTtBQUNEO0FBQ0Q7QUFDRDtBQUNEO0FBQ0Q7QUFDRDtBQUNEO0FBQ0QsQ0FoRUQ7QUFrRUFkLE1BQU05QyxNQUFOLENBQWFKLE1BQWIsQ0FBb0IsVUFBU2QsTUFBVCxFQUFpQmhDLEdBQWpCLEVBQXNCd0QsVUFBdEIsRUFBa0NSLFFBQWxDLEVBQTRDUyxPQUE1QyxFQUFxRDtBQUN4RSxNQUFHVCxTQUFTVSxJQUFULElBQWlCVixTQUFTVSxJQUFULENBQWNrRCxNQUEvQixJQUF5QzVELFNBQVNVLElBQVQsQ0FBY2tELE1BQWQsQ0FBcUI5SCxNQUE5RCxJQUF3RWtFLFNBQVNVLElBQVQsQ0FBY2tELE1BQWQsQ0FBcUIsQ0FBckIsRUFBd0JFLE9BQW5HLEVBQTRHO0FBQzNHOUQsYUFBU1UsSUFBVCxDQUFjNEMsT0FBZCxDQUFzQkYsS0FBdEIsR0FBOEJwRCxTQUFTVSxJQUFULENBQWNrRCxNQUFkLENBQXFCLENBQXJCLEVBQXdCRSxPQUF0RDtBQUNBO0FBQ0QsQ0FKRDtBQU1BakMsU0FBU2lFLE9BQVQsQ0FBaUIsVUFBVXZCLElBQVYsRUFBZ0IsQ0FFaEMsQ0FGRDs7QUFJQTFDLFNBQVNrRSxJQUFULENBQWNDLGFBQWQsR0FBOEIsVUFBVWYsS0FBVixFQUFpQjtBQUM5QyxTQUFPakUsT0FBT2lGLFdBQVAsQ0FBbUIsb0JBQW9CaEIsS0FBdkMsQ0FBUDtBQUNBLENBRkQ7O0FBSUFwRCxTQUFTa0UsSUFBVCxDQUFjbkUsV0FBZCxHQUE0QixVQUFVcUQsS0FBVixFQUFpQjtBQUM1QyxTQUFPakUsT0FBT2lGLFdBQVAsQ0FBbUIsa0JBQWtCaEIsS0FBckMsQ0FBUDtBQUNBLENBRkQ7O0FBSUFwRCxTQUFTa0UsSUFBVCxDQUFjRyxhQUFkLEdBQThCLFVBQVVqQixLQUFWLEVBQWlCO0FBQzlDLFNBQU9qRSxPQUFPaUYsV0FBUCxDQUFtQixxQkFBcUJoQixLQUF4QyxDQUFQO0FBQ0EsQ0FGRCxDIiwiZmlsZSI6Ii9hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJ2YXIgaGFzU3BhY2UgPSAvXFxzL1xudmFyIGhhc1NlcGFyYXRvciA9IC9bXFxXX10vXG52YXIgaGFzQ2FtZWwgPSAvKFthLXpdW0EtWl18W0EtWl1bYS16XSkvXG5cbi8qKlxuICogUmVtb3ZlIGFueSBzdGFydGluZyBjYXNlIGZyb20gYSBgc3RyaW5nYCwgbGlrZSBjYW1lbCBvciBzbmFrZSwgYnV0IGtlZXBcbiAqIHNwYWNlcyBhbmQgcHVuY3R1YXRpb24gdGhhdCBtYXkgYmUgaW1wb3J0YW50IG90aGVyd2lzZS5cbiAqXG4gKiBAcGFyYW0ge1N0cmluZ30gc3RyaW5nXG4gKiBAcmV0dXJuIHtTdHJpbmd9XG4gKi9cblxudGhpcy50b05vQ2FzZSA9IGZ1bmN0aW9uKHN0cmluZykge1xuICBpZiAoaGFzU3BhY2UudGVzdChzdHJpbmcpKSByZXR1cm4gc3RyaW5nLnRvTG93ZXJDYXNlKCk7XG4gIGlmIChoYXNTZXBhcmF0b3IudGVzdChzdHJpbmcpKSByZXR1cm4gKHVuc2VwYXJhdGUoc3RyaW5nKSB8fCBzdHJpbmcpLnRvTG93ZXJDYXNlKCk7XG4gIGlmIChoYXNDYW1lbC50ZXN0KHN0cmluZykpIHJldHVybiB1bmNhbWVsaXplKHN0cmluZykudG9Mb3dlckNhc2UoKTtcbiAgcmV0dXJuIHN0cmluZy50b0xvd2VyQ2FzZSgpO1xufTtcblxuLyoqXG4gKiBTZXBhcmF0b3Igc3BsaXR0ZXIuXG4gKi9cblxudmFyIHNlcGFyYXRvclNwbGl0dGVyID0gL1tcXFdfXSsoLnwkKS9nXG5cbi8qKlxuICogVW4tc2VwYXJhdGUgYSBgc3RyaW5nYC5cbiAqXG4gKiBAcGFyYW0ge1N0cmluZ30gc3RyaW5nXG4gKiBAcmV0dXJuIHtTdHJpbmd9XG4gKi9cblxuZnVuY3Rpb24gdW5zZXBhcmF0ZShzdHJpbmcpIHtcbiAgcmV0dXJuIHN0cmluZy5yZXBsYWNlKHNlcGFyYXRvclNwbGl0dGVyLCBmdW5jdGlvbiAobSwgbmV4dCkge1xuICAgIHJldHVybiBuZXh0ID8gJyAnICsgbmV4dCA6ICcnO1xuICB9KTtcbn1cblxuLyoqXG4gKiBDYW1lbGNhc2Ugc3BsaXR0ZXIuXG4gKi9cblxudmFyIGNhbWVsU3BsaXR0ZXIgPSAvKC4pKFtBLVpdKykvZ1xuXG4vKipcbiAqIFVuLWNhbWVsY2FzZSBhIGBzdHJpbmdgLlxuICpcbiAqIEBwYXJhbSB7U3RyaW5nfSBzdHJpbmdcbiAqIEByZXR1cm4ge1N0cmluZ31cbiAqL1xuXG5mdW5jdGlvbiB1bmNhbWVsaXplKHN0cmluZykge1xuICByZXR1cm4gc3RyaW5nLnJlcGxhY2UoY2FtZWxTcGxpdHRlciwgZnVuY3Rpb24gKG0sIHByZXZpb3VzLCB1cHBlcnMpIHtcbiAgICByZXR1cm4gcHJldmlvdXMgKyAnICcgKyB1cHBlcnMudG9Mb3dlckNhc2UoKS5zcGxpdCgnJykuam9pbignICcpO1xuICB9KTtcbn1cblxudGhpcy50b1NwYWNlQ2FzZSA9IGZ1bmN0aW9uKHN0cmluZykge1xuICByZXR1cm4gdG9Ob0Nhc2Uoc3RyaW5nKS5yZXBsYWNlKC9bXFxXX10rKC58JCkvZywgZnVuY3Rpb24gKG1hdGNoZXMsIG1hdGNoKSB7XG4gICAgcmV0dXJuIG1hdGNoID8gJyAnICsgbWF0Y2ggOiAnJztcbiAgfSkudHJpbSgpO1xufTtcblxudGhpcy50b0NhbWVsQ2FzZSA9IGZ1bmN0aW9uKHN0cmluZykge1xuICByZXR1cm4gdG9TcGFjZUNhc2Uoc3RyaW5nKS5yZXBsYWNlKC9cXHMoXFx3KS9nLCBmdW5jdGlvbiAobWF0Y2hlcywgbGV0dGVyKSB7XG4gICAgcmV0dXJuIGxldHRlci50b1VwcGVyQ2FzZSgpO1xuICB9KTtcbn07XG5cbnRoaXMudG9TbmFrZUNhc2UgPSBmdW5jdGlvbihzdHJpbmcpIHtcbiAgcmV0dXJuIHRvU3BhY2VDYXNlKHN0cmluZykucmVwbGFjZSgvXFxzL2csICdfJyk7XG59O1xuXG50aGlzLnRvS2ViYWJDYXNlID0gZnVuY3Rpb24oc3RyaW5nKSB7XG4gIHJldHVybiB0b1NwYWNlQ2FzZShzdHJpbmcpLnJlcGxhY2UoL1xccy9nLCAnLScpO1xufTtcblxudGhpcy50b1RpdGxlQ2FzZSA9IGZ1bmN0aW9uKHN0cmluZykge1xuICB2YXIgc3RyID0gdG9TcGFjZUNhc2Uoc3RyaW5nKS5yZXBsYWNlKC9cXHMoXFx3KS9nLCBmdW5jdGlvbihtYXRjaGVzLCBsZXR0ZXIpIHtcbiAgICByZXR1cm4gXCIgXCIgKyBsZXR0ZXIudG9VcHBlckNhc2UoKTtcbiAgfSk7XG5cbiAgaWYoc3RyKSB7XG4gICAgc3RyID0gc3RyLmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpICsgc3RyLnNsaWNlKDEpO1xuICB9XG4gIHJldHVybiBzdHI7XG59O1xuIiwiLypcbiAgIFJldHVybnMgcHJvcGVydHkgdmFsdWUsIHdoZXJlIHByb3BlcnR5IG5hbWUgaXMgZ2l2ZW4gYXMgcGF0aC5cblxuICAgRXhhbXBsZTpcblxuICAgICAgIGdldFByb3BlcnR5VmFsdWUoXCJ4LnkuelwiLCB7IHg6IHsgeTogeyB6OiAxMjMgfSB9IH0pOyAvLyByZXR1cm5zIDEyM1xuKi9cblxudGhpcy5nZXRQcm9wZXJ0eVZhbHVlID0gZnVuY3Rpb24ocHJvcGVydHlOYW1lLCBvYmopIHtcblx0dmFyIHByb3BzID0gcHJvcGVydHlOYW1lLnNwbGl0KFwiLlwiKTtcblx0dmFyIHJlcyA9IG9iajtcblx0Zm9yKHZhciBpID0gMDsgaSA8IHByb3BzLmxlbmd0aDsgaSsrKSB7XG5cdFx0cmVzID0gcmVzW3Byb3BzW2ldXTtcblx0XHRpZih0eXBlb2YgcmVzID09IFwidW5kZWZpbmVkXCIpIHtcblx0XHRcdHJldHVybiByZXM7XG5cdFx0fVxuXHR9XG5cdHJldHVybiByZXM7XG59O1xuXG5cbi8qIFxuICAgY29udmVydHMgcHJvcGVydGllcyBpbiBmb3JtYXQgeyBcIngueVwiOiBcInpcIiB9IHRvIHsgeDogeyB5OiBcInpcIiB9IH1cbiovXG5cbnRoaXMuZGVlcGVuID0gZnVuY3Rpb24obykge1xuXHR2YXIgb28gPSB7fSwgdCwgcGFydHMsIHBhcnQ7XG5cdGZvciAodmFyIGsgaW4gbykge1xuXHRcdHQgPSBvbztcblx0XHRwYXJ0cyA9IGsuc3BsaXQoJy4nKTtcblx0XHR2YXIga2V5ID0gcGFydHMucG9wKCk7XG5cdFx0d2hpbGUgKHBhcnRzLmxlbmd0aCkge1xuXHRcdFx0cGFydCA9IHBhcnRzLnNoaWZ0KCk7XG5cdFx0XHR0ID0gdFtwYXJ0XSA9IHRbcGFydF0gfHwge307XG5cdFx0fVxuXHRcdHRba2V5XSA9IG9ba107XG5cdH1cblx0cmV0dXJuIG9vO1xufTtcblxuLypcblx0RnVuY3Rpb24gY29udmVydHMgYXJyYXkgb2Ygb2JqZWN0cyB0byBjc3YsIHRzdiBvciBqc29uIHN0cmluZ1xuXG5cdGV4cG9ydEZpZWxkczogbGlzdCBvZiBvYmplY3Qga2V5cyB0byBleHBvcnQgKGFycmF5IG9mIHN0cmluZ3MpXG5cdGZpbGVUeXBlOiBjYW4gYmUgXCJqc29uXCIsIFwiY3N2XCIsIFwidHN2XCIgKHN0cmluZylcbiovXG5cbnRoaXMuZXhwb3J0QXJyYXlPZk9iamVjdHMgPSBmdW5jdGlvbihkYXRhLCBleHBvcnRGaWVsZHMsIGZpbGVUeXBlKSB7XG5cdGRhdGEgPSBkYXRhIHx8IFtdO1xuXHRmaWxlVHlwZSA9IGZpbGVUeXBlIHx8IFwiY3N2XCI7XG5cdGV4cG9ydEZpZWxkcyA9IGV4cG9ydEZpZWxkcyB8fCBbXTtcblxuXHR2YXIgc3RyID0gXCJcIjtcblx0Ly8gZXhwb3J0IHRvIEpTT05cblx0aWYoZmlsZVR5cGUgPT0gXCJqc29uXCIpIHtcblxuXHRcdHZhciB0bXAgPSBbXTtcblx0XHRfLmVhY2goZGF0YSwgZnVuY3Rpb24oZG9jKSB7XG5cdFx0XHR2YXIgb2JqID0ge307XG5cdFx0XHRfLmVhY2goZXhwb3J0RmllbGRzLCBmdW5jdGlvbihmaWVsZCkge1xuXHRcdFx0XHRvYmpbZmllbGRdID0gZG9jW2ZpZWxkXTtcblx0XHRcdH0pO1xuXHRcdFx0dG1wLnB1c2gob2JqKTtcblx0XHR9KTtcblxuXHRcdHN0ciA9IEpTT04uc3RyaW5naWZ5KHRtcCk7XG5cdH1cblxuXHQvLyBleHBvcnQgdG8gQ1NWIG9yIFRTVlxuXHRpZihmaWxlVHlwZSA9PSBcImNzdlwiIHx8IGZpbGVUeXBlID09IFwidHN2XCIpIHtcblx0XHR2YXIgY29sdW1uU2VwYXJhdG9yID0gXCJcIjtcblx0XHRpZihmaWxlVHlwZSA9PSBcImNzdlwiKSB7XG5cdFx0XHRjb2x1bW5TZXBhcmF0b3IgPSBcIixcIjtcblx0XHR9XG5cdFx0aWYoZmlsZVR5cGUgPT0gXCJ0c3ZcIikge1xuXHRcdFx0Ly8gXCJcXHRcIiBvYmplY3QgbGl0ZXJhbCBkb2VzIG5vdCB0cmFuc3BpbGUgY29ycmVjdGx5IHRvIGNvZmZlZXNjdGlwdFxuXHRcdFx0Y29sdW1uU2VwYXJhdG9yID0gU3RyaW5nLmZyb21DaGFyQ29kZSg5KTtcblx0XHR9XG5cblx0XHRfLmVhY2goZXhwb3J0RmllbGRzLCBmdW5jdGlvbihmaWVsZCwgaSkge1xuXHRcdFx0aWYoaSA+IDApIHtcblx0XHRcdFx0c3RyID0gc3RyICsgY29sdW1uU2VwYXJhdG9yO1xuXHRcdFx0fVxuXHRcdFx0c3RyID0gc3RyICsgXCJcXFwiXCIgKyBmaWVsZCArIFwiXFxcIlwiO1xuXHRcdH0pO1xuXHRcdC8vXFxyIGRvZXMgbm90IHRyYW5zcGlsZSBjb3JyZWN0bHkgdG8gY29mZmVlc2NyaXB0XG5cdFx0c3RyID0gc3RyICsgU3RyaW5nLmZyb21DaGFyQ29kZSgxMykgKyBcIlxcblwiO1xuXG5cdFx0Xy5lYWNoKGRhdGEsIGZ1bmN0aW9uKGRvYykge1xuXHRcdFx0Xy5lYWNoKGV4cG9ydEZpZWxkcywgZnVuY3Rpb24oZmllbGQsIGkpIHtcblx0XHRcdFx0aWYoaSA+IDApIHtcblx0XHRcdFx0XHRzdHIgPSBzdHIgKyBjb2x1bW5TZXBhcmF0b3I7XG5cdFx0XHRcdH1cblxuXHRcdFx0XHR2YXIgdmFsdWUgPSBnZXRQcm9wZXJ0eVZhbHVlKGZpZWxkLCBkb2MpICsgXCJcIjtcblx0XHRcdFx0dmFsdWUgPSB2YWx1ZS5yZXBsYWNlKC9cIi9nLCAnXCJcIicpO1xuXHRcdFx0XHRpZih0eXBlb2YodmFsdWUpID09IFwidW5kZWZpbmVkXCIpXG5cdFx0XHRcdFx0c3RyID0gc3RyICsgXCJcXFwiXFxcIlwiO1xuXHRcdFx0XHRlbHNlXG5cdFx0XHRcdFx0c3RyID0gc3RyICsgXCJcXFwiXCIgKyB2YWx1ZSArIFwiXFxcIlwiO1xuXHRcdFx0fSk7XG5cdFx0XHQvL1xcciBkb2VzIG5vdCB0cmFuc3BpbGUgY29ycmVjdGx5IHRvIGNvZmZlZXNjcmlwdFxuXHRcdFx0c3RyID0gc3RyICsgU3RyaW5nLmZyb21DaGFyQ29kZSgxMykgKyBcIlxcblwiO1xuXHRcdH0pO1xuXHR9XG5cblx0cmV0dXJuIHN0cjtcbn07XG5cblxudGhpcy5tZXJnZU9iamVjdHMgPSBmdW5jdGlvbih0YXJnZXQsIHNvdXJjZSkge1xuXG5cdC8qIE1lcmdlcyB0d28gKG9yIG1vcmUpIG9iamVjdHMsXG5cdGdpdmluZyB0aGUgbGFzdCBvbmUgcHJlY2VkZW5jZSAqL1xuXG5cdGlmKHR5cGVvZiB0YXJnZXQgIT09IFwib2JqZWN0XCIpIHtcblx0XHR0YXJnZXQgPSB7fTtcblx0fVxuXG5cdGZvcih2YXIgcHJvcGVydHkgaW4gc291cmNlKSB7XG5cblx0XHRpZihzb3VyY2UuaGFzT3duUHJvcGVydHkocHJvcGVydHkpKSB7XG5cblx0XHRcdHZhciBzb3VyY2VQcm9wZXJ0eSA9IHNvdXJjZVsgcHJvcGVydHkgXTtcblxuXHRcdFx0aWYodHlwZW9mIHNvdXJjZVByb3BlcnR5ID09PSAnb2JqZWN0Jykge1xuXHRcdFx0XHR0YXJnZXRbcHJvcGVydHldID0gbWVyZ2VPYmplY3RzKHRhcmdldFtwcm9wZXJ0eV0sIHNvdXJjZVByb3BlcnR5KTtcblx0XHRcdFx0Y29udGludWU7XG5cdFx0XHR9XG5cblx0XHRcdHRhcmdldFtwcm9wZXJ0eV0gPSBzb3VyY2VQcm9wZXJ0eTtcblx0XHR9XG5cdH1cblxuXHRmb3IodmFyIGEgPSAyLCBsID0gYXJndW1lbnRzLmxlbmd0aDsgYSA8IGw7IGErKykge1xuXHRcdG1lcmdlT2JqZWN0cyh0YXJnZXQsIGFyZ3VtZW50c1thXSk7XG5cdH1cblxuXHRyZXR1cm4gdGFyZ2V0O1xufTtcbiIsInRoaXMuZXNjYXBlUmVnRXggPSBmdW5jdGlvbiAoc3RyaW5nKSB7XG5cdHJldHVybiBzdHJpbmcucmVwbGFjZSgvKFsuKis/Xj0hOiR7fSgpfFxcW1xcXVxcL1xcXFxdKS9nLCBcIlxcXFwkMVwiKTtcbn1cblxudGhpcy5yZXBsYWNlU3Vic3RyaW5ncyA9IGZ1bmN0aW9uKHN0cmluZywgZmluZCwgcmVwbGFjZSkge1xuXHRyZXR1cm4gc3RyaW5nLnJlcGxhY2UobmV3IFJlZ0V4cChlc2NhcGVSZWdFeChmaW5kKSwgJ2cnKSwgcmVwbGFjZSk7XG59O1xuXG50aGlzLmpvaW5TdHJpbmdzID0gZnVuY3Rpb24oc3RyaW5nQXJyYXksIGpvaW4pIHtcblx0dmFyIHNlcCA9IGpvaW4gfHwgXCIsIFwiO1xuXHR2YXIgcmVzID0gXCJcIjtcblx0Xy5lYWNoKHN0cmluZ0FycmF5LCBmdW5jdGlvbihzdHIpIHtcblx0XHRpZihzdHIpIHtcblx0XHRcdGlmKHJlcylcblx0XHRcdFx0cmVzID0gcmVzICsgc2VwO1xuXHRcdFx0cmVzID0gcmVzICsgc3RyO1xuXHRcdH1cdFx0XG5cdH0pO1xuXHRyZXR1cm4gcmVzO1xufTtcblxudGhpcy5jb252ZXJ0VG9TbHVnID0gZnVuY3Rpb24odGV4dCkge1xuICByZXR1cm4gdGV4dC50b1N0cmluZygpLnRvTG93ZXJDYXNlKClcbiAgICAucmVwbGFjZSgvXFxzKy9nLCAnLScpICAgICAgICAgICAvLyBSZXBsYWNlIHNwYWNlcyB3aXRoIC1cbiAgICAucmVwbGFjZSgvW15cXHdcXC1dKy9nLCAnJykgICAgICAgLy8gUmVtb3ZlIGFsbCBub24td29yZCBjaGFyc1xuICAgIC5yZXBsYWNlKC9cXC1cXC0rL2csICctJykgICAgICAgICAvLyBSZXBsYWNlIG11bHRpcGxlIC0gd2l0aCBzaW5nbGUgLVxuICAgIC5yZXBsYWNlKC9eLSsvLCAnJykgICAgICAgICAgICAgLy8gVHJpbSAtIGZyb20gc3RhcnQgb2YgdGV4dFxuICAgIC5yZXBsYWNlKC8tKyQvLCAnJyk7ICAgICAgICAgICAgLy8gVHJpbSAtIGZyb20gZW5kIG9mIHRleHRcbn07XG4iLCJ0aGlzLkNvbnRyYXRpc3RhcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKFwiY29udHJhdGlzdGFzXCIpO1xuXG50aGlzLkNvbnRyYXRpc3Rhcy51c2VyQ2FuSW5zZXJ0ID0gZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0cmV0dXJuIHRydWU7XG59O1xuXG50aGlzLkNvbnRyYXRpc3Rhcy51c2VyQ2FuVXBkYXRlID0gZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0cmV0dXJuIHRydWU7XG59O1xuXG50aGlzLkNvbnRyYXRpc3Rhcy51c2VyQ2FuUmVtb3ZlID0gZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0cmV0dXJuIHRydWU7XG59O1xuIiwidGhpcy5JbnZlbnRhcmlvID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oXCJpbnZlbnRhcmlvXCIpO1xuXG50aGlzLkludmVudGFyaW8udXNlckNhbkluc2VydCA9IGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdHJldHVybiB0cnVlO1xufTtcblxudGhpcy5JbnZlbnRhcmlvLnVzZXJDYW5VcGRhdGUgPSBmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRyZXR1cm4gdHJ1ZTtcbn07XG5cbnRoaXMuSW52ZW50YXJpby51c2VyQ2FuUmVtb3ZlID0gZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0cmV0dXJuIHRydWU7XG59O1xuIiwidGhpcy5NYXRlcmlhbGVzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oXCJtYXRlcmlhbGVzXCIpO1xuXG50aGlzLk1hdGVyaWFsZXMudXNlckNhbkluc2VydCA9IGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdHJldHVybiB0cnVlO1xufTtcblxudGhpcy5NYXRlcmlhbGVzLnVzZXJDYW5VcGRhdGUgPSBmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRyZXR1cm4gdHJ1ZTtcbn07XG5cbnRoaXMuTWF0ZXJpYWxlcy51c2VyQ2FuUmVtb3ZlID0gZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0cmV0dXJuIHRydWU7XG59O1xuIiwidGhpcy5PcmRlbmVzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oXCJvcmRlbmVzXCIpO1xuXG50aGlzLk9yZGVuZXMudXNlckNhbkluc2VydCA9IGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdHJldHVybiB0cnVlO1xufTtcblxudGhpcy5PcmRlbmVzLnVzZXJDYW5VcGRhdGUgPSBmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRyZXR1cm4gdHJ1ZTtcbn07XG5cbnRoaXMuT3JkZW5lcy51c2VyQ2FuUmVtb3ZlID0gZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0cmV0dXJuIHRydWU7XG59O1xuIiwidGhpcy5PcmRlbmVzSXRlbXMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbihcIm9yZGVuZXNfaXRlbXNcIik7XG5cbnRoaXMuT3JkZW5lc0l0ZW1zLnVzZXJDYW5JbnNlcnQgPSBmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRyZXR1cm4gdHJ1ZTtcbn07XG5cbnRoaXMuT3JkZW5lc0l0ZW1zLnVzZXJDYW5VcGRhdGUgPSBmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRyZXR1cm4gdHJ1ZTtcbn07XG5cbnRoaXMuT3JkZW5lc0l0ZW1zLnVzZXJDYW5SZW1vdmUgPSBmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRyZXR1cm4gdHJ1ZTtcbn07XG4iLCJ0aGlzLlByb3ZlZWRvcmVzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oXCJwcm92ZWVkb3Jlc1wiKTtcblxudGhpcy5Qcm92ZWVkb3Jlcy51c2VyQ2FuSW5zZXJ0ID0gZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0cmV0dXJuIHRydWU7XG59O1xuXG50aGlzLlByb3ZlZWRvcmVzLnVzZXJDYW5VcGRhdGUgPSBmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRyZXR1cm4gdHJ1ZTtcbn07XG5cbnRoaXMuUHJvdmVlZG9yZXMudXNlckNhblJlbW92ZSA9IGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdHJldHVybiB0cnVlO1xufTtcbiIsInRoaXMuUHJveWVjdG9zID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oXCJwcm95ZWN0b3NcIik7XG5cbnRoaXMuUHJveWVjdG9zLnVzZXJDYW5JbnNlcnQgPSBmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRyZXR1cm4gdHJ1ZTtcbn07XG5cbnRoaXMuUHJveWVjdG9zLnVzZXJDYW5VcGRhdGUgPSBmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRyZXR1cm4gdHJ1ZTtcbn07XG5cbnRoaXMuUHJveWVjdG9zLnVzZXJDYW5SZW1vdmUgPSBmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRyZXR1cm4gdHJ1ZTtcbn07XG4iLCJ0aGlzLlJlcXVpc2ljaW9uZXMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbihcInJlcXVpc2ljaW9uZXNcIik7XG5cbnRoaXMuUmVxdWlzaWNpb25lcy51c2VyQ2FuSW5zZXJ0ID0gZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0cmV0dXJuIHRydWU7XG59O1xuXG50aGlzLlJlcXVpc2ljaW9uZXMudXNlckNhblVwZGF0ZSA9IGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdHJldHVybiB0cnVlO1xufTtcblxudGhpcy5SZXF1aXNpY2lvbmVzLnVzZXJDYW5SZW1vdmUgPSBmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRyZXR1cm4gdHJ1ZTtcbn07XG4iLCJ0aGlzLlJlcXVpc2ljaW9uZXNJdGVtcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKFwicmVxdWlzaWNpb25lc19pdGVtc1wiKTtcblxudGhpcy5SZXF1aXNpY2lvbmVzSXRlbXMudXNlckNhbkluc2VydCA9IGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdHJldHVybiB0cnVlO1xufTtcblxudGhpcy5SZXF1aXNpY2lvbmVzSXRlbXMudXNlckNhblVwZGF0ZSA9IGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdHJldHVybiB0cnVlO1xufTtcblxudGhpcy5SZXF1aXNpY2lvbmVzSXRlbXMudXNlckNhblJlbW92ZSA9IGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdHJldHVybiB0cnVlO1xufTtcbiIsInRoaXMuVHJhbnNhY2Npb25lcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKFwidHJhbnNhY2Npb25lc1wiKTtcblxudGhpcy5UcmFuc2FjY2lvbmVzLnVzZXJDYW5JbnNlcnQgPSBmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRyZXR1cm4gdHJ1ZTtcbn07XG5cbnRoaXMuVHJhbnNhY2Npb25lcy51c2VyQ2FuVXBkYXRlID0gZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0cmV0dXJuIHRydWU7XG59O1xuXG50aGlzLlRyYW5zYWNjaW9uZXMudXNlckNhblJlbW92ZSA9IGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdHJldHVybiB0cnVlO1xufTtcbiIsIkNvbnRyYXRpc3Rhcy5hbGxvdyh7XG5cdGluc2VydDogZnVuY3Rpb24gKHVzZXJJZCwgZG9jKSB7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9LFxuXG5cdHVwZGF0ZTogZnVuY3Rpb24gKHVzZXJJZCwgZG9jLCBmaWVsZHMsIG1vZGlmaWVyKSB7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9LFxuXG5cdHJlbW92ZTogZnVuY3Rpb24gKHVzZXJJZCwgZG9jKSB7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9XG59KTtcblxuQ29udHJhdGlzdGFzLmJlZm9yZS5pbnNlcnQoZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0ZG9jLmNyZWF0ZWRBdCA9IG5ldyBEYXRlKCk7XG5cdGRvYy5jcmVhdGVkQnkgPSB1c2VySWQ7XG5cdGRvYy5tb2RpZmllZEF0ID0gZG9jLmNyZWF0ZWRBdDtcblx0ZG9jLm1vZGlmaWVkQnkgPSBkb2MuY3JlYXRlZEJ5O1xuXG5cdFxuXHRpZighZG9jLmNyZWF0ZWRCeSkgZG9jLmNyZWF0ZWRCeSA9IHVzZXJJZDtcbn0pO1xuXG5Db250cmF0aXN0YXMuYmVmb3JlLnVwZGF0ZShmdW5jdGlvbih1c2VySWQsIGRvYywgZmllbGROYW1lcywgbW9kaWZpZXIsIG9wdGlvbnMpIHtcblx0bW9kaWZpZXIuJHNldCA9IG1vZGlmaWVyLiRzZXQgfHwge307XG5cdG1vZGlmaWVyLiRzZXQubW9kaWZpZWRBdCA9IG5ldyBEYXRlKCk7XG5cdG1vZGlmaWVyLiRzZXQubW9kaWZpZWRCeSA9IHVzZXJJZDtcblxuXHRcbn0pO1xuXG5Db250cmF0aXN0YXMuYmVmb3JlLnVwc2VydChmdW5jdGlvbih1c2VySWQsIHNlbGVjdG9yLCBtb2RpZmllciwgb3B0aW9ucykge1xuXHRtb2RpZmllci4kc2V0ID0gbW9kaWZpZXIuJHNldCB8fCB7fTtcblx0bW9kaWZpZXIuJHNldC5tb2RpZmllZEF0ID0gbmV3IERhdGUoKTtcblx0bW9kaWZpZXIuJHNldC5tb2RpZmllZEJ5ID0gdXNlcklkO1xuXG5cdC8qQkVGT1JFX1VQU0VSVF9DT0RFKi9cbn0pO1xuXG5Db250cmF0aXN0YXMuYmVmb3JlLnJlbW92ZShmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRcbn0pO1xuXG5Db250cmF0aXN0YXMuYWZ0ZXIuaW5zZXJ0KGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdFxufSk7XG5cbkNvbnRyYXRpc3Rhcy5hZnRlci51cGRhdGUoZnVuY3Rpb24odXNlcklkLCBkb2MsIGZpZWxkTmFtZXMsIG1vZGlmaWVyLCBvcHRpb25zKSB7XG5cdFxufSk7XG5cbkNvbnRyYXRpc3Rhcy5hZnRlci5yZW1vdmUoZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0XG59KTtcbiIsIkludmVudGFyaW8uYWxsb3coe1xuXHRpbnNlcnQ6IGZ1bmN0aW9uICh1c2VySWQsIGRvYykge1xuXHRcdHJldHVybiBmYWxzZTtcblx0fSxcblxuXHR1cGRhdGU6IGZ1bmN0aW9uICh1c2VySWQsIGRvYywgZmllbGRzLCBtb2RpZmllcikge1xuXHRcdHJldHVybiBmYWxzZTtcblx0fSxcblxuXHRyZW1vdmU6IGZ1bmN0aW9uICh1c2VySWQsIGRvYykge1xuXHRcdHJldHVybiBmYWxzZTtcblx0fVxufSk7XG5cbkludmVudGFyaW8uYmVmb3JlLmluc2VydChmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRkb2MuY3JlYXRlZEF0ID0gbmV3IERhdGUoKTtcblx0ZG9jLmNyZWF0ZWRCeSA9IHVzZXJJZDtcblx0ZG9jLm1vZGlmaWVkQXQgPSBkb2MuY3JlYXRlZEF0O1xuXHRkb2MubW9kaWZpZWRCeSA9IGRvYy5jcmVhdGVkQnk7XG5cblx0XG5cdGlmKCFkb2MuY3JlYXRlZEJ5KSBkb2MuY3JlYXRlZEJ5ID0gdXNlcklkO1xufSk7XG5cbkludmVudGFyaW8uYmVmb3JlLnVwZGF0ZShmdW5jdGlvbih1c2VySWQsIGRvYywgZmllbGROYW1lcywgbW9kaWZpZXIsIG9wdGlvbnMpIHtcblx0bW9kaWZpZXIuJHNldCA9IG1vZGlmaWVyLiRzZXQgfHwge307XG5cdG1vZGlmaWVyLiRzZXQubW9kaWZpZWRBdCA9IG5ldyBEYXRlKCk7XG5cdG1vZGlmaWVyLiRzZXQubW9kaWZpZWRCeSA9IHVzZXJJZDtcblxuXHRcbn0pO1xuXG5JbnZlbnRhcmlvLmJlZm9yZS51cHNlcnQoZnVuY3Rpb24odXNlcklkLCBzZWxlY3RvciwgbW9kaWZpZXIsIG9wdGlvbnMpIHtcblx0bW9kaWZpZXIuJHNldCA9IG1vZGlmaWVyLiRzZXQgfHwge307XG5cdG1vZGlmaWVyLiRzZXQubW9kaWZpZWRBdCA9IG5ldyBEYXRlKCk7XG5cdG1vZGlmaWVyLiRzZXQubW9kaWZpZWRCeSA9IHVzZXJJZDtcblxuXHQvKkJFRk9SRV9VUFNFUlRfQ09ERSovXG59KTtcblxuSW52ZW50YXJpby5iZWZvcmUucmVtb3ZlKGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdFxufSk7XG5cbkludmVudGFyaW8uYWZ0ZXIuaW5zZXJ0KGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdFxufSk7XG5cbkludmVudGFyaW8uYWZ0ZXIudXBkYXRlKGZ1bmN0aW9uKHVzZXJJZCwgZG9jLCBmaWVsZE5hbWVzLCBtb2RpZmllciwgb3B0aW9ucykge1xuXHRcbn0pO1xuXG5JbnZlbnRhcmlvLmFmdGVyLnJlbW92ZShmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRcbn0pO1xuIiwiTWF0ZXJpYWxlcy5hbGxvdyh7XG5cdGluc2VydDogZnVuY3Rpb24gKHVzZXJJZCwgZG9jKSB7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9LFxuXG5cdHVwZGF0ZTogZnVuY3Rpb24gKHVzZXJJZCwgZG9jLCBmaWVsZHMsIG1vZGlmaWVyKSB7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9LFxuXG5cdHJlbW92ZTogZnVuY3Rpb24gKHVzZXJJZCwgZG9jKSB7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9XG59KTtcblxuTWF0ZXJpYWxlcy5iZWZvcmUuaW5zZXJ0KGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdGRvYy5jcmVhdGVkQXQgPSBuZXcgRGF0ZSgpO1xuXHRkb2MuY3JlYXRlZEJ5ID0gdXNlcklkO1xuXHRkb2MubW9kaWZpZWRBdCA9IGRvYy5jcmVhdGVkQXQ7XG5cdGRvYy5tb2RpZmllZEJ5ID0gZG9jLmNyZWF0ZWRCeTtcblxuXHRcblx0aWYoIWRvYy5jcmVhdGVkQnkpIGRvYy5jcmVhdGVkQnkgPSB1c2VySWQ7XG59KTtcblxuTWF0ZXJpYWxlcy5iZWZvcmUudXBkYXRlKGZ1bmN0aW9uKHVzZXJJZCwgZG9jLCBmaWVsZE5hbWVzLCBtb2RpZmllciwgb3B0aW9ucykge1xuXHRtb2RpZmllci4kc2V0ID0gbW9kaWZpZXIuJHNldCB8fCB7fTtcblx0bW9kaWZpZXIuJHNldC5tb2RpZmllZEF0ID0gbmV3IERhdGUoKTtcblx0bW9kaWZpZXIuJHNldC5tb2RpZmllZEJ5ID0gdXNlcklkO1xuXG5cdFxufSk7XG5cbk1hdGVyaWFsZXMuYmVmb3JlLnVwc2VydChmdW5jdGlvbih1c2VySWQsIHNlbGVjdG9yLCBtb2RpZmllciwgb3B0aW9ucykge1xuXHRtb2RpZmllci4kc2V0ID0gbW9kaWZpZXIuJHNldCB8fCB7fTtcblx0bW9kaWZpZXIuJHNldC5tb2RpZmllZEF0ID0gbmV3IERhdGUoKTtcblx0bW9kaWZpZXIuJHNldC5tb2RpZmllZEJ5ID0gdXNlcklkO1xuXG5cdC8qQkVGT1JFX1VQU0VSVF9DT0RFKi9cbn0pO1xuXG5NYXRlcmlhbGVzLmJlZm9yZS5yZW1vdmUoZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0XG59KTtcblxuTWF0ZXJpYWxlcy5hZnRlci5pbnNlcnQoZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0XG59KTtcblxuTWF0ZXJpYWxlcy5hZnRlci51cGRhdGUoZnVuY3Rpb24odXNlcklkLCBkb2MsIGZpZWxkTmFtZXMsIG1vZGlmaWVyLCBvcHRpb25zKSB7XG5cdFxufSk7XG5cbk1hdGVyaWFsZXMuYWZ0ZXIucmVtb3ZlKGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdFxufSk7XG4iLCJPcmRlbmVzLmFsbG93KHtcblx0aW5zZXJ0OiBmdW5jdGlvbiAodXNlcklkLCBkb2MpIHtcblx0XHRyZXR1cm4gZmFsc2U7XG5cdH0sXG5cblx0dXBkYXRlOiBmdW5jdGlvbiAodXNlcklkLCBkb2MsIGZpZWxkcywgbW9kaWZpZXIpIHtcblx0XHRyZXR1cm4gZmFsc2U7XG5cdH0sXG5cblx0cmVtb3ZlOiBmdW5jdGlvbiAodXNlcklkLCBkb2MpIHtcblx0XHRyZXR1cm4gZmFsc2U7XG5cdH1cbn0pO1xuXG5PcmRlbmVzLmJlZm9yZS5pbnNlcnQoZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0ZG9jLmNyZWF0ZWRBdCA9IG5ldyBEYXRlKCk7XG5cdGRvYy5jcmVhdGVkQnkgPSB1c2VySWQ7XG5cdGRvYy5tb2RpZmllZEF0ID0gZG9jLmNyZWF0ZWRBdDtcblx0ZG9jLm1vZGlmaWVkQnkgPSBkb2MuY3JlYXRlZEJ5O1xuXG5cdFxuXHRpZighZG9jLmNyZWF0ZWRCeSkgZG9jLmNyZWF0ZWRCeSA9IHVzZXJJZDtcbn0pO1xuXG5PcmRlbmVzLmJlZm9yZS51cGRhdGUoZnVuY3Rpb24odXNlcklkLCBkb2MsIGZpZWxkTmFtZXMsIG1vZGlmaWVyLCBvcHRpb25zKSB7XG5cdG1vZGlmaWVyLiRzZXQgPSBtb2RpZmllci4kc2V0IHx8IHt9O1xuXHRtb2RpZmllci4kc2V0Lm1vZGlmaWVkQXQgPSBuZXcgRGF0ZSgpO1xuXHRtb2RpZmllci4kc2V0Lm1vZGlmaWVkQnkgPSB1c2VySWQ7XG5cblx0XG59KTtcblxuT3JkZW5lcy5iZWZvcmUudXBzZXJ0KGZ1bmN0aW9uKHVzZXJJZCwgc2VsZWN0b3IsIG1vZGlmaWVyLCBvcHRpb25zKSB7XG5cdG1vZGlmaWVyLiRzZXQgPSBtb2RpZmllci4kc2V0IHx8IHt9O1xuXHRtb2RpZmllci4kc2V0Lm1vZGlmaWVkQXQgPSBuZXcgRGF0ZSgpO1xuXHRtb2RpZmllci4kc2V0Lm1vZGlmaWVkQnkgPSB1c2VySWQ7XG5cblx0LypCRUZPUkVfVVBTRVJUX0NPREUqL1xufSk7XG5cbk9yZGVuZXMuYmVmb3JlLnJlbW92ZShmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRcbn0pO1xuXG5PcmRlbmVzLmFmdGVyLmluc2VydChmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRcbn0pO1xuXG5PcmRlbmVzLmFmdGVyLnVwZGF0ZShmdW5jdGlvbih1c2VySWQsIGRvYywgZmllbGROYW1lcywgbW9kaWZpZXIsIG9wdGlvbnMpIHtcblx0XG59KTtcblxuT3JkZW5lcy5hZnRlci5yZW1vdmUoZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0XG59KTtcbiIsIk9yZGVuZXNJdGVtcy5hbGxvdyh7XG5cdGluc2VydDogZnVuY3Rpb24gKHVzZXJJZCwgZG9jKSB7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9LFxuXG5cdHVwZGF0ZTogZnVuY3Rpb24gKHVzZXJJZCwgZG9jLCBmaWVsZHMsIG1vZGlmaWVyKSB7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9LFxuXG5cdHJlbW92ZTogZnVuY3Rpb24gKHVzZXJJZCwgZG9jKSB7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9XG59KTtcblxuT3JkZW5lc0l0ZW1zLmJlZm9yZS5pbnNlcnQoZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0ZG9jLmNyZWF0ZWRBdCA9IG5ldyBEYXRlKCk7XG5cdGRvYy5jcmVhdGVkQnkgPSB1c2VySWQ7XG5cdGRvYy5tb2RpZmllZEF0ID0gZG9jLmNyZWF0ZWRBdDtcblx0ZG9jLm1vZGlmaWVkQnkgPSBkb2MuY3JlYXRlZEJ5O1xuXG5cdFxuXHRpZighZG9jLmNyZWF0ZWRCeSkgZG9jLmNyZWF0ZWRCeSA9IHVzZXJJZDtcbn0pO1xuXG5PcmRlbmVzSXRlbXMuYmVmb3JlLnVwZGF0ZShmdW5jdGlvbih1c2VySWQsIGRvYywgZmllbGROYW1lcywgbW9kaWZpZXIsIG9wdGlvbnMpIHtcblx0bW9kaWZpZXIuJHNldCA9IG1vZGlmaWVyLiRzZXQgfHwge307XG5cdG1vZGlmaWVyLiRzZXQubW9kaWZpZWRBdCA9IG5ldyBEYXRlKCk7XG5cdG1vZGlmaWVyLiRzZXQubW9kaWZpZWRCeSA9IHVzZXJJZDtcblxuXHRcbn0pO1xuXG5PcmRlbmVzSXRlbXMuYmVmb3JlLnVwc2VydChmdW5jdGlvbih1c2VySWQsIHNlbGVjdG9yLCBtb2RpZmllciwgb3B0aW9ucykge1xuXHRtb2RpZmllci4kc2V0ID0gbW9kaWZpZXIuJHNldCB8fCB7fTtcblx0bW9kaWZpZXIuJHNldC5tb2RpZmllZEF0ID0gbmV3IERhdGUoKTtcblx0bW9kaWZpZXIuJHNldC5tb2RpZmllZEJ5ID0gdXNlcklkO1xuXG5cdC8qQkVGT1JFX1VQU0VSVF9DT0RFKi9cbn0pO1xuXG5PcmRlbmVzSXRlbXMuYmVmb3JlLnJlbW92ZShmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRcbn0pO1xuXG5PcmRlbmVzSXRlbXMuYWZ0ZXIuaW5zZXJ0KGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdFxufSk7XG5cbk9yZGVuZXNJdGVtcy5hZnRlci51cGRhdGUoZnVuY3Rpb24odXNlcklkLCBkb2MsIGZpZWxkTmFtZXMsIG1vZGlmaWVyLCBvcHRpb25zKSB7XG5cdFxufSk7XG5cbk9yZGVuZXNJdGVtcy5hZnRlci5yZW1vdmUoZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0XG59KTtcbiIsIlByb3ZlZWRvcmVzLmFsbG93KHtcblx0aW5zZXJ0OiBmdW5jdGlvbiAodXNlcklkLCBkb2MpIHtcblx0XHRyZXR1cm4gZmFsc2U7XG5cdH0sXG5cblx0dXBkYXRlOiBmdW5jdGlvbiAodXNlcklkLCBkb2MsIGZpZWxkcywgbW9kaWZpZXIpIHtcblx0XHRyZXR1cm4gZmFsc2U7XG5cdH0sXG5cblx0cmVtb3ZlOiBmdW5jdGlvbiAodXNlcklkLCBkb2MpIHtcblx0XHRyZXR1cm4gZmFsc2U7XG5cdH1cbn0pO1xuXG5Qcm92ZWVkb3Jlcy5iZWZvcmUuaW5zZXJ0KGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdGRvYy5jcmVhdGVkQXQgPSBuZXcgRGF0ZSgpO1xuXHRkb2MuY3JlYXRlZEJ5ID0gdXNlcklkO1xuXHRkb2MubW9kaWZpZWRBdCA9IGRvYy5jcmVhdGVkQXQ7XG5cdGRvYy5tb2RpZmllZEJ5ID0gZG9jLmNyZWF0ZWRCeTtcblxuXHRcblx0aWYoIWRvYy5jcmVhdGVkQnkpIGRvYy5jcmVhdGVkQnkgPSB1c2VySWQ7XG59KTtcblxuUHJvdmVlZG9yZXMuYmVmb3JlLnVwZGF0ZShmdW5jdGlvbih1c2VySWQsIGRvYywgZmllbGROYW1lcywgbW9kaWZpZXIsIG9wdGlvbnMpIHtcblx0bW9kaWZpZXIuJHNldCA9IG1vZGlmaWVyLiRzZXQgfHwge307XG5cdG1vZGlmaWVyLiRzZXQubW9kaWZpZWRBdCA9IG5ldyBEYXRlKCk7XG5cdG1vZGlmaWVyLiRzZXQubW9kaWZpZWRCeSA9IHVzZXJJZDtcblxuXHRcbn0pO1xuXG5Qcm92ZWVkb3Jlcy5iZWZvcmUudXBzZXJ0KGZ1bmN0aW9uKHVzZXJJZCwgc2VsZWN0b3IsIG1vZGlmaWVyLCBvcHRpb25zKSB7XG5cdG1vZGlmaWVyLiRzZXQgPSBtb2RpZmllci4kc2V0IHx8IHt9O1xuXHRtb2RpZmllci4kc2V0Lm1vZGlmaWVkQXQgPSBuZXcgRGF0ZSgpO1xuXHRtb2RpZmllci4kc2V0Lm1vZGlmaWVkQnkgPSB1c2VySWQ7XG5cblx0LypCRUZPUkVfVVBTRVJUX0NPREUqL1xufSk7XG5cblByb3ZlZWRvcmVzLmJlZm9yZS5yZW1vdmUoZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0XG59KTtcblxuUHJvdmVlZG9yZXMuYWZ0ZXIuaW5zZXJ0KGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdFxufSk7XG5cblByb3ZlZWRvcmVzLmFmdGVyLnVwZGF0ZShmdW5jdGlvbih1c2VySWQsIGRvYywgZmllbGROYW1lcywgbW9kaWZpZXIsIG9wdGlvbnMpIHtcblx0XG59KTtcblxuUHJvdmVlZG9yZXMuYWZ0ZXIucmVtb3ZlKGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdFxufSk7XG4iLCJQcm95ZWN0b3MuYWxsb3coe1xuXHRpbnNlcnQ6IGZ1bmN0aW9uICh1c2VySWQsIGRvYykge1xuXHRcdHJldHVybiBmYWxzZTtcblx0fSxcblxuXHR1cGRhdGU6IGZ1bmN0aW9uICh1c2VySWQsIGRvYywgZmllbGRzLCBtb2RpZmllcikge1xuXHRcdHJldHVybiBmYWxzZTtcblx0fSxcblxuXHRyZW1vdmU6IGZ1bmN0aW9uICh1c2VySWQsIGRvYykge1xuXHRcdHJldHVybiBmYWxzZTtcblx0fVxufSk7XG5cblByb3llY3Rvcy5iZWZvcmUuaW5zZXJ0KGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdGRvYy5jcmVhdGVkQXQgPSBuZXcgRGF0ZSgpO1xuXHRkb2MuY3JlYXRlZEJ5ID0gdXNlcklkO1xuXHRkb2MubW9kaWZpZWRBdCA9IGRvYy5jcmVhdGVkQXQ7XG5cdGRvYy5tb2RpZmllZEJ5ID0gZG9jLmNyZWF0ZWRCeTtcblxuXHRcblx0aWYoIWRvYy5jcmVhdGVkQnkpIGRvYy5jcmVhdGVkQnkgPSB1c2VySWQ7XG59KTtcblxuUHJveWVjdG9zLmJlZm9yZS51cGRhdGUoZnVuY3Rpb24odXNlcklkLCBkb2MsIGZpZWxkTmFtZXMsIG1vZGlmaWVyLCBvcHRpb25zKSB7XG5cdG1vZGlmaWVyLiRzZXQgPSBtb2RpZmllci4kc2V0IHx8IHt9O1xuXHRtb2RpZmllci4kc2V0Lm1vZGlmaWVkQXQgPSBuZXcgRGF0ZSgpO1xuXHRtb2RpZmllci4kc2V0Lm1vZGlmaWVkQnkgPSB1c2VySWQ7XG5cblx0XG59KTtcblxuUHJveWVjdG9zLmJlZm9yZS51cHNlcnQoZnVuY3Rpb24odXNlcklkLCBzZWxlY3RvciwgbW9kaWZpZXIsIG9wdGlvbnMpIHtcblx0bW9kaWZpZXIuJHNldCA9IG1vZGlmaWVyLiRzZXQgfHwge307XG5cdG1vZGlmaWVyLiRzZXQubW9kaWZpZWRBdCA9IG5ldyBEYXRlKCk7XG5cdG1vZGlmaWVyLiRzZXQubW9kaWZpZWRCeSA9IHVzZXJJZDtcblxuXHQvKkJFRk9SRV9VUFNFUlRfQ09ERSovXG59KTtcblxuUHJveWVjdG9zLmJlZm9yZS5yZW1vdmUoZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0XG59KTtcblxuUHJveWVjdG9zLmFmdGVyLmluc2VydChmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRcbn0pO1xuXG5Qcm95ZWN0b3MuYWZ0ZXIudXBkYXRlKGZ1bmN0aW9uKHVzZXJJZCwgZG9jLCBmaWVsZE5hbWVzLCBtb2RpZmllciwgb3B0aW9ucykge1xuXHRcbn0pO1xuXG5Qcm95ZWN0b3MuYWZ0ZXIucmVtb3ZlKGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdFxufSk7XG4iLCJSZXF1aXNpY2lvbmVzLmFsbG93KHtcblx0aW5zZXJ0OiBmdW5jdGlvbiAodXNlcklkLCBkb2MpIHtcblx0XHRyZXR1cm4gZmFsc2U7XG5cdH0sXG5cblx0dXBkYXRlOiBmdW5jdGlvbiAodXNlcklkLCBkb2MsIGZpZWxkcywgbW9kaWZpZXIpIHtcblx0XHRyZXR1cm4gZmFsc2U7XG5cdH0sXG5cblx0cmVtb3ZlOiBmdW5jdGlvbiAodXNlcklkLCBkb2MpIHtcblx0XHRyZXR1cm4gZmFsc2U7XG5cdH1cbn0pO1xuXG5SZXF1aXNpY2lvbmVzLmJlZm9yZS5pbnNlcnQoZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0ZG9jLmNyZWF0ZWRBdCA9IG5ldyBEYXRlKCk7XG5cdGRvYy5jcmVhdGVkQnkgPSB1c2VySWQ7XG5cdGRvYy5tb2RpZmllZEF0ID0gZG9jLmNyZWF0ZWRBdDtcblx0ZG9jLm1vZGlmaWVkQnkgPSBkb2MuY3JlYXRlZEJ5O1xuXG5cdFxuXHRpZighZG9jLmNyZWF0ZWRCeSkgZG9jLmNyZWF0ZWRCeSA9IHVzZXJJZDtcbn0pO1xuXG5SZXF1aXNpY2lvbmVzLmJlZm9yZS51cGRhdGUoZnVuY3Rpb24odXNlcklkLCBkb2MsIGZpZWxkTmFtZXMsIG1vZGlmaWVyLCBvcHRpb25zKSB7XG5cdG1vZGlmaWVyLiRzZXQgPSBtb2RpZmllci4kc2V0IHx8IHt9O1xuXHRtb2RpZmllci4kc2V0Lm1vZGlmaWVkQXQgPSBuZXcgRGF0ZSgpO1xuXHRtb2RpZmllci4kc2V0Lm1vZGlmaWVkQnkgPSB1c2VySWQ7XG5cblx0XG59KTtcblxuUmVxdWlzaWNpb25lcy5iZWZvcmUudXBzZXJ0KGZ1bmN0aW9uKHVzZXJJZCwgc2VsZWN0b3IsIG1vZGlmaWVyLCBvcHRpb25zKSB7XG5cdG1vZGlmaWVyLiRzZXQgPSBtb2RpZmllci4kc2V0IHx8IHt9O1xuXHRtb2RpZmllci4kc2V0Lm1vZGlmaWVkQXQgPSBuZXcgRGF0ZSgpO1xuXHRtb2RpZmllci4kc2V0Lm1vZGlmaWVkQnkgPSB1c2VySWQ7XG5cblx0LypCRUZPUkVfVVBTRVJUX0NPREUqL1xufSk7XG5cblJlcXVpc2ljaW9uZXMuYmVmb3JlLnJlbW92ZShmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRcbn0pO1xuXG5SZXF1aXNpY2lvbmVzLmFmdGVyLmluc2VydChmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRcbn0pO1xuXG5SZXF1aXNpY2lvbmVzLmFmdGVyLnVwZGF0ZShmdW5jdGlvbih1c2VySWQsIGRvYywgZmllbGROYW1lcywgbW9kaWZpZXIsIG9wdGlvbnMpIHtcblx0XG59KTtcblxuUmVxdWlzaWNpb25lcy5hZnRlci5yZW1vdmUoZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0XG59KTtcbiIsIlJlcXVpc2ljaW9uZXNJdGVtcy5hbGxvdyh7XG5cdGluc2VydDogZnVuY3Rpb24gKHVzZXJJZCwgZG9jKSB7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9LFxuXG5cdHVwZGF0ZTogZnVuY3Rpb24gKHVzZXJJZCwgZG9jLCBmaWVsZHMsIG1vZGlmaWVyKSB7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9LFxuXG5cdHJlbW92ZTogZnVuY3Rpb24gKHVzZXJJZCwgZG9jKSB7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9XG59KTtcblxuUmVxdWlzaWNpb25lc0l0ZW1zLmJlZm9yZS5pbnNlcnQoZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0ZG9jLmNyZWF0ZWRBdCA9IG5ldyBEYXRlKCk7XG5cdGRvYy5jcmVhdGVkQnkgPSB1c2VySWQ7XG5cdGRvYy5tb2RpZmllZEF0ID0gZG9jLmNyZWF0ZWRBdDtcblx0ZG9jLm1vZGlmaWVkQnkgPSBkb2MuY3JlYXRlZEJ5O1xuXG5cdFxuXHRpZighZG9jLmNyZWF0ZWRCeSkgZG9jLmNyZWF0ZWRCeSA9IHVzZXJJZDtcbn0pO1xuXG5SZXF1aXNpY2lvbmVzSXRlbXMuYmVmb3JlLnVwZGF0ZShmdW5jdGlvbih1c2VySWQsIGRvYywgZmllbGROYW1lcywgbW9kaWZpZXIsIG9wdGlvbnMpIHtcblx0bW9kaWZpZXIuJHNldCA9IG1vZGlmaWVyLiRzZXQgfHwge307XG5cdG1vZGlmaWVyLiRzZXQubW9kaWZpZWRBdCA9IG5ldyBEYXRlKCk7XG5cdG1vZGlmaWVyLiRzZXQubW9kaWZpZWRCeSA9IHVzZXJJZDtcblxuXHRcbn0pO1xuXG5SZXF1aXNpY2lvbmVzSXRlbXMuYmVmb3JlLnVwc2VydChmdW5jdGlvbih1c2VySWQsIHNlbGVjdG9yLCBtb2RpZmllciwgb3B0aW9ucykge1xuXHRtb2RpZmllci4kc2V0ID0gbW9kaWZpZXIuJHNldCB8fCB7fTtcblx0bW9kaWZpZXIuJHNldC5tb2RpZmllZEF0ID0gbmV3IERhdGUoKTtcblx0bW9kaWZpZXIuJHNldC5tb2RpZmllZEJ5ID0gdXNlcklkO1xuXG5cdC8qQkVGT1JFX1VQU0VSVF9DT0RFKi9cbn0pO1xuXG5SZXF1aXNpY2lvbmVzSXRlbXMuYmVmb3JlLnJlbW92ZShmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRcbn0pO1xuXG5SZXF1aXNpY2lvbmVzSXRlbXMuYWZ0ZXIuaW5zZXJ0KGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdFxufSk7XG5cblJlcXVpc2ljaW9uZXNJdGVtcy5hZnRlci51cGRhdGUoZnVuY3Rpb24odXNlcklkLCBkb2MsIGZpZWxkTmFtZXMsIG1vZGlmaWVyLCBvcHRpb25zKSB7XG5cdFxufSk7XG5cblJlcXVpc2ljaW9uZXNJdGVtcy5hZnRlci5yZW1vdmUoZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0XG59KTtcbiIsIlRyYW5zYWNjaW9uZXMuYWxsb3coe1xuXHRpbnNlcnQ6IGZ1bmN0aW9uICh1c2VySWQsIGRvYykge1xuXHRcdHJldHVybiBmYWxzZTtcblx0fSxcblxuXHR1cGRhdGU6IGZ1bmN0aW9uICh1c2VySWQsIGRvYywgZmllbGRzLCBtb2RpZmllcikge1xuXHRcdHJldHVybiBmYWxzZTtcblx0fSxcblxuXHRyZW1vdmU6IGZ1bmN0aW9uICh1c2VySWQsIGRvYykge1xuXHRcdHJldHVybiBmYWxzZTtcblx0fVxufSk7XG5cblRyYW5zYWNjaW9uZXMuYmVmb3JlLmluc2VydChmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRkb2MuY3JlYXRlZEF0ID0gbmV3IERhdGUoKTtcblx0ZG9jLmNyZWF0ZWRCeSA9IHVzZXJJZDtcblx0ZG9jLm1vZGlmaWVkQXQgPSBkb2MuY3JlYXRlZEF0O1xuXHRkb2MubW9kaWZpZWRCeSA9IGRvYy5jcmVhdGVkQnk7XG5cblx0XG5cdGlmKCFkb2MuY3JlYXRlZEJ5KSBkb2MuY3JlYXRlZEJ5ID0gdXNlcklkO1xufSk7XG5cblRyYW5zYWNjaW9uZXMuYmVmb3JlLnVwZGF0ZShmdW5jdGlvbih1c2VySWQsIGRvYywgZmllbGROYW1lcywgbW9kaWZpZXIsIG9wdGlvbnMpIHtcblx0bW9kaWZpZXIuJHNldCA9IG1vZGlmaWVyLiRzZXQgfHwge307XG5cdG1vZGlmaWVyLiRzZXQubW9kaWZpZWRBdCA9IG5ldyBEYXRlKCk7XG5cdG1vZGlmaWVyLiRzZXQubW9kaWZpZWRCeSA9IHVzZXJJZDtcblxuXHRcbn0pO1xuXG5UcmFuc2FjY2lvbmVzLmJlZm9yZS51cHNlcnQoZnVuY3Rpb24odXNlcklkLCBzZWxlY3RvciwgbW9kaWZpZXIsIG9wdGlvbnMpIHtcblx0bW9kaWZpZXIuJHNldCA9IG1vZGlmaWVyLiRzZXQgfHwge307XG5cdG1vZGlmaWVyLiRzZXQubW9kaWZpZWRBdCA9IG5ldyBEYXRlKCk7XG5cdG1vZGlmaWVyLiRzZXQubW9kaWZpZWRCeSA9IHVzZXJJZDtcblxuXHQvKkJFRk9SRV9VUFNFUlRfQ09ERSovXG59KTtcblxuVHJhbnNhY2Npb25lcy5iZWZvcmUucmVtb3ZlKGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdFxufSk7XG5cblRyYW5zYWNjaW9uZXMuYWZ0ZXIuaW5zZXJ0KGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdFxufSk7XG5cblRyYW5zYWNjaW9uZXMuYWZ0ZXIudXBkYXRlKGZ1bmN0aW9uKHVzZXJJZCwgZG9jLCBmaWVsZE5hbWVzLCBtb2RpZmllciwgb3B0aW9ucykge1xuXHRcbn0pO1xuXG5UcmFuc2FjY2lvbmVzLmFmdGVyLnJlbW92ZShmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRcbn0pO1xuIiwiUm91dGVyLm1hcChmdW5jdGlvbiAoKSB7XG5cbn0pO1xuIiwiTWV0ZW9yLm1ldGhvZHMoe1xuXHRcImNvbnRyYXRpc3Rhc0luc2VydFwiOiBmdW5jdGlvbihkYXRhKSB7XG5cdFx0aWYoIUNvbnRyYXRpc3Rhcy51c2VyQ2FuSW5zZXJ0KHRoaXMudXNlcklkLCBkYXRhKSkge1xuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDMsIFwiRm9yYmlkZGVuLlwiKTtcblx0XHR9XG5cblx0XHRyZXR1cm4gQ29udHJhdGlzdGFzLmluc2VydChkYXRhKTtcblx0fSxcblxuXHRcImNvbnRyYXRpc3Rhc1VwZGF0ZVwiOiBmdW5jdGlvbihpZCwgZGF0YSkge1xuXHRcdHZhciBkb2MgPSBDb250cmF0aXN0YXMuZmluZE9uZSh7IF9pZDogaWQgfSk7XG5cdFx0aWYoIUNvbnRyYXRpc3Rhcy51c2VyQ2FuVXBkYXRlKHRoaXMudXNlcklkLCBkb2MpKSB7XG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMywgXCJGb3JiaWRkZW4uXCIpO1xuXHRcdH1cblxuXHRcdENvbnRyYXRpc3Rhcy51cGRhdGUoeyBfaWQ6IGlkIH0sIHsgJHNldDogZGF0YSB9KTtcblx0fSxcblxuXHRcImNvbnRyYXRpc3Rhc1JlbW92ZVwiOiBmdW5jdGlvbihpZCkge1xuXHRcdHZhciBkb2MgPSBDb250cmF0aXN0YXMuZmluZE9uZSh7IF9pZDogaWQgfSk7XG5cdFx0aWYoIUNvbnRyYXRpc3Rhcy51c2VyQ2FuUmVtb3ZlKHRoaXMudXNlcklkLCBkb2MpKSB7XG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMywgXCJGb3JiaWRkZW4uXCIpO1xuXHRcdH1cblxuXHRcdENvbnRyYXRpc3Rhcy5yZW1vdmUoeyBfaWQ6IGlkIH0pO1xuXHR9XG59KTtcbiIsIk1ldGVvci5tZXRob2RzKHtcblx0XCJpbnZlbnRhcmlvSW5zZXJ0XCI6IGZ1bmN0aW9uKGRhdGEpIHtcblx0XHRpZighSW52ZW50YXJpby51c2VyQ2FuSW5zZXJ0KHRoaXMudXNlcklkLCBkYXRhKSkge1xuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDMsIFwiRm9yYmlkZGVuLlwiKTtcblx0XHR9XG5cblx0XHRyZXR1cm4gSW52ZW50YXJpby5pbnNlcnQoZGF0YSk7XG5cdH0sXG5cblx0XCJpbnZlbnRhcmlvVXBkYXRlXCI6IGZ1bmN0aW9uKGlkLCBkYXRhKSB7XG5cdFx0dmFyIGRvYyA9IEludmVudGFyaW8uZmluZE9uZSh7IF9pZDogaWQgfSk7XG5cdFx0aWYoIUludmVudGFyaW8udXNlckNhblVwZGF0ZSh0aGlzLnVzZXJJZCwgZG9jKSkge1xuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDMsIFwiRm9yYmlkZGVuLlwiKTtcblx0XHR9XG5cblx0XHRJbnZlbnRhcmlvLnVwZGF0ZSh7IF9pZDogaWQgfSwgeyAkc2V0OiBkYXRhIH0pO1xuXHR9LFxuXG5cdFwiaW52ZW50YXJpb1JlbW92ZVwiOiBmdW5jdGlvbihpZCkge1xuXHRcdHZhciBkb2MgPSBJbnZlbnRhcmlvLmZpbmRPbmUoeyBfaWQ6IGlkIH0pO1xuXHRcdGlmKCFJbnZlbnRhcmlvLnVzZXJDYW5SZW1vdmUodGhpcy51c2VySWQsIGRvYykpIHtcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCBcIkZvcmJpZGRlbi5cIik7XG5cdFx0fVxuXG5cdFx0SW52ZW50YXJpby5yZW1vdmUoeyBfaWQ6IGlkIH0pO1xuXHR9XG59KTtcbiIsIk1ldGVvci5tZXRob2RzKHtcblx0XCJtYXRlcmlhbGVzSW5zZXJ0XCI6IGZ1bmN0aW9uKGRhdGEpIHtcblx0XHRpZighTWF0ZXJpYWxlcy51c2VyQ2FuSW5zZXJ0KHRoaXMudXNlcklkLCBkYXRhKSkge1xuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDMsIFwiRm9yYmlkZGVuLlwiKTtcblx0XHR9XG5cblx0XHRyZXR1cm4gTWF0ZXJpYWxlcy5pbnNlcnQoZGF0YSk7XG5cdH0sXG5cblx0XCJtYXRlcmlhbGVzVXBkYXRlXCI6IGZ1bmN0aW9uKGlkLCBkYXRhKSB7XG5cdFx0dmFyIGRvYyA9IE1hdGVyaWFsZXMuZmluZE9uZSh7IF9pZDogaWQgfSk7XG5cdFx0aWYoIU1hdGVyaWFsZXMudXNlckNhblVwZGF0ZSh0aGlzLnVzZXJJZCwgZG9jKSkge1xuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDMsIFwiRm9yYmlkZGVuLlwiKTtcblx0XHR9XG5cblx0XHRNYXRlcmlhbGVzLnVwZGF0ZSh7IF9pZDogaWQgfSwgeyAkc2V0OiBkYXRhIH0pO1xuXHR9LFxuXG5cdFwibWF0ZXJpYWxlc1JlbW92ZVwiOiBmdW5jdGlvbihpZCkge1xuXHRcdHZhciBkb2MgPSBNYXRlcmlhbGVzLmZpbmRPbmUoeyBfaWQ6IGlkIH0pO1xuXHRcdGlmKCFNYXRlcmlhbGVzLnVzZXJDYW5SZW1vdmUodGhpcy51c2VySWQsIGRvYykpIHtcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCBcIkZvcmJpZGRlbi5cIik7XG5cdFx0fVxuXG5cdFx0TWF0ZXJpYWxlcy5yZW1vdmUoeyBfaWQ6IGlkIH0pO1xuXHR9XG59KTtcbiIsIk1ldGVvci5tZXRob2RzKHtcblx0XCJvcmRlbmVzSW5zZXJ0XCI6IGZ1bmN0aW9uKGRhdGEpIHtcblx0XHRpZighT3JkZW5lcy51c2VyQ2FuSW5zZXJ0KHRoaXMudXNlcklkLCBkYXRhKSkge1xuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDMsIFwiRm9yYmlkZGVuLlwiKTtcblx0XHR9XG5cblx0XHRyZXR1cm4gT3JkZW5lcy5pbnNlcnQoZGF0YSk7XG5cdH0sXG5cblx0XCJvcmRlbmVzVXBkYXRlXCI6IGZ1bmN0aW9uKGlkLCBkYXRhKSB7XG5cdFx0dmFyIGRvYyA9IE9yZGVuZXMuZmluZE9uZSh7IF9pZDogaWQgfSk7XG5cdFx0aWYoIU9yZGVuZXMudXNlckNhblVwZGF0ZSh0aGlzLnVzZXJJZCwgZG9jKSkge1xuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDMsIFwiRm9yYmlkZGVuLlwiKTtcblx0XHR9XG5cblx0XHRPcmRlbmVzLnVwZGF0ZSh7IF9pZDogaWQgfSwgeyAkc2V0OiBkYXRhIH0pO1xuXHR9LFxuXG5cdFwib3JkZW5lc1JlbW92ZVwiOiBmdW5jdGlvbihpZCkge1xuXHRcdHZhciBkb2MgPSBPcmRlbmVzLmZpbmRPbmUoeyBfaWQ6IGlkIH0pO1xuXHRcdGlmKCFPcmRlbmVzLnVzZXJDYW5SZW1vdmUodGhpcy51c2VySWQsIGRvYykpIHtcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCBcIkZvcmJpZGRlbi5cIik7XG5cdFx0fVxuXG5cdFx0T3JkZW5lcy5yZW1vdmUoeyBfaWQ6IGlkIH0pO1xuXHR9XG59KTtcbiIsIk1ldGVvci5tZXRob2RzKHtcblx0XCJvcmRlbmVzSXRlbXNJbnNlcnRcIjogZnVuY3Rpb24oZGF0YSkge1xuXHRcdGlmKCFPcmRlbmVzSXRlbXMudXNlckNhbkluc2VydCh0aGlzLnVzZXJJZCwgZGF0YSkpIHtcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCBcIkZvcmJpZGRlbi5cIik7XG5cdFx0fVxuXG5cdFx0cmV0dXJuIE9yZGVuZXNJdGVtcy5pbnNlcnQoZGF0YSk7XG5cdH0sXG5cblx0XCJvcmRlbmVzSXRlbXNVcGRhdGVcIjogZnVuY3Rpb24oaWQsIGRhdGEpIHtcblx0XHR2YXIgZG9jID0gT3JkZW5lc0l0ZW1zLmZpbmRPbmUoeyBfaWQ6IGlkIH0pO1xuXHRcdGlmKCFPcmRlbmVzSXRlbXMudXNlckNhblVwZGF0ZSh0aGlzLnVzZXJJZCwgZG9jKSkge1xuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDMsIFwiRm9yYmlkZGVuLlwiKTtcblx0XHR9XG5cblx0XHRPcmRlbmVzSXRlbXMudXBkYXRlKHsgX2lkOiBpZCB9LCB7ICRzZXQ6IGRhdGEgfSk7XG5cdH0sXG5cblx0XCJvcmRlbmVzSXRlbXNSZW1vdmVcIjogZnVuY3Rpb24oaWQpIHtcblx0XHR2YXIgZG9jID0gT3JkZW5lc0l0ZW1zLmZpbmRPbmUoeyBfaWQ6IGlkIH0pO1xuXHRcdGlmKCFPcmRlbmVzSXRlbXMudXNlckNhblJlbW92ZSh0aGlzLnVzZXJJZCwgZG9jKSkge1xuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDMsIFwiRm9yYmlkZGVuLlwiKTtcblx0XHR9XG5cblx0XHRPcmRlbmVzSXRlbXMucmVtb3ZlKHsgX2lkOiBpZCB9KTtcblx0fVxufSk7XG4iLCJNZXRlb3IubWV0aG9kcyh7XG5cdFwicHJvdmVlZG9yZXNJbnNlcnRcIjogZnVuY3Rpb24oZGF0YSkge1xuXHRcdGlmKCFQcm92ZWVkb3Jlcy51c2VyQ2FuSW5zZXJ0KHRoaXMudXNlcklkLCBkYXRhKSkge1xuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDMsIFwiRm9yYmlkZGVuLlwiKTtcblx0XHR9XG5cblx0XHRyZXR1cm4gUHJvdmVlZG9yZXMuaW5zZXJ0KGRhdGEpO1xuXHR9LFxuXG5cdFwicHJvdmVlZG9yZXNVcGRhdGVcIjogZnVuY3Rpb24oaWQsIGRhdGEpIHtcblx0XHR2YXIgZG9jID0gUHJvdmVlZG9yZXMuZmluZE9uZSh7IF9pZDogaWQgfSk7XG5cdFx0aWYoIVByb3ZlZWRvcmVzLnVzZXJDYW5VcGRhdGUodGhpcy51c2VySWQsIGRvYykpIHtcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCBcIkZvcmJpZGRlbi5cIik7XG5cdFx0fVxuXG5cdFx0UHJvdmVlZG9yZXMudXBkYXRlKHsgX2lkOiBpZCB9LCB7ICRzZXQ6IGRhdGEgfSk7XG5cdH0sXG5cblx0XCJwcm92ZWVkb3Jlc1JlbW92ZVwiOiBmdW5jdGlvbihpZCkge1xuXHRcdHZhciBkb2MgPSBQcm92ZWVkb3Jlcy5maW5kT25lKHsgX2lkOiBpZCB9KTtcblx0XHRpZighUHJvdmVlZG9yZXMudXNlckNhblJlbW92ZSh0aGlzLnVzZXJJZCwgZG9jKSkge1xuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDMsIFwiRm9yYmlkZGVuLlwiKTtcblx0XHR9XG5cblx0XHRQcm92ZWVkb3Jlcy5yZW1vdmUoeyBfaWQ6IGlkIH0pO1xuXHR9XG59KTtcbiIsIk1ldGVvci5tZXRob2RzKHtcblx0XCJwcm95ZWN0b3NJbnNlcnRcIjogZnVuY3Rpb24oZGF0YSkge1xuXHRcdGlmKCFQcm95ZWN0b3MudXNlckNhbkluc2VydCh0aGlzLnVzZXJJZCwgZGF0YSkpIHtcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCBcIkZvcmJpZGRlbi5cIik7XG5cdFx0fVxuXG5cdFx0cmV0dXJuIFByb3llY3Rvcy5pbnNlcnQoZGF0YSk7XG5cdH0sXG5cblx0XCJwcm95ZWN0b3NVcGRhdGVcIjogZnVuY3Rpb24oaWQsIGRhdGEpIHtcblx0XHR2YXIgZG9jID0gUHJveWVjdG9zLmZpbmRPbmUoeyBfaWQ6IGlkIH0pO1xuXHRcdGlmKCFQcm95ZWN0b3MudXNlckNhblVwZGF0ZSh0aGlzLnVzZXJJZCwgZG9jKSkge1xuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDMsIFwiRm9yYmlkZGVuLlwiKTtcblx0XHR9XG5cblx0XHRQcm95ZWN0b3MudXBkYXRlKHsgX2lkOiBpZCB9LCB7ICRzZXQ6IGRhdGEgfSk7XG5cdH0sXG5cblx0XCJwcm95ZWN0b3NSZW1vdmVcIjogZnVuY3Rpb24oaWQpIHtcblx0XHR2YXIgZG9jID0gUHJveWVjdG9zLmZpbmRPbmUoeyBfaWQ6IGlkIH0pO1xuXHRcdGlmKCFQcm95ZWN0b3MudXNlckNhblJlbW92ZSh0aGlzLnVzZXJJZCwgZG9jKSkge1xuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDMsIFwiRm9yYmlkZGVuLlwiKTtcblx0XHR9XG5cblx0XHRQcm95ZWN0b3MucmVtb3ZlKHsgX2lkOiBpZCB9KTtcblx0fVxufSk7XG4iLCJNZXRlb3IubWV0aG9kcyh7XG5cdFwicmVxdWlzaWNpb25lc0luc2VydFwiOiBmdW5jdGlvbihkYXRhKSB7XG5cdFx0aWYoIVJlcXVpc2ljaW9uZXMudXNlckNhbkluc2VydCh0aGlzLnVzZXJJZCwgZGF0YSkpIHtcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCBcIkZvcmJpZGRlbi5cIik7XG5cdFx0fVxuXG5cdFx0cmV0dXJuIFJlcXVpc2ljaW9uZXMuaW5zZXJ0KGRhdGEpO1xuXHR9LFxuXG5cdFwicmVxdWlzaWNpb25lc1VwZGF0ZVwiOiBmdW5jdGlvbihpZCwgZGF0YSkge1xuXHRcdHZhciBkb2MgPSBSZXF1aXNpY2lvbmVzLmZpbmRPbmUoeyBfaWQ6IGlkIH0pO1xuXHRcdGlmKCFSZXF1aXNpY2lvbmVzLnVzZXJDYW5VcGRhdGUodGhpcy51c2VySWQsIGRvYykpIHtcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCBcIkZvcmJpZGRlbi5cIik7XG5cdFx0fVxuXG5cdFx0UmVxdWlzaWNpb25lcy51cGRhdGUoeyBfaWQ6IGlkIH0sIHsgJHNldDogZGF0YSB9KTtcblx0fSxcblxuXHRcInJlcXVpc2ljaW9uZXNSZW1vdmVcIjogZnVuY3Rpb24oaWQpIHtcblx0XHR2YXIgZG9jID0gUmVxdWlzaWNpb25lcy5maW5kT25lKHsgX2lkOiBpZCB9KTtcblx0XHRpZighUmVxdWlzaWNpb25lcy51c2VyQ2FuUmVtb3ZlKHRoaXMudXNlcklkLCBkb2MpKSB7XG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMywgXCJGb3JiaWRkZW4uXCIpO1xuXHRcdH1cblxuXHRcdFJlcXVpc2ljaW9uZXMucmVtb3ZlKHsgX2lkOiBpZCB9KTtcblx0fVxufSk7XG4iLCJNZXRlb3IubWV0aG9kcyh7XG5cdFwicmVxdWlzaWNpb25lc0l0ZW1zSW5zZXJ0XCI6IGZ1bmN0aW9uKGRhdGEpIHtcblx0XHRpZighUmVxdWlzaWNpb25lc0l0ZW1zLnVzZXJDYW5JbnNlcnQodGhpcy51c2VySWQsIGRhdGEpKSB7XG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMywgXCJGb3JiaWRkZW4uXCIpO1xuXHRcdH1cblxuXHRcdHJldHVybiBSZXF1aXNpY2lvbmVzSXRlbXMuaW5zZXJ0KGRhdGEpO1xuXHR9LFxuXG5cdFwicmVxdWlzaWNpb25lc0l0ZW1zVXBkYXRlXCI6IGZ1bmN0aW9uKGlkLCBkYXRhKSB7XG5cdFx0dmFyIGRvYyA9IFJlcXVpc2ljaW9uZXNJdGVtcy5maW5kT25lKHsgX2lkOiBpZCB9KTtcblx0XHRpZighUmVxdWlzaWNpb25lc0l0ZW1zLnVzZXJDYW5VcGRhdGUodGhpcy51c2VySWQsIGRvYykpIHtcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCBcIkZvcmJpZGRlbi5cIik7XG5cdFx0fVxuXG5cdFx0UmVxdWlzaWNpb25lc0l0ZW1zLnVwZGF0ZSh7IF9pZDogaWQgfSwgeyAkc2V0OiBkYXRhIH0pO1xuXHR9LFxuXG5cdFwicmVxdWlzaWNpb25lc0l0ZW1zUmVtb3ZlXCI6IGZ1bmN0aW9uKGlkKSB7XG5cdFx0dmFyIGRvYyA9IFJlcXVpc2ljaW9uZXNJdGVtcy5maW5kT25lKHsgX2lkOiBpZCB9KTtcblx0XHRpZighUmVxdWlzaWNpb25lc0l0ZW1zLnVzZXJDYW5SZW1vdmUodGhpcy51c2VySWQsIGRvYykpIHtcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCBcIkZvcmJpZGRlbi5cIik7XG5cdFx0fVxuXG5cdFx0UmVxdWlzaWNpb25lc0l0ZW1zLnJlbW92ZSh7IF9pZDogaWQgfSk7XG5cdH1cbn0pO1xuIiwiTWV0ZW9yLm1ldGhvZHMoe1xuXHRcInRyYW5zYWNjaW9uZXNJbnNlcnRcIjogZnVuY3Rpb24oZGF0YSkge1xuXHRcdGlmKCFUcmFuc2FjY2lvbmVzLnVzZXJDYW5JbnNlcnQodGhpcy51c2VySWQsIGRhdGEpKSB7XG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMywgXCJGb3JiaWRkZW4uXCIpO1xuXHRcdH1cblxuXHRcdHJldHVybiBUcmFuc2FjY2lvbmVzLmluc2VydChkYXRhKTtcblx0fSxcblxuXHRcInRyYW5zYWNjaW9uZXNVcGRhdGVcIjogZnVuY3Rpb24oaWQsIGRhdGEpIHtcblx0XHR2YXIgZG9jID0gVHJhbnNhY2Npb25lcy5maW5kT25lKHsgX2lkOiBpZCB9KTtcblx0XHRpZighVHJhbnNhY2Npb25lcy51c2VyQ2FuVXBkYXRlKHRoaXMudXNlcklkLCBkb2MpKSB7XG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMywgXCJGb3JiaWRkZW4uXCIpO1xuXHRcdH1cblxuXHRcdFRyYW5zYWNjaW9uZXMudXBkYXRlKHsgX2lkOiBpZCB9LCB7ICRzZXQ6IGRhdGEgfSk7XG5cdH0sXG5cblx0XCJ0cmFuc2FjY2lvbmVzUmVtb3ZlXCI6IGZ1bmN0aW9uKGlkKSB7XG5cdFx0dmFyIGRvYyA9IFRyYW5zYWNjaW9uZXMuZmluZE9uZSh7IF9pZDogaWQgfSk7XG5cdFx0aWYoIVRyYW5zYWNjaW9uZXMudXNlckNhblJlbW92ZSh0aGlzLnVzZXJJZCwgZG9jKSkge1xuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDMsIFwiRm9yYmlkZGVuLlwiKTtcblx0XHR9XG5cblx0XHRUcmFuc2FjY2lvbmVzLnJlbW92ZSh7IF9pZDogaWQgfSk7XG5cdH1cbn0pO1xuIiwiTWV0ZW9yLnB1Ymxpc2goXCJjb250cmF0aXN0YV9saXN0XCIsIGZ1bmN0aW9uKCkge1xuXHRyZXR1cm4gQ29udHJhdGlzdGFzLmZpbmQoe30sIHt9KTtcbn0pO1xuXG5NZXRlb3IucHVibGlzaChcImNvbnRyYXRpc3Rhc19udWxsXCIsIGZ1bmN0aW9uKCkge1xuXHRyZXR1cm4gQ29udHJhdGlzdGFzLmZpbmQoe19pZDpudWxsfSwge30pO1xufSk7XG5cbk1ldGVvci5wdWJsaXNoKFwiY29udHJhdGlzdGFcIiwgZnVuY3Rpb24oY29udHJhdGlzdGFJZCkge1xuXHRyZXR1cm4gQ29udHJhdGlzdGFzLmZpbmQoe19pZDpjb250cmF0aXN0YUlkfSwge30pO1xufSk7XG5cbiIsIk1ldGVvci5wdWJsaXNoKFwibWF0ZXJpYWxfbGlzdFwiLCBmdW5jdGlvbigpIHtcblx0cmV0dXJuIE1hdGVyaWFsZXMuZmluZCh7fSwge30pO1xufSk7XG5cbk1ldGVvci5wdWJsaXNoKFwibWF0ZXJpYWxlc19udWxsXCIsIGZ1bmN0aW9uKCkge1xuXHRyZXR1cm4gTWF0ZXJpYWxlcy5maW5kKHtfaWQ6bnVsbH0sIHt9KTtcbn0pO1xuXG5NZXRlb3IucHVibGlzaChcIm1hdGVyaWFsXCIsIGZ1bmN0aW9uKG1hdGVyaWFsSWQpIHtcblx0cmV0dXJuIE1hdGVyaWFsZXMuZmluZCh7X2lkOm1hdGVyaWFsSWR9LCB7fSk7XG59KTtcblxuIiwiTWV0ZW9yLnB1Ymxpc2goXCJwcm92ZWVkb3JfbGlzdFwiLCBmdW5jdGlvbigpIHtcblx0cmV0dXJuIFByb3ZlZWRvcmVzLmZpbmQoe30sIHt9KTtcbn0pO1xuXG5NZXRlb3IucHVibGlzaChcInByb3ZlZWRvcmVzX251bGxcIiwgZnVuY3Rpb24oKSB7XG5cdHJldHVybiBQcm92ZWVkb3Jlcy5maW5kKHtfaWQ6bnVsbH0sIHt9KTtcbn0pO1xuXG5NZXRlb3IucHVibGlzaChcInByb3ZlZWRvclwiLCBmdW5jdGlvbihwcm92ZWVkb3JJZCkge1xuXHRyZXR1cm4gUHJvdmVlZG9yZXMuZmluZCh7X2lkOnByb3ZlZWRvcklkfSwge30pO1xufSk7XG5cbiIsIk1ldGVvci5wdWJsaXNoKFwicHJveWVjdG9fbGlzdFwiLCBmdW5jdGlvbigpIHtcblx0cmV0dXJuIFByb3llY3Rvcy5maW5kKHt9LCB7fSk7XG59KTtcblxuTWV0ZW9yLnB1Ymxpc2goXCJwcm95ZWN0b3NfbnVsbFwiLCBmdW5jdGlvbigpIHtcblx0cmV0dXJuIFByb3llY3Rvcy5maW5kKHtfaWQ6bnVsbH0sIHt9KTtcbn0pO1xuXG5NZXRlb3IucHVibGlzaChcInByb3llY3RvXCIsIGZ1bmN0aW9uKHByb3llY3RvSWQpIHtcblx0cmV0dXJuIFByb3llY3Rvcy5maW5kKHtfaWQ6cHJveWVjdG9JZH0sIHt9KTtcbn0pO1xuXG4iLCJNZXRlb3IucHVibGlzaChcInRyYW5zYWNjaW9uX2xpc3RcIiwgZnVuY3Rpb24oKSB7XG5cdHJldHVybiBUcmFuc2FjY2lvbmVzLmZpbmQoe30sIHt9KTtcbn0pO1xuXG5NZXRlb3IucHVibGlzaChcInRyYW5zYWNjaW9uZXNfbnVsbFwiLCBmdW5jdGlvbigpIHtcblx0cmV0dXJuIFRyYW5zYWNjaW9uZXMuZmluZCh7X2lkOm51bGx9LCB7fSk7XG59KTtcblxuTWV0ZW9yLnB1Ymxpc2goXCJ0cmFuc2FjY2lvblwiLCBmdW5jdGlvbih0cmFuc2FjY2lvbklkKSB7XG5cdHJldHVybiBUcmFuc2FjY2lvbmVzLmZpbmQoe19pZDp0cmFuc2FjY2lvbklkfSwge30pO1xufSk7XG5cbiIsInZhciB2ZXJpZnlFbWFpbCA9IHRydWU7XG5cbkFjY291bnRzLmNvbmZpZyh7IHNlbmRWZXJpZmljYXRpb25FbWFpbDogdmVyaWZ5RW1haWwgfSk7XG5cbk1ldGVvci5zdGFydHVwKGZ1bmN0aW9uKCkge1xuXHQvLyByZWFkIGVudmlyb25tZW50IHZhcmlhYmxlcyBmcm9tIE1ldGVvci5zZXR0aW5nc1xuXHRpZihNZXRlb3Iuc2V0dGluZ3MgJiYgTWV0ZW9yLnNldHRpbmdzLmVudiAmJiBfLmlzT2JqZWN0KE1ldGVvci5zZXR0aW5ncy5lbnYpKSB7XG5cdFx0Zm9yKHZhciB2YXJpYWJsZU5hbWUgaW4gTWV0ZW9yLnNldHRpbmdzLmVudikge1xuXHRcdFx0cHJvY2Vzcy5lbnZbdmFyaWFibGVOYW1lXSA9IE1ldGVvci5zZXR0aW5ncy5lbnZbdmFyaWFibGVOYW1lXTtcblx0XHR9XG5cdH1cblxuXHQvL1xuXHQvLyBTZXR1cCBPQXV0aCBsb2dpbiBzZXJ2aWNlIGNvbmZpZ3VyYXRpb24gKHJlYWQgZnJvbSBNZXRlb3Iuc2V0dGluZ3MpXG5cdC8vXG5cdC8vIFlvdXIgc2V0dGluZ3MgZmlsZSBzaG91bGQgbG9vayBsaWtlIHRoaXM6XG5cdC8vXG5cdC8vIHtcblx0Ly8gICAgIFwib2F1dGhcIjoge1xuXHQvLyAgICAgICAgIFwiZ29vZ2xlXCI6IHtcblx0Ly8gICAgICAgICAgICAgXCJjbGllbnRJZFwiOiBcInlvdXJDbGllbnRJZFwiLFxuXHQvLyAgICAgICAgICAgICBcInNlY3JldFwiOiBcInlvdXJTZWNyZXRcIlxuXHQvLyAgICAgICAgIH0sXG5cdC8vICAgICAgICAgXCJnaXRodWJcIjoge1xuXHQvLyAgICAgICAgICAgICBcImNsaWVudElkXCI6IFwieW91ckNsaWVudElkXCIsXG5cdC8vICAgICAgICAgICAgIFwic2VjcmV0XCI6IFwieW91clNlY3JldFwiXG5cdC8vICAgICAgICAgfVxuXHQvLyAgICAgfVxuXHQvLyB9XG5cdC8vXG5cdGlmKEFjY291bnRzICYmIEFjY291bnRzLmxvZ2luU2VydmljZUNvbmZpZ3VyYXRpb24gJiYgTWV0ZW9yLnNldHRpbmdzICYmIE1ldGVvci5zZXR0aW5ncy5vYXV0aCAmJiBfLmlzT2JqZWN0KE1ldGVvci5zZXR0aW5ncy5vYXV0aCkpIHtcblx0XHQvLyBnb29nbGVcblx0XHRpZihNZXRlb3Iuc2V0dGluZ3Mub2F1dGguZ29vZ2xlICYmIF8uaXNPYmplY3QoTWV0ZW9yLnNldHRpbmdzLm9hdXRoLmdvb2dsZSkpIHtcblx0XHRcdC8vIHJlbW92ZSBvbGQgY29uZmlndXJhdGlvblxuXHRcdFx0QWNjb3VudHMubG9naW5TZXJ2aWNlQ29uZmlndXJhdGlvbi5yZW1vdmUoe1xuXHRcdFx0XHRzZXJ2aWNlOiBcImdvb2dsZVwiXG5cdFx0XHR9KTtcblxuXHRcdFx0dmFyIHNldHRpbmdzT2JqZWN0ID0gTWV0ZW9yLnNldHRpbmdzLm9hdXRoLmdvb2dsZTtcblx0XHRcdHNldHRpbmdzT2JqZWN0LnNlcnZpY2UgPSBcImdvb2dsZVwiO1xuXG5cdFx0XHQvLyBhZGQgbmV3IGNvbmZpZ3VyYXRpb25cblx0XHRcdEFjY291bnRzLmxvZ2luU2VydmljZUNvbmZpZ3VyYXRpb24uaW5zZXJ0KHNldHRpbmdzT2JqZWN0KTtcblx0XHR9XG5cdFx0Ly8gZ2l0aHViXG5cdFx0aWYoTWV0ZW9yLnNldHRpbmdzLm9hdXRoLmdpdGh1YiAmJiBfLmlzT2JqZWN0KE1ldGVvci5zZXR0aW5ncy5vYXV0aC5naXRodWIpKSB7XG5cdFx0XHQvLyByZW1vdmUgb2xkIGNvbmZpZ3VyYXRpb25cblx0XHRcdEFjY291bnRzLmxvZ2luU2VydmljZUNvbmZpZ3VyYXRpb24ucmVtb3ZlKHtcblx0XHRcdFx0c2VydmljZTogXCJnaXRodWJcIlxuXHRcdFx0fSk7XG5cblx0XHRcdHZhciBzZXR0aW5nc09iamVjdCA9IE1ldGVvci5zZXR0aW5ncy5vYXV0aC5naXRodWI7XG5cdFx0XHRzZXR0aW5nc09iamVjdC5zZXJ2aWNlID0gXCJnaXRodWJcIjtcblxuXHRcdFx0Ly8gYWRkIG5ldyBjb25maWd1cmF0aW9uXG5cdFx0XHRBY2NvdW50cy5sb2dpblNlcnZpY2VDb25maWd1cmF0aW9uLmluc2VydChzZXR0aW5nc09iamVjdCk7XG5cdFx0fVxuXHRcdC8vIGxpbmtlZGluXG5cdFx0aWYoTWV0ZW9yLnNldHRpbmdzLm9hdXRoLmxpbmtlZGluICYmIF8uaXNPYmplY3QoTWV0ZW9yLnNldHRpbmdzLm9hdXRoLmxpbmtlZGluKSkge1xuXHRcdFx0Ly8gcmVtb3ZlIG9sZCBjb25maWd1cmF0aW9uXG5cdFx0XHRBY2NvdW50cy5sb2dpblNlcnZpY2VDb25maWd1cmF0aW9uLnJlbW92ZSh7XG5cdFx0XHRcdHNlcnZpY2U6IFwibGlua2VkaW5cIlxuXHRcdFx0fSk7XG5cblx0XHRcdHZhciBzZXR0aW5nc09iamVjdCA9IE1ldGVvci5zZXR0aW5ncy5vYXV0aC5saW5rZWRpbjtcblx0XHRcdHNldHRpbmdzT2JqZWN0LnNlcnZpY2UgPSBcImxpbmtlZGluXCI7XG5cblx0XHRcdC8vIGFkZCBuZXcgY29uZmlndXJhdGlvblxuXHRcdFx0QWNjb3VudHMubG9naW5TZXJ2aWNlQ29uZmlndXJhdGlvbi5pbnNlcnQoc2V0dGluZ3NPYmplY3QpO1xuXHRcdH1cblx0XHQvLyBmYWNlYm9va1xuXHRcdGlmKE1ldGVvci5zZXR0aW5ncy5vYXV0aC5mYWNlYm9vayAmJiBfLmlzT2JqZWN0KE1ldGVvci5zZXR0aW5ncy5vYXV0aC5mYWNlYm9vaykpIHtcblx0XHRcdC8vIHJlbW92ZSBvbGQgY29uZmlndXJhdGlvblxuXHRcdFx0QWNjb3VudHMubG9naW5TZXJ2aWNlQ29uZmlndXJhdGlvbi5yZW1vdmUoe1xuXHRcdFx0XHRzZXJ2aWNlOiBcImZhY2Vib29rXCJcblx0XHRcdH0pO1xuXG5cdFx0XHR2YXIgc2V0dGluZ3NPYmplY3QgPSBNZXRlb3Iuc2V0dGluZ3Mub2F1dGguZmFjZWJvb2s7XG5cdFx0XHRzZXR0aW5nc09iamVjdC5zZXJ2aWNlID0gXCJmYWNlYm9va1wiO1xuXG5cdFx0XHQvLyBhZGQgbmV3IGNvbmZpZ3VyYXRpb25cblx0XHRcdEFjY291bnRzLmxvZ2luU2VydmljZUNvbmZpZ3VyYXRpb24uaW5zZXJ0KHNldHRpbmdzT2JqZWN0KTtcblx0XHR9XG5cdFx0Ly8gdHdpdHRlclxuXHRcdGlmKE1ldGVvci5zZXR0aW5ncy5vYXV0aC50d2l0dGVyICYmIF8uaXNPYmplY3QoTWV0ZW9yLnNldHRpbmdzLm9hdXRoLnR3aXR0ZXIpKSB7XG5cdFx0XHQvLyByZW1vdmUgb2xkIGNvbmZpZ3VyYXRpb25cblx0XHRcdEFjY291bnRzLmxvZ2luU2VydmljZUNvbmZpZ3VyYXRpb24ucmVtb3ZlKHtcblx0XHRcdFx0c2VydmljZTogXCJ0d2l0dGVyXCJcblx0XHRcdH0pO1xuXG5cdFx0XHR2YXIgc2V0dGluZ3NPYmplY3QgPSBNZXRlb3Iuc2V0dGluZ3Mub2F1dGgudHdpdHRlcjtcblx0XHRcdHNldHRpbmdzT2JqZWN0LnNlcnZpY2UgPSBcInR3aXR0ZXJcIjtcblxuXHRcdFx0Ly8gYWRkIG5ldyBjb25maWd1cmF0aW9uXG5cdFx0XHRBY2NvdW50cy5sb2dpblNlcnZpY2VDb25maWd1cmF0aW9uLmluc2VydChzZXR0aW5nc09iamVjdCk7XG5cdFx0fVxuXHRcdC8vIG1ldGVvclxuXHRcdGlmKE1ldGVvci5zZXR0aW5ncy5vYXV0aC5tZXRlb3IgJiYgXy5pc09iamVjdChNZXRlb3Iuc2V0dGluZ3Mub2F1dGgubWV0ZW9yKSkge1xuXHRcdFx0Ly8gcmVtb3ZlIG9sZCBjb25maWd1cmF0aW9uXG5cdFx0XHRBY2NvdW50cy5sb2dpblNlcnZpY2VDb25maWd1cmF0aW9uLnJlbW92ZSh7XG5cdFx0XHRcdHNlcnZpY2U6IFwibWV0ZW9yLWRldmVsb3BlclwiXG5cdFx0XHR9KTtcblxuXHRcdFx0dmFyIHNldHRpbmdzT2JqZWN0ID0gTWV0ZW9yLnNldHRpbmdzLm9hdXRoLm1ldGVvcjtcblx0XHRcdHNldHRpbmdzT2JqZWN0LnNlcnZpY2UgPSBcIm1ldGVvci1kZXZlbG9wZXJcIjtcblxuXHRcdFx0Ly8gYWRkIG5ldyBjb25maWd1cmF0aW9uXG5cdFx0XHRBY2NvdW50cy5sb2dpblNlcnZpY2VDb25maWd1cmF0aW9uLmluc2VydChzZXR0aW5nc09iamVjdCk7XG5cdFx0fVxuXHR9XG5cblx0XG59KTtcblxuTWV0ZW9yLm1ldGhvZHMoe1xuXHRcImNyZWF0ZVVzZXJBY2NvdW50XCI6IGZ1bmN0aW9uKG9wdGlvbnMpIHtcblx0XHRpZighVXNlcnMuaXNBZG1pbihNZXRlb3IudXNlcklkKCkpKSB7XG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMywgXCJBY2Nlc3MgZGVuaWVkLlwiKTtcblx0XHR9XG5cblx0XHR2YXIgdXNlck9wdGlvbnMgPSB7fTtcblx0XHRpZihvcHRpb25zLnVzZXJuYW1lKSB1c2VyT3B0aW9ucy51c2VybmFtZSA9IG9wdGlvbnMudXNlcm5hbWU7XG5cdFx0aWYob3B0aW9ucy5lbWFpbCkgdXNlck9wdGlvbnMuZW1haWwgPSBvcHRpb25zLmVtYWlsO1xuXHRcdGlmKG9wdGlvbnMucGFzc3dvcmQpIHVzZXJPcHRpb25zLnBhc3N3b3JkID0gb3B0aW9ucy5wYXNzd29yZDtcblx0XHRpZihvcHRpb25zLnByb2ZpbGUpIHVzZXJPcHRpb25zLnByb2ZpbGUgPSBvcHRpb25zLnByb2ZpbGU7XG5cdFx0aWYob3B0aW9ucy5wcm9maWxlICYmIG9wdGlvbnMucHJvZmlsZS5lbWFpbCkgdXNlck9wdGlvbnMuZW1haWwgPSBvcHRpb25zLnByb2ZpbGUuZW1haWw7XG5cblx0XHRBY2NvdW50cy5jcmVhdGVVc2VyKHVzZXJPcHRpb25zKTtcblx0fSxcblx0XCJ1cGRhdGVVc2VyQWNjb3VudFwiOiBmdW5jdGlvbih1c2VySWQsIG9wdGlvbnMpIHtcblx0XHQvLyBvbmx5IGFkbWluIG9yIHVzZXJzIG93biBwcm9maWxlXG5cdFx0aWYoIShVc2Vycy5pc0FkbWluKE1ldGVvci51c2VySWQoKSkgfHwgdXNlcklkID09IE1ldGVvci51c2VySWQoKSkpIHtcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCBcIkFjY2VzcyBkZW5pZWQuXCIpO1xuXHRcdH1cblxuXHRcdC8vIG5vbi1hZG1pbiB1c2VyIGNhbiBjaGFuZ2Ugb25seSBwcm9maWxlXG5cdFx0aWYoIVVzZXJzLmlzQWRtaW4oTWV0ZW9yLnVzZXJJZCgpKSkge1xuXHRcdFx0dmFyIGtleXMgPSBPYmplY3Qua2V5cyhvcHRpb25zKTtcblx0XHRcdGlmKGtleXMubGVuZ3RoICE9PSAxIHx8ICFvcHRpb25zLnByb2ZpbGUpIHtcblx0XHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDMsIFwiQWNjZXNzIGRlbmllZC5cIik7XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0dmFyIHVzZXJPcHRpb25zID0ge307XG5cdFx0aWYob3B0aW9ucy51c2VybmFtZSkgdXNlck9wdGlvbnMudXNlcm5hbWUgPSBvcHRpb25zLnVzZXJuYW1lO1xuXHRcdGlmKG9wdGlvbnMuZW1haWwpIHVzZXJPcHRpb25zLmVtYWlsID0gb3B0aW9ucy5lbWFpbDtcblx0XHRpZihvcHRpb25zLnBhc3N3b3JkKSB1c2VyT3B0aW9ucy5wYXNzd29yZCA9IG9wdGlvbnMucGFzc3dvcmQ7XG5cdFx0aWYob3B0aW9ucy5wcm9maWxlKSB1c2VyT3B0aW9ucy5wcm9maWxlID0gb3B0aW9ucy5wcm9maWxlO1xuXG5cdFx0aWYob3B0aW9ucy5wcm9maWxlICYmIG9wdGlvbnMucHJvZmlsZS5lbWFpbCkgdXNlck9wdGlvbnMuZW1haWwgPSBvcHRpb25zLnByb2ZpbGUuZW1haWw7XG5cdFx0aWYob3B0aW9ucy5yb2xlcykgdXNlck9wdGlvbnMucm9sZXMgPSBvcHRpb25zLnJvbGVzO1xuXG5cdFx0aWYodXNlck9wdGlvbnMuZW1haWwpIHtcblx0XHRcdHZhciBlbWFpbCA9IHVzZXJPcHRpb25zLmVtYWlsO1xuXHRcdFx0ZGVsZXRlIHVzZXJPcHRpb25zLmVtYWlsO1xuXHRcdFx0dmFyIHVzZXJEYXRhID0gVXNlcnMuZmluZE9uZSh0aGlzLnVzZXJJZCk7XG5cdFx0XHRpZih1c2VyRGF0YS5lbWFpbHMgJiYgIXVzZXJEYXRhLmVtYWlscy5maW5kKGZ1bmN0aW9uKG1haWwpIHsgcmV0dXJuIG1haWwuYWRkcmVzcyA9PSBlbWFpbDsgfSkpIHtcblx0XHRcdFx0dXNlck9wdGlvbnMuZW1haWxzID0gW3sgYWRkcmVzczogZW1haWwgfV07XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0dmFyIHBhc3N3b3JkID0gXCJcIjtcblx0XHRpZih1c2VyT3B0aW9ucy5wYXNzd29yZCkge1xuXHRcdFx0cGFzc3dvcmQgPSB1c2VyT3B0aW9ucy5wYXNzd29yZDtcblx0XHRcdGRlbGV0ZSB1c2VyT3B0aW9ucy5wYXNzd29yZDtcblx0XHR9XG5cblx0XHRpZih1c2VyT3B0aW9ucykge1xuXHRcdFx0Zm9yKHZhciBrZXkgaW4gdXNlck9wdGlvbnMpIHtcblx0XHRcdFx0dmFyIG9iaiA9IHVzZXJPcHRpb25zW2tleV07XG5cdFx0XHRcdGlmKF8uaXNPYmplY3Qob2JqKSkge1xuXHRcdFx0XHRcdGZvcih2YXIgayBpbiBvYmopIHtcblx0XHRcdFx0XHRcdHVzZXJPcHRpb25zW2tleSArIFwiLlwiICsga10gPSBvYmpba107XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdGRlbGV0ZSB1c2VyT3B0aW9uc1trZXldO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRVc2Vycy51cGRhdGUodXNlcklkLCB7ICRzZXQ6IHVzZXJPcHRpb25zIH0pO1xuXHRcdH1cblxuXHRcdGlmKHBhc3N3b3JkKSB7XG5cdFx0XHRBY2NvdW50cy5zZXRQYXNzd29yZCh1c2VySWQsIHBhc3N3b3JkKTtcblx0XHR9XG5cdH0sXG5cblx0XCJzZW5kTWFpbFwiOiBmdW5jdGlvbihvcHRpb25zKSB7XG5cdFx0dGhpcy51bmJsb2NrKCk7XG5cblx0XHRFbWFpbC5zZW5kKG9wdGlvbnMpO1xuXHR9XG59KTtcblxuQWNjb3VudHMub25DcmVhdGVVc2VyKGZ1bmN0aW9uIChvcHRpb25zLCB1c2VyKSB7XG5cdHVzZXIucm9sZXMgPSBbXCJ1c2VyXCJdO1xuXG5cdGlmKG9wdGlvbnMucHJvZmlsZSkge1xuXHRcdHVzZXIucHJvZmlsZSA9IG9wdGlvbnMucHJvZmlsZTtcblx0fVxuXG5cdGlmKCFVc2Vycy5maW5kT25lKHsgcm9sZXM6IFwiYWRtaW5cIiB9KSAmJiB1c2VyLnJvbGVzLmluZGV4T2YoXCJhZG1pblwiKSA8IDApIHtcblx0XHR1c2VyLnJvbGVzID0gW1wiYWRtaW5cIl07XG5cdCB9XG5cblx0cmV0dXJuIHVzZXI7XG59KTtcblxuQWNjb3VudHMudmFsaWRhdGVMb2dpbkF0dGVtcHQoZnVuY3Rpb24oaW5mbykge1xuXG5cdC8vIHJlamVjdCB1c2VycyB3aXRoIHJvbGUgXCJibG9ja2VkXCJcblx0aWYoaW5mby51c2VyICYmIFVzZXJzLmlzSW5Sb2xlKGluZm8udXNlci5faWQsIFwiYmxvY2tlZFwiKSkge1xuXHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCBcIllvdXIgYWNjb3VudCBpcyBibG9ja2VkLlwiKTtcblx0fVxuXG4gIGlmKHZlcmlmeUVtYWlsICYmIGluZm8udXNlciAmJiBpbmZvLnVzZXIuZW1haWxzICYmIGluZm8udXNlci5lbWFpbHMubGVuZ3RoICYmICFpbmZvLnVzZXIuZW1haWxzWzBdLnZlcmlmaWVkICkge1xuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcig0OTksIFwiRS1tYWlsIG5vdCB2ZXJpZmllZC5cIik7XG4gIH1cblxuXHRyZXR1cm4gdHJ1ZTtcbn0pO1xuXG5cblVzZXJzLmJlZm9yZS5pbnNlcnQoZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0aWYoZG9jLmVtYWlscyAmJiBkb2MuZW1haWxzWzBdICYmIGRvYy5lbWFpbHNbMF0uYWRkcmVzcykge1xuXHRcdGRvYy5wcm9maWxlID0gZG9jLnByb2ZpbGUgfHwge307XG5cdFx0ZG9jLnByb2ZpbGUuZW1haWwgPSBkb2MuZW1haWxzWzBdLmFkZHJlc3M7XG5cdH0gZWxzZSB7XG5cdFx0Ly8gb2F1dGhcblx0XHRpZihkb2Muc2VydmljZXMpIHtcblx0XHRcdC8vIGdvb2dsZSBlLW1haWxcblx0XHRcdGlmKGRvYy5zZXJ2aWNlcy5nb29nbGUgJiYgZG9jLnNlcnZpY2VzLmdvb2dsZS5lbWFpbCkge1xuXHRcdFx0XHRkb2MucHJvZmlsZSA9IGRvYy5wcm9maWxlIHx8IHt9O1xuXHRcdFx0XHRkb2MucHJvZmlsZS5lbWFpbCA9IGRvYy5zZXJ2aWNlcy5nb29nbGUuZW1haWw7XG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHQvLyBnaXRodWIgZS1tYWlsXG5cdFx0XHRcdGlmKGRvYy5zZXJ2aWNlcy5naXRodWIgJiYgZG9jLnNlcnZpY2VzLmdpdGh1Yi5hY2Nlc3NUb2tlbikge1xuXHRcdFx0XHRcdHZhciBnaXRodWIgPSBuZXcgR2l0SHViKHtcblx0XHRcdFx0XHRcdHZlcnNpb246IFwiMy4wLjBcIixcblx0XHRcdFx0XHRcdHRpbWVvdXQ6IDUwMDBcblx0XHRcdFx0XHR9KTtcblxuXHRcdFx0XHRcdGdpdGh1Yi5hdXRoZW50aWNhdGUoe1xuXHRcdFx0XHRcdFx0dHlwZTogXCJvYXV0aFwiLFxuXHRcdFx0XHRcdFx0dG9rZW46IGRvYy5zZXJ2aWNlcy5naXRodWIuYWNjZXNzVG9rZW5cblx0XHRcdFx0XHR9KTtcblxuXHRcdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0XHR2YXIgcmVzdWx0ID0gZ2l0aHViLnVzZXIuZ2V0RW1haWxzKHt9KTtcblx0XHRcdFx0XHRcdHZhciBlbWFpbCA9IF8uZmluZFdoZXJlKHJlc3VsdCwgeyBwcmltYXJ5OiB0cnVlIH0pO1xuXHRcdFx0XHRcdFx0aWYoIWVtYWlsICYmIHJlc3VsdC5sZW5ndGggJiYgXy5pc1N0cmluZyhyZXN1bHRbMF0pKSB7XG5cdFx0XHRcdFx0XHRcdGVtYWlsID0geyBlbWFpbDogcmVzdWx0WzBdIH07XG5cdFx0XHRcdFx0XHR9XG5cblx0XHRcdFx0XHRcdGlmKGVtYWlsKSB7XG5cdFx0XHRcdFx0XHRcdGRvYy5wcm9maWxlID0gZG9jLnByb2ZpbGUgfHwge307XG5cdFx0XHRcdFx0XHRcdGRvYy5wcm9maWxlLmVtYWlsID0gZW1haWwuZW1haWw7XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fSBjYXRjaChlKSB7XG5cdFx0XHRcdFx0XHRjb25zb2xlLmxvZyhlKTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0Ly8gbGlua2VkaW4gZW1haWxcblx0XHRcdFx0XHRpZihkb2Muc2VydmljZXMubGlua2VkaW4gJiYgZG9jLnNlcnZpY2VzLmxpbmtlZGluLmVtYWlsQWRkcmVzcykge1xuXHRcdFx0XHRcdFx0ZG9jLnByb2ZpbGUgPSBkb2MucHJvZmlsZSB8fCB7fTtcblx0XHRcdFx0XHRcdGRvYy5wcm9maWxlLm5hbWUgPSBkb2Muc2VydmljZXMubGlua2VkaW4uZmlyc3ROYW1lICsgXCIgXCIgKyBkb2Muc2VydmljZXMubGlua2VkaW4ubGFzdE5hbWU7XG5cdFx0XHRcdFx0XHRkb2MucHJvZmlsZS5lbWFpbCA9IGRvYy5zZXJ2aWNlcy5saW5rZWRpbi5lbWFpbEFkZHJlc3M7XG5cdFx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRcdGlmKGRvYy5zZXJ2aWNlcy5mYWNlYm9vayAmJiBkb2Muc2VydmljZXMuZmFjZWJvb2suZW1haWwpIHtcblx0XHRcdFx0XHRcdFx0ZG9jLnByb2ZpbGUgPSBkb2MucHJvZmlsZSB8fCB7fTtcblx0XHRcdFx0XHRcdFx0ZG9jLnByb2ZpbGUuZW1haWwgPSBkb2Muc2VydmljZXMuZmFjZWJvb2suZW1haWw7XG5cdFx0XHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdFx0XHRpZihkb2Muc2VydmljZXMudHdpdHRlciAmJiBkb2Muc2VydmljZXMudHdpdHRlci5lbWFpbCkge1xuXHRcdFx0XHRcdFx0XHRcdGRvYy5wcm9maWxlID0gZG9jLnByb2ZpbGUgfHwge307XG5cdFx0XHRcdFx0XHRcdFx0ZG9jLnByb2ZpbGUuZW1haWwgPSBkb2Muc2VydmljZXMudHdpdHRlci5lbWFpbDtcblx0XHRcdFx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRcdFx0XHRpZihkb2Muc2VydmljZXNbXCJtZXRlb3ItZGV2ZWxvcGVyXCJdICYmIGRvYy5zZXJ2aWNlc1tcIm1ldGVvci1kZXZlbG9wZXJcIl0uZW1haWxzICYmIGRvYy5zZXJ2aWNlc1tcIm1ldGVvci1kZXZlbG9wZXJcIl0uZW1haWxzLmxlbmd0aCkge1xuXHRcdFx0XHRcdFx0XHRcdFx0ZG9jLnByb2ZpbGUgPSBkb2MucHJvZmlsZSB8fCB7fTtcblx0XHRcdFx0XHRcdFx0XHRcdGRvYy5wcm9maWxlLmVtYWlsID0gZG9jLnNlcnZpY2VzW1wibWV0ZW9yLWRldmVsb3BlclwiXS5lbWFpbHNbMF0uYWRkcmVzcztcblx0XHRcdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9XG5cdH1cbn0pO1xuXG5Vc2Vycy5iZWZvcmUudXBkYXRlKGZ1bmN0aW9uKHVzZXJJZCwgZG9jLCBmaWVsZE5hbWVzLCBtb2RpZmllciwgb3B0aW9ucykge1xuXHRpZihtb2RpZmllci4kc2V0ICYmIG1vZGlmaWVyLiRzZXQuZW1haWxzICYmIG1vZGlmaWVyLiRzZXQuZW1haWxzLmxlbmd0aCAmJiBtb2RpZmllci4kc2V0LmVtYWlsc1swXS5hZGRyZXNzKSB7XG5cdFx0bW9kaWZpZXIuJHNldC5wcm9maWxlLmVtYWlsID0gbW9kaWZpZXIuJHNldC5lbWFpbHNbMF0uYWRkcmVzcztcblx0fVxufSk7XG5cbkFjY291bnRzLm9uTG9naW4oZnVuY3Rpb24gKGluZm8pIHtcblx0XG59KTtcblxuQWNjb3VudHMudXJscy5yZXNldFBhc3N3b3JkID0gZnVuY3Rpb24gKHRva2VuKSB7XG5cdHJldHVybiBNZXRlb3IuYWJzb2x1dGVVcmwoJ3Jlc2V0X3Bhc3N3b3JkLycgKyB0b2tlbik7XG59O1xuXG5BY2NvdW50cy51cmxzLnZlcmlmeUVtYWlsID0gZnVuY3Rpb24gKHRva2VuKSB7XG5cdHJldHVybiBNZXRlb3IuYWJzb2x1dGVVcmwoJ3ZlcmlmeV9lbWFpbC8nICsgdG9rZW4pO1xufTtcblxuQWNjb3VudHMudXJscy5lbnJvbGxBY2NvdW50ID0gZnVuY3Rpb24gKHRva2VuKSB7XG5cdHJldHVybiBNZXRlb3IuYWJzb2x1dGVVcmwoJ2NyZWF0ZV9wYXNzd29yZC8nICsgdG9rZW4pO1xufTtcbiJdfQ==
